import sqlite3
import threading
import random
from datetime import datetime, timedelta
from config import DB_PATH, DEFAULT_REFERRAL_REWARD, LOW_STOCK_THRESHOLD

_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with get_conn() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id         INTEGER PRIMARY KEY,
            username        TEXT,
            full_name       TEXT NOT NULL,
            language        TEXT DEFAULT 'ar',
            balance         REAL DEFAULT 0.0,
            total_spent     REAL DEFAULT 0.0,
            ref_earnings    REAL DEFAULT 0.0,
            ref_count       INTEGER DEFAULT 0,
            referred_by     INTEGER,
            discount_coupon INTEGER DEFAULT 0,
            instagram_shown INTEGER DEFAULT 0,
            pending_ref     INTEGER,
            created_at      TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (referred_by) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS mods (
            mod_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL UNIQUE,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS keys (
            key_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            mod_id       INTEGER NOT NULL,
            product_type TEXT NOT NULL DEFAULT 'key',
            key_value    TEXT,
            file_id      TEXT,
            file_name    TEXT,
            description  TEXT,
            duration     INTEGER NOT NULL,
            price        REAL NOT NULL,
            quantity     INTEGER DEFAULT 1,
            is_sold      INTEGER DEFAULT 0,
            sold_to      INTEGER,
            sold_at      TEXT,
            FOREIGN KEY (mod_id) REFERENCES mods(mod_id) ON DELETE CASCADE,
            FOREIGN KEY (sold_to) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS purchases (
            purchase_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            key_id       INTEGER NOT NULL,
            mod_id       INTEGER NOT NULL,
            mod_name     TEXT NOT NULL,
            duration     INTEGER NOT NULL,
            price        REAL NOT NULL,
            product_type TEXT DEFAULT 'key',
            key_value    TEXT,
            file_id      TEXT,
            purchased_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS tickets (
            ticket_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            message    TEXT NOT NULL,
            photo_id   TEXT,
            status     TEXT DEFAULT 'open',
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS gift_links (
            link_id    TEXT PRIMARY KEY,
            amount     REAL NOT NULL,
            max_uses   INTEGER DEFAULT 0,
            used_count INTEGER DEFAULT 0,
            expires_at TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS gift_usages (
            usage_id INTEGER PRIMARY KEY AUTOINCREMENT,
            link_id  TEXT NOT NULL,
            user_id  INTEGER NOT NULL,
            used_at  TEXT DEFAULT (datetime('now')),
            UNIQUE(link_id, user_id),
            FOREIGN KEY (link_id) REFERENCES gift_links(link_id)
        );

        CREATE TABLE IF NOT EXISTS payment_methods (
            method_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            name_ar         TEXT NOT NULL,
            name_en         TEXT NOT NULL,
            instructions_ar TEXT,
            instructions_en TEXT,
            is_active       INTEGER DEFAULT 1,
            created_at      TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS coupons (
            coupon_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            code       TEXT NOT NULL UNIQUE,
            type       TEXT NOT NULL,
            value      REAL NOT NULL,
            is_used    INTEGER DEFAULT 0,
            used_by    INTEGER,
            used_at    TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (used_by) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS daily_spins (
            user_id   INTEGER PRIMARY KEY,
            last_spin TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        );

        CREATE TABLE IF NOT EXISTS user_messages (
            user_id    INTEGER,
            message_id INTEGER,
            sent_at    TEXT DEFAULT (datetime('now')),
            PRIMARY KEY (user_id, message_id)
        );

        INSERT OR IGNORE INTO settings (key, value) VALUES ('referral_reward',      '0.03');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('maintenance_mode',     '0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('recharge_commission',  '15.0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('referral_enabled',     '1');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('commission_enabled',   '1');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('force_sub_enabled',    '1');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('spin_no_prize_chance', '60.0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('spin_balance_chance',  '25.0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('spin_discount5_chance','10.0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('spin_discount7_chance','5.0');
        INSERT OR IGNORE INTO settings (key, value) VALUES ('spin_balance_value',   '0.05');

        INSERT OR IGNORE INTO payment_methods
            (method_id, name_ar, name_en, instructions_ar, instructions_en)
        VALUES
            (1,
             '📩 الدفع عبر التواصل مع المطور',
             '📩 Payment via Developer Contact',
             'قم بإرسال المعلومات التالية إلى المطور',
             'Send the following information to the developer');
        """)
        _run_migrations(conn)


def _run_migrations(conn):
    """Add new columns to existing tables safely."""
    migrations = [
        "ALTER TABLE keys ADD COLUMN product_type TEXT DEFAULT 'key'",
        "ALTER TABLE keys ADD COLUMN file_id      TEXT",
        "ALTER TABLE keys ADD COLUMN file_name    TEXT",
        "ALTER TABLE keys ADD COLUMN description  TEXT",
        "ALTER TABLE keys ADD COLUMN quantity     INTEGER DEFAULT 1",
        "ALTER TABLE purchases ADD COLUMN product_type TEXT DEFAULT 'key'",
        "ALTER TABLE purchases ADD COLUMN file_id      TEXT",
        # Forced-subscription onboarding state.
        "ALTER TABLE users ADD COLUMN instagram_shown INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN pending_ref     INTEGER",
    ]
    for sql in migrations:
        try:
            conn.execute(sql)
        except Exception:
            pass


# ══════════════════════════════════════════
#                   USERS
# ══════════════════════════════════════════

def get_user(user_id: int):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ).fetchone()


def create_user(user_id: int, username: str, full_name: str,
                language: str = 'ar', referred_by: int = None,
                pending_ref: int = None):
    """
    Create a user if not present.

    `referred_by`  : permanent record of who invited this user (history).
    `pending_ref`  : the referrer who will be REWARDED, but only AFTER this
                     user passes the forced-subscription check. Stored here
                     and consumed later by grant_pending_referral(). This is
                     the core anti-fake-referral mechanism — no reward is
                     paid on link click, only on verified subscription.
    """
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                INSERT OR IGNORE INTO users
                    (user_id, username, full_name, language,
                     referred_by, pending_ref)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, username, full_name, language,
                  referred_by, pending_ref))


def update_user_language(user_id: int, language: str):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE users SET language = ? WHERE user_id = ?",
                (language, user_id)
            )


def get_user_language(user_id: int) -> str:
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT language FROM users WHERE user_id = ?", (user_id,)
            ).fetchone()
            return row["language"] if row else "ar"


def update_balance(user_id: int, amount: float):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (amount, user_id)
            )


def deduct_balance_and_record_spend(user_id: int, amount: float):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                UPDATE users
                SET balance     = balance - ?,
                    total_spent = total_spent + ?
                WHERE user_id = ?
            """, (amount, amount, user_id))


def add_referral_earnings(referrer_id: int, amount: float):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                UPDATE users
                SET balance      = balance + ?,
                    ref_earnings = ref_earnings + ?,
                    ref_count    = ref_count + 1
                WHERE user_id = ?
            """, (amount, amount, referrer_id))


def get_all_users_count() -> int:
    with _lock:
        with get_conn() as conn:
            return conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def get_all_user_ids() -> list:
    """Get ALL user IDs including old users - for broadcast."""
    with _lock:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT user_id FROM users ORDER BY created_at ASC"
            ).fetchall()
            return [row["user_id"] for row in rows]


def get_all_users_with_balance() -> list:
    """Get all users with balance > 0 for balance notification."""
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT user_id, full_name, balance, ref_count, language
                FROM users
                WHERE balance > 0
                ORDER BY balance DESC
            """).fetchall()


def get_user_referrer(user_id: int):
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT referred_by FROM users WHERE user_id = ?",
                (user_id,)
            ).fetchone()
            if row and row["referred_by"]:
                return row["referred_by"]
            return None


def set_user_discount(user_id: int, discount: int):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE users SET discount_coupon = ? WHERE user_id = ?",
                (discount, user_id)
            )


def get_user_discount(user_id: int) -> int:
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT discount_coupon FROM users WHERE user_id = ?",
                (user_id,)
            ).fetchone()
            return row["discount_coupon"] if row else 0


def use_user_discount(user_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE users SET discount_coupon = 0 WHERE user_id = ?",
                (user_id,)
            )


# ══════════════════════════════════════════
#                   MODS
# ══════════════════════════════════════════

def get_all_mods():
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM mods ORDER BY name"
            ).fetchall()


def get_mod_by_id(mod_id: int):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM mods WHERE mod_id = ?", (mod_id,)
            ).fetchone()


def add_mod(name: str) -> bool:
    try:
        with _lock:
            with get_conn() as conn:
                conn.execute("INSERT INTO mods (name) VALUES (?)", (name,))
        return True
    except sqlite3.IntegrityError:
        return False


def update_mod_name(mod_id: int, new_name: str) -> bool:
    try:
        with _lock:
            with get_conn() as conn:
                conn.execute(
                    "UPDATE mods SET name = ? WHERE mod_id = ?",
                    (new_name, mod_id)
                )
        return True
    except sqlite3.IntegrityError:
        return False


def delete_mod(mod_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute("DELETE FROM mods WHERE mod_id = ?", (mod_id,))


# ══════════════════════════════════════════
#                   KEYS
# ══════════════════════════════════════════

def add_keys(mod_id: int, duration: int, price: float,
             key_list: list) -> tuple:
    """Add text keys - same as before."""
    added = 0
    with _lock:
        with get_conn() as conn:
            for k in key_list:
                k = k.strip()
                if not k:
                    continue
                conn.execute("""
                    INSERT INTO keys
                        (mod_id, product_type, key_value, duration, price)
                    VALUES (?, 'key', ?, ?, ?)
                """, (mod_id, k, duration, price))
                added += 1
    return added, 0


def add_file_product(mod_id: int, duration: int, price: float,
                     file_id: str, file_name: str,
                     quantity: int, description: str = None) -> bool:
    """
    Add a file product with quantity.
    Each row = one unit available for sale.
    """
    try:
        with _lock:
            with get_conn() as conn:
                for _ in range(quantity):
                    conn.execute("""
                        INSERT INTO keys
                            (mod_id, product_type, file_id, file_name,
                             description, duration, price, quantity)
                        VALUES (?, 'file', ?, ?, ?, ?, ?, ?)
                    """, (mod_id, file_id, file_name,
                          description, duration, price, quantity))
        return True
    except Exception:
        return False


def get_keys_summary(mod_id: int) -> list:
    """Returns available products grouped by duration/price/type."""
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT duration, price, product_type,
                       COUNT(*) as cnt
                FROM keys
                WHERE mod_id = ? AND is_sold = 0
                GROUP BY duration, price, product_type
                ORDER BY duration, price
            """, (mod_id,)).fetchall()


def get_available_key(mod_id: int, duration: int, price: float):
    """Get one available product."""
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT * FROM keys
                WHERE mod_id = ? AND duration = ?
                  AND price = ? AND is_sold = 0
                LIMIT 1
            """, (mod_id, duration, price)).fetchone()


def mark_key_sold(key_id: int, user_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                UPDATE keys
                SET is_sold = 1,
                    sold_to = ?,
                    sold_at = datetime('now')
                WHERE key_id = ?
            """, (user_id, key_id))


def get_total_available_keys() -> int:
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM keys WHERE is_sold = 0"
            ).fetchone()[0]


def get_mod_keys_info(mod_id: int) -> list:
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT duration, price, product_type,
                       SUM(CASE WHEN is_sold=0 THEN 1 ELSE 0 END) as available,
                       COUNT(*) as total
                FROM keys
                WHERE mod_id = ?
                GROUP BY duration, price, product_type
                ORDER BY duration, price
            """, (mod_id,)).fetchall()


def update_keys_price(mod_id: int, duration: int,
                      old_price: float, new_price: float) -> int:
    with _lock:
        with get_conn() as conn:
            cur = conn.execute("""
                UPDATE keys
                SET price = ?
                WHERE mod_id = ? AND duration = ?
                  AND price = ? AND is_sold = 0
            """, (new_price, mod_id, duration, old_price))
            return cur.rowcount


def get_keys_by_duration_price(mod_id: int, duration: int,
                                price: float, limit: int = 50):
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT key_id, product_type, key_value,
                       file_id, file_name, description,
                       is_sold, sold_at
                FROM keys
                WHERE mod_id = ? AND duration = ? AND price = ?
                ORDER BY is_sold, key_id
                LIMIT ?
            """, (mod_id, duration, price, limit)).fetchall()


# ══════════════════════════════════════════
#                 PURCHASES
# ══════════════════════════════════════════

def record_purchase(user_id: int, key_id: int, mod_id: int,
                    mod_name: str, duration: int, price: float,
                    product_type: str = 'key',
                    key_value: str = None,
                    file_id: str = None):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                INSERT INTO purchases
                    (user_id, key_id, mod_id, mod_name, duration,
                     price, product_type, key_value, file_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, key_id, mod_id, mod_name, duration,
                  price, product_type, key_value, file_id))


def get_user_purchases(user_id: int) -> list:
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT * FROM purchases
                WHERE user_id = ?
                ORDER BY purchased_at DESC
            """, (user_id,)).fetchall()


def get_total_sales() -> tuple:
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT COUNT(*), COALESCE(SUM(price),0) FROM purchases"
            ).fetchone()
            return row[0], row[1]


# ══════════════════════════════════════════
#                  TICKETS
# ══════════════════════════════════════════

def create_ticket(user_id: int, message: str, photo_id: str = None):
    with _lock:
        with get_conn() as conn:
            cur = conn.execute("""
                INSERT INTO tickets (user_id, message, photo_id)
                VALUES (?, ?, ?)
            """, (user_id, message, photo_id))
            return cur.lastrowid


def get_open_tickets() -> list:
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT t.*, u.full_name, u.username
                FROM tickets t
                JOIN users u ON t.user_id = u.user_id
                WHERE t.status = 'open'
                ORDER BY t.created_at
            """).fetchall()


def get_open_tickets_count() -> int:
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM tickets WHERE status='open'"
            ).fetchone()[0]


def close_ticket(ticket_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE tickets SET status='closed' WHERE ticket_id=?",
                (ticket_id,)
            )


def get_ticket(ticket_id: int):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM tickets WHERE ticket_id=?", (ticket_id,)
            ).fetchone()


# ══════════════════════════════════════════
#                 SETTINGS
# ══════════════════════════════════════════

def get_setting(key: str, default=None):
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT value FROM settings WHERE key=?", (key,)
            ).fetchone()
            return row["value"] if row else default


def set_setting(key: str, value: str):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)",
                (key, value)
            )


def get_referral_reward() -> float:
    return float(get_setting("referral_reward", DEFAULT_REFERRAL_REWARD))


def is_maintenance_mode() -> bool:
    return get_setting("maintenance_mode", "0") == "1"


def set_maintenance_mode(enabled: bool):
    set_setting("maintenance_mode", "1" if enabled else "0")


def get_recharge_commission_rate() -> float:
    return float(get_setting("recharge_commission", "15.0"))


def set_recharge_commission_rate(rate: float):
    set_setting("recharge_commission", str(rate))


def is_referral_enabled() -> bool:
    return get_setting("referral_enabled", "1") == "1"


def set_referral_enabled(enabled: bool):
    set_setting("referral_enabled", "1" if enabled else "0")


def is_commission_enabled() -> bool:
    return get_setting("commission_enabled", "1") == "1"


def set_commission_enabled(enabled: bool):
    set_setting("commission_enabled", "1" if enabled else "0")


# ══════════════════════════════════════════
#       FORCED SUBSCRIPTION  (NEW)
# ══════════════════════════════════════════

def is_force_sub_enabled() -> bool:
    """Admin toggle for the forced-subscription gate."""
    return get_setting("force_sub_enabled", "1") == "1"


def set_force_sub_enabled(enabled: bool):
    set_setting("force_sub_enabled", "1" if enabled else "0")


def instagram_shown(user_id: int) -> bool:
    """True if the one-time Instagram step was already shown to this user."""
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT instagram_shown FROM users WHERE user_id = ?",
                (user_id,)
            ).fetchone()
            return bool(row["instagram_shown"]) if row else False


def mark_instagram_shown(user_id: int):
    """Mark the one-time Instagram step as shown (idempotent)."""
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "UPDATE users SET instagram_shown = 1 WHERE user_id = ?",
                (user_id,)
            )


def set_pending_referrer(user_id: int, referrer_id: int):
    """
    Store a pending (unpaid) referral for `user_id`. The reward is paid only
    after the user passes the channel check. Never overwrites an existing
    pending referrer and never allows self-referral.
    """
    if not referrer_id or referrer_id == user_id:
        return
    with _lock:
        with get_conn() as conn:
            # Only set if currently NULL, so the first inviter wins and a user
            # cannot be re-attributed by spamming multiple referral links.
            conn.execute("""
                UPDATE users
                SET pending_ref = ?
                WHERE user_id = ? AND pending_ref IS NULL
            """, (referrer_id, user_id))


def get_pending_referrer(user_id: int):
    """Return the pending (unpaid) referrer id for this user, or None."""
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT pending_ref FROM users WHERE user_id = ?",
                (user_id,)
            ).fetchone()
            if row and row["pending_ref"]:
                return row["pending_ref"]
            return None


def clear_pending_referrer(user_id: int) -> bool:
    """
    Atomically consume the pending referral so the reward can be paid AT MOST
    once. Returns True only if there really was a pending referrer that this
    call cleared (so two concurrent verifications can never double-pay).
    """
    with _lock:
        with get_conn() as conn:
            cur = conn.execute("""
                UPDATE users
                SET pending_ref = NULL
                WHERE user_id = ? AND pending_ref IS NOT NULL
            """, (user_id,))
            return cur.rowcount == 1


def add_recharge_commission(referrer_id: int, amount: float,
                             commission_rate: float) -> float:
    """Add commission to referrer. Returns commission amount."""
    commission = round((amount * commission_rate) / 100.0, 4)
    if commission <= 0:
        return 0.0
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                UPDATE users
                SET balance      = balance + ?,
                    ref_earnings = ref_earnings + ?
                WHERE user_id = ?
            """, (commission, commission, referrer_id))
    return commission


# ══════════════════════════════════════════
#                GIFT LINKS
# ══════════════════════════════════════════

def create_gift_link(link_id: str, amount: float,
                     max_uses: int, expires_at: str = None):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                INSERT INTO gift_links (link_id, amount, max_uses, expires_at)
                VALUES (?, ?, ?, ?)
            """, (link_id, amount, max_uses, expires_at))


def get_gift_link(link_id: str):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM gift_links WHERE link_id=?", (link_id,)
            ).fetchone()


def check_gift_usage(link_id: str, user_id: int) -> bool:
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT 1 FROM gift_usages WHERE link_id=? AND user_id=?",
                (link_id, user_id)
            ).fetchone()
            return row is not None


def claim_gift(link_id: str, user_id: int, amount: float):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO gift_usages (link_id, user_id) VALUES (?,?)",
                (link_id, user_id)
            )
            conn.execute(
                "UPDATE gift_links SET used_count = used_count+1 WHERE link_id=?",
                (link_id,)
            )
            conn.execute(
                "UPDATE users SET balance = balance+? WHERE user_id=?",
                (amount, user_id)
            )


# ══════════════════════════════════════════
#            PAYMENT METHODS
# ══════════════════════════════════════════

def get_payment_methods() -> list:
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT * FROM payment_methods
                WHERE is_active = 1 ORDER BY method_id
            """).fetchall()


def get_all_payment_methods() -> list:
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM payment_methods ORDER BY method_id"
            ).fetchall()


def add_payment_method(name_ar: str, name_en: str,
                        instructions_ar: str, instructions_en: str) -> int:
    with _lock:
        with get_conn() as conn:
            cur = conn.execute("""
                INSERT INTO payment_methods
                    (name_ar, name_en, instructions_ar, instructions_en)
                VALUES (?, ?, ?, ?)
            """, (name_ar, name_en, instructions_ar, instructions_en))
            return cur.lastrowid


def delete_payment_method(method_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "DELETE FROM payment_methods WHERE method_id=?",
                (method_id,)
            )


def toggle_payment_method(method_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                UPDATE payment_methods
                SET is_active = NOT is_active
                WHERE method_id = ?
            """, (method_id,))


def get_payment_method(method_id: int):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM payment_methods WHERE method_id=?",
                (method_id,)
            ).fetchone()


# ══════════════════════════════════════════
#            LEADERBOARD
# ══════════════════════════════════════════

def get_top_users_by_balance(limit: int = 15, min_balance: float = 0.50):
    with _lock:
        with get_conn() as conn:
            return conn.execute("""
                SELECT user_id, username, full_name,
                       balance, total_spent, ref_earnings
                FROM users
                WHERE balance >= ?
                ORDER BY balance DESC
                LIMIT ?
            """, (min_balance, limit)).fetchall()


def get_user_rank(user_id: int) -> int:
    with _lock:
        with get_conn() as conn:
            row = conn.execute("""
                SELECT COUNT(*) + 1 as rank
                FROM users
                WHERE balance > (
                    SELECT balance FROM users WHERE user_id = ?
                )
            """, (user_id,)).fetchone()
            return row["rank"] if row else 0


# ══════════════════════════════════════════
#            COUPONS
# ══════════════════════════════════════════

def generate_coupon_code() -> str:
    while True:
        code = str(random.randint(100000000, 999999999))
        with _lock:
            with get_conn() as conn:
                exists = conn.execute(
                    "SELECT 1 FROM coupons WHERE code=?", (code,)
                ).fetchone()
                if not exists:
                    return code


def create_coupon(coupon_type: str, value: float) -> str:
    code = generate_coupon_code()
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO coupons (code, type, value) VALUES (?,?,?)",
                (code, coupon_type, value)
            )
    return code


def get_coupon(code: str):
    with _lock:
        with get_conn() as conn:
            return conn.execute(
                "SELECT * FROM coupons WHERE code=?", (code,)
            ).fetchone()


def use_coupon(code: str, user_id: int) -> bool:
    with _lock:
        with get_conn() as conn:
            coupon = conn.execute(
                "SELECT * FROM coupons WHERE code=? AND is_used=0", (code,)
            ).fetchone()
            if not coupon:
                return False
            conn.execute("""
                UPDATE coupons
                SET is_used=1, used_by=?, used_at=datetime('now')
                WHERE code=?
            """, (user_id, code))
            return True


# ══════════════════════════════════════════
#           DAILY SPIN WHEEL
# ══════════════════════════════════════════

def get_last_spin_time(user_id: int):
    with _lock:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT last_spin FROM daily_spins WHERE user_id=?",
                (user_id,)
            ).fetchone()
            return row["last_spin"] if row else None


def update_spin_time(user_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO daily_spins (user_id, last_spin)
                VALUES (?, datetime('now'))
            """, (user_id,))


def get_spin_settings() -> dict:
    return {
        'no_prize':      float(get_setting('spin_no_prize_chance', '60.0')),
        'balance':       float(get_setting('spin_balance_chance',  '25.0')),
        'discount5':     float(get_setting('spin_discount5_chance','10.0')),
        'discount7':     float(get_setting('spin_discount7_chance', '5.0')),
        'balance_value': float(get_setting('spin_balance_value',   '0.05')),
    }


def update_spin_setting(key: str, value: float):
    set_setting(key, str(value))


# ══════════════════════════════════════════
#      MESSAGE TRACKING
# ══════════════════════════════════════════

def save_bot_message(user_id: int, message_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute("""
                INSERT OR IGNORE INTO user_messages (user_id, message_id)
                VALUES (?, ?)
            """, (user_id, message_id))
            conn.execute("""
                DELETE FROM user_messages
                WHERE user_id = ?
                  AND message_id NOT IN (
                      SELECT message_id FROM user_messages
                      WHERE user_id = ?
                      ORDER BY sent_at DESC
                      LIMIT 50
                  )
            """, (user_id, user_id))


def get_user_bot_messages(user_id: int, limit: int = 50):
    with _lock:
        with get_conn() as conn:
            rows = conn.execute("""
                SELECT message_id FROM user_messages
                WHERE user_id = ?
                ORDER BY sent_at DESC
                LIMIT ?
            """, (user_id, limit)).fetchall()
            return [row["message_id"] for row in rows]


def clear_user_messages(user_id: int):
    with _lock:
        with get_conn() as conn:
            conn.execute(
                "DELETE FROM user_messages WHERE user_id=?", (user_id,)
            )


# ══════════════════════════════════════════
#         ATOMIC PURCHASE (race-safe)
# ══════════════════════════════════════════

def purchase_atomic(user_id: int, mod_id: int, duration: int,
                    price: float, final_price: float,
                    mod_name: str, apply_discount: bool):
    """
    Perform the whole purchase in ONE transaction so two fast clicks
    (or two devices) can never double-sell a key or double-charge.

    Returns a dict:
      {"status": "ok", "key_row": <dict>, "new_balance": float}
      {"status": "insufficient", "balance": float}
      {"status": "out_of_stock"}
      {"status": "error"}
    """
    with _lock:
        conn = get_conn()
        try:
            conn.isolation_level = None  # manual transaction control
            conn.execute("BEGIN IMMEDIATE")

            # 1) Lock-read the user balance.
            urow = conn.execute(
                "SELECT balance, discount_coupon FROM users WHERE user_id = ?",
                (user_id,)
            ).fetchone()
            if not urow:
                conn.execute("ROLLBACK")
                return {"status": "error"}

            balance = urow["balance"]
            if balance < final_price:
                conn.execute("ROLLBACK")
                return {"status": "insufficient", "balance": balance}

            # 2) Reserve exactly one unsold unit (conditional UPDATE = atomic claim).
            key_row = conn.execute("""
                SELECT key_id, product_type, key_value, file_id
                FROM keys
                WHERE mod_id = ? AND duration = ? AND price = ? AND is_sold = 0
                LIMIT 1
            """, (mod_id, duration, price)).fetchone()

            if not key_row:
                conn.execute("ROLLBACK")
                return {"status": "out_of_stock"}

            claimed = conn.execute("""
                UPDATE keys
                SET is_sold = 1, sold_to = ?, sold_at = datetime('now')
                WHERE key_id = ? AND is_sold = 0
            """, (user_id, key_row["key_id"]))

            if claimed.rowcount != 1:
                # Someone else grabbed it between SELECT and UPDATE.
                conn.execute("ROLLBACK")
                return {"status": "out_of_stock"}

            # 3) Deduct balance + record spend.
            conn.execute("""
                UPDATE users
                SET balance = balance - ?, total_spent = total_spent + ?
                WHERE user_id = ?
            """, (final_price, final_price, user_id))

            # 4) Record the purchase.
            ptype = key_row["product_type"] if key_row["product_type"] else "key"
            conn.execute("""
                INSERT INTO purchases
                    (user_id, key_id, mod_id, mod_name, duration,
                     price, product_type, key_value, file_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                user_id, key_row["key_id"], mod_id, mod_name, duration,
                final_price, ptype,
                key_row["key_value"] if ptype == "key" else None,
                key_row["file_id"]  if ptype == "file" else None
            ))

            # 5) Consume the one-time discount if it was applied.
            if apply_discount:
                conn.execute(
                    "UPDATE users SET discount_coupon = 0 WHERE user_id = ?",
                    (user_id,)
                )

            conn.execute("COMMIT")

            return {
                "status": "ok",
                "key_row": {
                    "key_id":       key_row["key_id"],
                    "product_type": ptype,
                    "key_value":    key_row["key_value"],
                    "file_id":      key_row["file_id"],
                },
                "new_balance": balance - final_price,
            }

        except Exception:
            try:
                conn.execute("ROLLBACK")
            except Exception:
                pass
            return {"status": "error"}
        finally:
            conn.close()


# ══════════════════════════════════════════
#         DATA BACKUP / RESTORE
# ══════════════════════════════════════════
import os as _os
import shutil as _shutil

# When the bot starts, if a backup file with this name exists in the project
# folder, it is imported automatically (so data survives across redeploys).
BACKUP_IMPORT_NAME = "bot_data_backup.db"


def export_backup(dest_path: str = None) -> str:
    """
    Create a safe, consistent copy of the live database using SQLite's
    online backup API (works even with WAL mode and concurrent access).
    Returns the path to the generated backup file.
    """
    if dest_path is None:
        dest_path = "bot_data_backup.db"
    with _lock:
        src = sqlite3.connect(DB_PATH, check_same_thread=False)
        try:
            # Make sure WAL changes are flushed into the main db file.
            try:
                src.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
            dst = sqlite3.connect(dest_path)
            try:
                src.backup(dst)          # atomic, consistent snapshot
            finally:
                dst.close()
        finally:
            src.close()
    return dest_path


def restore_backup_if_present(import_name: str = None) -> bool:
    """
    Called ONCE at startup, BEFORE init_db().

    Logic:
      - If the live DB does not exist yet AND an incoming backup file exists,
        import it (rename/copy it into place) so the bot continues with old data.
      - If the live DB already exists, leave it untouched (we never overwrite
        live data automatically) but keep a safety copy of any incoming backup.
      - If neither exists, do nothing -> init_db() will create a fresh DB.

    Returns True if a backup was imported.
    """
    if import_name is None:
        import_name = BACKUP_IMPORT_NAME

    incoming_exists = _os.path.exists(import_name)
    live_exists     = _os.path.exists(DB_PATH)

    if incoming_exists and not live_exists:
        # Fresh deploy + a backup provided -> adopt the backup as the live DB.
        _shutil.copyfile(import_name, DB_PATH)
        return True

    if incoming_exists and live_exists:
        # Live DB already present; do NOT clobber it automatically.
        # Keep the incoming backup aside so the owner can restore manually if needed.
        try:
            if _os.path.abspath(import_name) != _os.path.abspath(DB_PATH):
                _shutil.copyfile(import_name, import_name + ".kept")
        except Exception:
            pass
        return False

    return False


def force_restore(import_name: str = None) -> bool:
    """
    Explicit, owner-triggered full restore: overwrite the live DB with the
    provided backup file. A safety snapshot of the current DB is taken first.
    Returns True on success.
    """
    if import_name is None:
        import_name = BACKUP_IMPORT_NAME
    if not _os.path.exists(import_name):
        return False
    with _lock:
        try:
            if _os.path.exists(DB_PATH):
                _shutil.copyfile(DB_PATH, DB_PATH + ".pre_restore")
            _shutil.copyfile(import_name, DB_PATH)
            return True
        except Exception:
            return False


def get_backup_stats() -> dict:
    """Quick counts to confirm a backup/restore contains real data."""
    with _lock:
        with get_conn() as conn:
            def one(q):
                try:
                    return conn.execute(q).fetchone()[0]
                except Exception:
                    return 0
            return {
                "users":     one("SELECT COUNT(*) FROM users"),
                "purchases": one("SELECT COUNT(*) FROM purchases"),
                "keys":      one("SELECT COUNT(*) FROM keys"),
                "mods":      one("SELECT COUNT(*) FROM mods"),
                "balance":   one("SELECT COALESCE(SUM(balance),0) FROM users"),
            }
