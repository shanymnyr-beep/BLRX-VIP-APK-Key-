"""
╔══════════════════════════════════════════════════════════════╗
║   Forced Subscription + hidden anti-spam / anti-fake-referral  ║
╚══════════════════════════════════════════════════════════════╝

Central gate used by every handler in the bot.

Flow enforced here:
  1) User must be a member of the Telegram channel (verified via
     get_chat_member -> REAL check). Owner is always exempt.
  2) After passing (1) the user is shown the Instagram follow step
     ONCE (no verification — purely informational).
  3) Once the Instagram step has been shown, the user is fully
     onboarded and the bot works normally.

The referral reward is intentionally NOT granted when the user merely
opens the referral link. It is granted ONLY the moment the invited user
passes the real channel-membership check (see grant_pending_referral).
That single rule kills most fake-referral farming.
"""

import time
import logging

import telebot

from config import (
    OWNER_ID,
    FORCE_SUB_ENABLED,
    FORCE_SUB_CHANNEL_ID,
    FORCE_SUB_CHANNEL_USERNAME,
    FORCE_SUB_CHANNEL_LINK,
    INSTAGRAM_ENABLED,
    VERIFY_COOLDOWN_SECONDS,
)
from database import (
    is_force_sub_enabled,
    get_user,
    instagram_shown,
    mark_instagram_shown,
    get_pending_referrer,
    clear_pending_referrer,
    add_referral_earnings,
    get_user_language,
    is_referral_enabled,
    get_referral_reward,
)

logger = logging.getLogger(__name__)

# Statuses returned by Telegram for a channel member.
_MEMBER_STATUSES = ("creator", "administrator", "member", "restricted")

# In-memory cooldown map for the "verify" button (anti-flood). user_id -> ts.
_verify_cooldown = {}


# ══════════════════════════════════════════════════════════════
#   CHANNEL LINK
# ══════════════════════════════════════════════════════════════
def channel_link() -> str:
    """Public link used by the 'Join channel' button."""
    if FORCE_SUB_CHANNEL_LINK:
        return FORCE_SUB_CHANNEL_LINK
    if FORCE_SUB_CHANNEL_USERNAME:
        uname = FORCE_SUB_CHANNEL_USERNAME.lstrip("@")
        return f"https://t.me/{uname}"
    return ""


# ══════════════════════════════════════════════════════════════
#   REAL MEMBERSHIP CHECK
# ══════════════════════════════════════════════════════════════
def is_subscribed(bot: telebot.TeleBot, user_id: int) -> bool:
    """
    Returns True if the forced-subscription gate is satisfied for this user.

    - Owner is always allowed.
    - If the feature is disabled (config flag OR admin toggle), always True.
    - Otherwise performs a REAL get_chat_member call against the channel.
      Any failure (bot not admin, network, etc.) is treated as 'not
      subscribed' so the gate fails closed, EXCEPT it is logged so the
      owner can fix the admin rights.
    """
    if user_id == OWNER_ID:
        return True
    if not FORCE_SUB_ENABLED:
        return True
    if not is_force_sub_enabled():
        return True

    try:
        member = bot.get_chat_member(FORCE_SUB_CHANNEL_ID, user_id)
        return member.status in _MEMBER_STATUSES
    except Exception as e:
        logger.warning(
            "Membership check failed for %s on %s: %s "
            "(is the bot an admin in the channel?)",
            user_id, FORCE_SUB_CHANNEL_ID, e
        )
        return False


# ══════════════════════════════════════════════════════════════
#   HIDDEN ANTI-SPAM HELPERS
# ══════════════════════════════════════════════════════════════
def is_real_telegram_user(user) -> bool:
    """
    Hidden 'is this a real human telegram account?' heuristic.

    Telegram offers no official 'is real' API, so we use the strongest
    practical signals:
      - reject explicit bot accounts (is_bot)
      - reject obviously invalid ids
    This runs silently; the user is never told why an action was ignored.
    """
    try:
        if getattr(user, "is_bot", False):
            return False
        if not getattr(user, "id", None) or user.id <= 0:
            return False
    except Exception:
        return False
    return True


def verify_rate_limited(user_id: int) -> bool:
    """
    Silent anti-flood for the 'verify' button. Returns True if the user is
    pressing too fast and the press should be ignored (no error shown).
    """
    now = time.time()
    last = _verify_cooldown.get(user_id, 0.0)
    if now - last < VERIFY_COOLDOWN_SECONDS:
        return True
    _verify_cooldown[user_id] = now
    return False


# ══════════════════════════════════════════════════════════════
#   REFERRAL REWARD (granted ONLY after real verification)
# ══════════════════════════════════════════════════════════════
def grant_pending_referral(bot: telebot.TeleBot, user_id: int):
    """
    Called the moment a user passes the channel check for the first time.

    If this user was invited by someone (a pending referral was stored at
    /start time) AND the referral system is enabled, credit the referrer
    exactly once, then clear the pending link so it can never be paid twice.

    Anti-fake-referral guarantees enforced here:
      - reward is paid only after a REAL subscription check
      - self-referral is impossible (stored only if ref_id != user_id)
      - paid at most once (pending row is deleted atomically)
    """
    referrer_id = get_pending_referrer(user_id)
    if not referrer_id:
        return
    if referrer_id == user_id:
        clear_pending_referrer(user_id)
        return
    if not is_referral_enabled():
        # Keep it pending in case the owner re-enables referrals later? No —
        # the user is already verified now; clear to avoid stale state.
        clear_pending_referrer(user_id)
        return

    # Atomically consume the pending link first (so a double press cannot
    # pay twice), only then credit the referrer.
    consumed = clear_pending_referrer(user_id)
    if not consumed:
        return

    reward = get_referral_reward()
    add_referral_earnings(referrer_id, reward)

    # Notify the referrer in their own language (best-effort).
    try:
        from locales.ar import AR
        from locales.en import EN
        lang = get_user_language(referrer_id)
        ref_L = AR if lang == "ar" else EN
        referrer = get_user(referrer_id)
        new_bal = referrer["balance"] if referrer else 0.0
        invited = get_user(user_id)
        invited_name = invited["full_name"] if invited else str(user_id)
        bot.send_message(
            referrer_id,
            ref_L["referral_earned"].format(
                name=invited_name,
                amount=f"{reward:.2f}",
                balance=f"{new_bal:.2f}",
            ),
        )
    except Exception as e:
        logger.warning("Failed to notify referrer %s: %s", referrer_id, e)


# ══════════════════════════════════════════════════════════════
#   ONBOARDING STATE
# ══════════════════════════════════════════════════════════════
def needs_instagram_step(user_id: int) -> bool:
    """
    True if the user has passed the channel gate but has NOT yet been shown
    the one-time Instagram step.
    """
    if user_id == OWNER_ID:
        return False
    if not INSTAGRAM_ENABLED:
        return False
    return not instagram_shown(user_id)


def complete_instagram_step(user_id: int):
    """Mark the one-time Instagram step as shown (never shown again)."""
    mark_instagram_shown(user_id)
