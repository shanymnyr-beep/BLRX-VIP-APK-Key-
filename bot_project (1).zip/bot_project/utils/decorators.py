from functools import wraps
from config import OWNER_ID
from database import is_maintenance_mode, get_user_language
from locales.ar import AR
from locales.en import EN


def _L(user_id):
    return AR if get_user_language(user_id) == "ar" else EN


def owner_only(func):
    """Decorator to restrict access to owner only."""
    @wraps(func)
    def wrapper(call, *args, **kwargs):
        if call.from_user.id != OWNER_ID:
            return
        return func(call, *args, **kwargs)
    return wrapper


# ══════════════════════════════════════════════════════════════
#   SUBSCRIPTION GATE (shared presentation helpers)
# ══════════════════════════════════════════════════════════════
def _show_join(bot, moc, is_callback, L):
    from keyboards import join_channel_keyboard
    kb = join_channel_keyboard(moc.from_user.id)
    text = L["force_sub_message"]
    if is_callback:
        try:
            bot.answer_callback_query(moc.id, L["force_sub_not_joined"], show_alert=True)
        except Exception:
            pass
        try:
            bot.edit_message_text(
                text, moc.message.chat.id, moc.message.message_id,
                reply_markup=kb, parse_mode="HTML"
            )
        except Exception:
            try:
                bot.send_message(
                    moc.message.chat.id, text,
                    reply_markup=kb, parse_mode="HTML"
                )
            except Exception:
                pass
    else:
        bot.send_message(
            moc.chat.id, text, reply_markup=kb, parse_mode="HTML"
        )


def _show_instagram(bot, moc, is_callback, L):
    from keyboards import instagram_keyboard
    kb = instagram_keyboard(moc.from_user.id)
    text = L["instagram_message"]
    chat_id = moc.message.chat.id if is_callback else moc.chat.id
    if is_callback:
        try:
            bot.answer_callback_query(moc.id)
        except Exception:
            pass
        try:
            bot.edit_message_text(
                text, chat_id, moc.message.message_id,
                reply_markup=kb, parse_mode="HTML"
            )
            return
        except Exception:
            pass
    bot.send_message(chat_id, text, reply_markup=kb, parse_mode="HTML")


def _passes_gate(bot, moc, is_callback) -> bool:
    """
    Core forced-subscription gate.

    Returns True if the user is fully onboarded (subscribed to the channel and
    the one-time Instagram step has been shown). Otherwise renders the correct
    screen and returns False.

    Owner always passes. Hidden anti-spam: bot accounts are rejected silently.
    """
    from utils.subscription import (
        is_subscribed, needs_instagram_step, grant_pending_referral,
        is_real_telegram_user,
    )

    user = moc.from_user
    user_id = user.id

    if user_id == OWNER_ID:
        return True

    # Silent anti-spam: ignore bot accounts entirely.
    if not is_real_telegram_user(user):
        if is_callback:
            try:
                bot.answer_callback_query(moc.id)
            except Exception:
                pass
        return False

    L = _L(user_id)

    # 1) Real channel membership.
    if not is_subscribed(bot, user_id):
        _show_join(bot, moc, is_callback, L)
        return False

    # Passed -> pay any pending referral exactly once.
    try:
        grant_pending_referral(bot, user_id)
    except Exception:
        pass

    # 2) One-time Instagram step.
    if needs_instagram_step(user_id):
        _show_instagram(bot, moc, is_callback, L)
        return False

    return True


def maintenance_check(bot):
    """
    Combined gate applied to every user-facing handler:

      (1) Forced-subscription gate  — channel membership + one-time Instagram.
      (2) Maintenance mode          — original behaviour.

    Because every feature handler in the bot is already wrapped with
    @maintenance_check(bot), folding the subscription gate in here guarantees a
    non-subscribed user can NEVER reach any feature, regardless of which button
    or message they send — without having to touch every handler file.

    NOTE: /start, the verify button and the instagram-done button are handled
    in handlers.start and deliberately do NOT use this decorator, so the user
    can always reach the join/verify screens.
    """
    def decorator(func):
        @wraps(func)
        def wrapper(message_or_call, *args, **kwargs):
            user_id = message_or_call.from_user.id

            # Owner bypasses everything.
            if user_id == OWNER_ID:
                return func(message_or_call, *args, **kwargs)

            is_callback = hasattr(message_or_call, 'message')

            # (1) Subscription gate FIRST.
            if not _passes_gate(bot, message_or_call, is_callback):
                return

            # (2) Maintenance mode.
            if is_maintenance_mode():
                L = _L(user_id)
                try:
                    if is_callback:
                        bot.answer_callback_query(
                            message_or_call.id,
                            L["maintenance_mode_active"],
                            show_alert=True
                        )
                    else:
                        bot.send_message(
                            message_or_call.chat.id,
                            L["maintenance_mode_message"]
                        )
                except Exception:
                    pass
                return

            return func(message_or_call, *args, **kwargs)
        return wrapper
    return decorator
