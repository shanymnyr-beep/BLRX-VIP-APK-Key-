import html
from locales.ar import AR
from locales.en import EN
from database import get_user_language


def get_text(user_id: int, key: str, **kwargs) -> str:
    lang = get_user_language(user_id)
    locale = AR if lang == "ar" else EN
    text = locale.get(key, AR.get(key, key))
    if isinstance(text, str) and kwargs:
        try:
            return text.format(**kwargs)
        except KeyError:
            return text
    return text


def get_locale(user_id: int) -> dict:
    lang = get_user_language(user_id)
    return AR if lang == "ar" else EN


def format_price(price: float) -> str:
    return f"{price:.2f}"


def esc(value) -> str:
    """
    Escape a dynamic value before inserting it into a parse_mode='HTML'
    message. Prevents broken messages when keys / names contain < > &.
    """
    if value is None:
        return ""
    return html.escape(str(value), quote=False)


def get_stock_text(count: int, locale: dict, threshold: int = 3) -> str:
    if count == 0:
        return locale["out_of_stock"]
    elif count <= threshold:
        return locale["low_stock"].format(count=count)
    else:
        return locale["in_stock"]
