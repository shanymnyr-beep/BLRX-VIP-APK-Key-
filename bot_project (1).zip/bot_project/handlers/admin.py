import telebot
import uuid
import time
import threading
from telebot.types import CallbackQuery, Message
from datetime import datetime, timedelta
from config import OWNER_ID
from database import (
    get_all_mods, get_mod_by_id, add_mod, update_mod_name, delete_mod,
    add_keys, add_file_product, get_mod_keys_info, get_keys_summary,
    get_setting, set_setting, get_referral_reward,
    get_open_tickets, get_ticket, close_ticket,
    create_gift_link, get_all_users_count, get_total_sales,
    get_total_available_keys, get_open_tickets_count,
    get_user, update_balance, get_all_user_ids, get_all_users_with_balance,
    get_all_payment_methods, get_payment_method, add_payment_method,
    delete_payment_method, toggle_payment_method,
    is_maintenance_mode, set_maintenance_mode,
    is_force_sub_enabled, set_force_sub_enabled,
    get_recharge_commission_rate, set_recharge_commission_rate,
    add_recharge_commission, get_user_referrer,
    is_referral_enabled, set_referral_enabled,
    is_commission_enabled, set_commission_enabled,
    update_keys_price, get_keys_by_duration_price,
    get_top_users_by_balance, get_user_rank,
    create_coupon, get_spin_settings, update_spin_setting,
    get_user_language,
    export_backup, get_backup_stats
)
from keyboards import (
    admin_keyboard, admin_mods_keyboard, admin_mod_actions_keyboard,
    confirm_delete_keyboard, admin_select_mod_for_key,
    duration_keyboard, product_type_keyboard,
    ticket_reply_keyboard, back_keyboard,
    admin_payment_methods_keyboard, admin_payment_actions_keyboard,
    confirm_delete_payment_keyboard, broadcast_confirm_keyboard,
    settings_keyboard, maintenance_keyboard, force_sub_keyboard,
    duration_price_select_keyboard, coupon_type_keyboard,
    recharge_commission_keyboard, referral_system_keyboard,
    spin_wheel_settings_keyboard
)
from utils.helpers import get_locale, esc
from utils.decorators import owner_only

# ── Admin States ──────────────────────────────────────────────
_admin_states = {}


def _set_state(state: str, **data):
    _admin_states[OWNER_ID] = {"state": state, "data": data}


def _get_state() -> dict:
    return _admin_states.get(OWNER_ID, {})


def _clear_state():
    _admin_states.pop(OWNER_ID, None)


# ── Broadcast Helper ──────────────────────────────────────────
def _do_broadcast(bot, user_ids: list, message_text: str,
                  photo_id: str = None, chat_id: int = None):
    """Run broadcast in background thread."""
    success = 0
    failed  = 0

    for uid in user_ids:
        try:
            if photo_id:
                bot.send_photo(uid, photo_id, caption=message_text)
            else:
                bot.send_message(uid, message_text)
            success += 1
        except Exception:
            failed += 1
        time.sleep(0.03)   # 30ms delay - fast but safe

    if chat_id:
        L = get_locale(OWNER_ID)
        try:
            bot.send_message(
                chat_id,
                L["broadcast_completed"].format(
                    success=success,
                    failed=failed,
                    total=len(user_ids)
                ),
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
        except Exception:
            pass


def register_admin_handlers(bot: telebot.TeleBot):

    # ══════════════════════════════════════════
    #           ADMIN PANEL
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_backup")
    @owner_only
    def cb_backup(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        bot.answer_callback_query(call.id, "⏳")
        try:
            path  = export_backup("bot_data_backup.db")
            stats = get_backup_stats()
            caption = L["backup_caption"].format(
                users=stats["users"],
                balance=f"{stats['balance']:.2f}",
                purchases=stats["purchases"],
                keys=stats["keys"],
                mods=stats["mods"]
            )
            with open(path, "rb") as f:
                bot.send_document(
                    call.message.chat.id, f,
                    visible_file_name="bot_data_backup.db",
                    caption=caption
                )
        except Exception as e:
            bot.send_message(
                call.message.chat.id,
                L["backup_failed"].format(error=str(e)[:200])
            )

    @bot.callback_query_handler(func=lambda c: c.data == "admin")
    @owner_only
    def cb_admin(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _clear_state()
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["admin_panel"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_keyboard(OWNER_ID)
        )

    # ══════════════════════════════════════════
    #           ADD MOD
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_add_mod")
    @owner_only
    def cb_add_mod(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("add_mod")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_mod_name"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           MANAGE MODS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_manage_mods")
    @owner_only
    def cb_manage_mods(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        mods = get_all_mods()
        bot.answer_callback_query(call.id)
        if not mods:
            bot.edit_message_text(
                L["no_mods"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
            return
        bot.edit_message_text(
            L["select_mod_to_manage"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_mods_keyboard(mods, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_mod_"))
    @owner_only
    def cb_mod_actions(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[2])
        except (IndexError, ValueError):
            return
        mod = get_mod_by_id(mod_id)
        if not mod:
            bot.answer_callback_query(call.id, L["error"])
            return
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["mod_actions"].format(name=mod["name"]),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_mod_actions_keyboard(mod_id, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_edit_mod_"))
    @owner_only
    def cb_edit_mod(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        _set_state("edit_mod", mod_id=mod_id)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_new_mod_name"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, f"adm_mod_{mod_id}")
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_del_mod_"))
    @owner_only
    def cb_delete_mod_confirm(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        mod = get_mod_by_id(mod_id)
        if not mod:
            bot.answer_callback_query(call.id, L["error"])
            return
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["confirm_delete_mod"].format(name=mod["name"]),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=confirm_delete_keyboard(mod_id, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_confirm_del_")
                                 and not c.data.startswith("adm_confirm_del_payment_"))
    @owner_only
    def cb_confirm_delete_mod(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        delete_mod(mod_id)
        bot.answer_callback_query(call.id, L["mod_deleted"])
        mods = get_all_mods()
        bot.edit_message_text(
            L["mod_deleted"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_mods_keyboard(mods, OWNER_ID)
            if mods else back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           VIEW KEYS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_view_keys_")
        and not c.data.startswith("adm_view_keys_detail_")
    )
    @owner_only
    def cb_view_keys(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        mod       = get_mod_by_id(mod_id)
        keys_info = get_mod_keys_info(mod_id)

        if not keys_info:
            text = f"🎮 {mod['name']}\n\n📭 لا توجد منتجات."
        else:
            text = f"🎮 {mod['name']}\n━━━━━━━━━━━━━━━━━━━━━━\n"
            for row in keys_info:
                icon = "🔑" if row["product_type"] == "key" else "📁"
                text += (
                    f"{icon} {row['duration']} يوم | "
                    f"${row['price']:.2f}\n"
                    f"   ✅ متاح: {row['available']} | "
                    f"📦 الكل: {row['total']}\n\n"
                )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, f"adm_mod_{mod_id}")
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_view_keys_detail_")
    )
    @owner_only
    def cb_view_keys_detail(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[4])
        except (IndexError, ValueError):
            return
        keys_info = get_mod_keys_info(mod_id)
        if not keys_info:
            bot.answer_callback_query(call.id, L["no_keys_available"])
            return
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["select_duration"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=duration_price_select_keyboard(
                mod_id, keys_info, OWNER_ID, "view"
            )
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_keys_view_"))
    @owner_only
    def cb_keys_view_detail(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            parts    = call.data.split("_")
            mod_id   = int(parts[3])
            duration = int(parts[4])
            price    = float(parts[5])
        except (IndexError, ValueError):
            return

        mod  = get_mod_by_id(mod_id)
        keys = get_keys_by_duration_price(mod_id, duration, price, limit=50)

        if not keys:
            bot.answer_callback_query(call.id, L["no_keys_available"])
            return

        preview = ""
        for key in keys:
            ptype = key["product_type"]
            if ptype == "file":
                if key["is_sold"]:
                    preview += L["file_item_sold"].format(
                        date=key["sold_at"][:10] if key["sold_at"] else "N/A"
                    ) + "\n"
                else:
                    preview += L["file_item_available"] + "\n"
            else:
                if key["is_sold"]:
                    preview += L["key_item_sold"].format(
                        key=esc(key["key_value"]),
                        date=key["sold_at"][:10] if key["sold_at"] else "N/A"
                    ) + "\n"
                else:
                    preview += L["key_item_available"].format(
                        key=esc(key["key_value"])
                    ) + "\n"

        text = L["keys_list_title"].format(
            mod_name=esc(mod["name"]),
            days=duration,
            price=f"{price:.2f}",
            keys_preview=preview.strip(),
            total=len(keys)
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=back_keyboard(OWNER_ID, f"adm_view_keys_detail_{mod_id}")
        )

    # ══════════════════════════════════════════
    #           EDIT KEY PRICES
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_edit_price_"))
    @owner_only
    def cb_edit_price_select(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        keys_info = get_mod_keys_info(mod_id)
        if not keys_info:
            bot.answer_callback_query(call.id, L["no_keys_to_update"])
            return
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["select_duration_edit"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=duration_price_select_keyboard(
                mod_id, keys_info, OWNER_ID, "price"
            )
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_price_select_"))
    @owner_only
    def cb_price_select(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            parts     = call.data.split("_")
            mod_id    = int(parts[3])
            duration  = int(parts[4])
            old_price = float(parts[5])
        except (IndexError, ValueError):
            return
        _set_state("edit_key_price",
                   mod_id=mod_id,
                   duration=duration,
                   old_price=old_price)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_new_price"].format(old_price=f"{old_price:.2f}"),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, f"adm_edit_price_{mod_id}")
        )

    # ══════════════════════════════════════════
    #     ADD PRODUCT (KEY or FILE) - NEW FLOW
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_add_key")
    @owner_only
    def cb_add_key(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        mods = get_all_mods()
        bot.answer_callback_query(call.id)
        if not mods:
            bot.edit_message_text(
                L["no_mods_for_key"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
            return
        bot.edit_message_text(
            L["select_mod_for_key"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_select_mod_for_key(mods, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_key_mod_"))
    @owner_only
    def cb_key_select_mod(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            mod_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        mod = get_mod_by_id(mod_id)
        if not mod:
            bot.answer_callback_query(call.id, L["error"])
            return
        _set_state("key_select_duration",
                   mod_id=mod_id,
                   mod_name=mod["name"])
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["select_duration"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=duration_keyboard(mod_id, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_dur_"))
    @owner_only
    def cb_key_select_duration(call: CallbackQuery):
        """After selecting duration → show product type selection."""
        L = get_locale(OWNER_ID)
        try:
            parts    = call.data.split("_")
            mod_id   = int(parts[2])
            duration = int(parts[3])
        except (IndexError, ValueError):
            return

        state    = _get_state()
        mod_name = state.get("data", {}).get("mod_name", "")

        _set_state("key_select_type",
                   mod_id=mod_id,
                   mod_name=mod_name,
                   duration=duration)

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["select_product_type"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=product_type_keyboard(mod_id, duration, OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_ptype_key_"))
    @owner_only
    def cb_product_type_key(call: CallbackQuery):
        """Selected KEY → ask for price."""
        L = get_locale(OWNER_ID)
        try:
            parts    = call.data.split("_")
            mod_id   = int(parts[3])
            duration = int(parts[4])
        except (IndexError, ValueError):
            return

        state    = _get_state()
        mod_name = state.get("data", {}).get("mod_name", "")

        _set_state("key_enter_price",
                   mod_id=mod_id,
                   mod_name=mod_name,
                   duration=duration)

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_price"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_ptype_file_"))
    @owner_only
    def cb_product_type_file(call: CallbackQuery):
        """Selected FILE → ask for price first."""
        L = get_locale(OWNER_ID)
        try:
            parts    = call.data.split("_")
            mod_id   = int(parts[3])
            duration = int(parts[4])
        except (IndexError, ValueError):
            return

        state    = _get_state()
        mod_name = state.get("data", {}).get("mod_name", "")

        _set_state("file_enter_price",
                   mod_id=mod_id,
                   mod_name=mod_name,
                   duration=duration)

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_file_price"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
        )
            # ══════════════════════════════════════════
    #           REFERRAL SETTINGS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_ref_set")
    @owner_only
    def cb_ref_set(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        reward = get_referral_reward()
        _set_state("set_referral")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["current_ref_reward"].format(reward=f"{reward:.2f}"),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           TICKETS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_tickets")
    @owner_only
    def cb_tickets(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        tickets = get_open_tickets()
        bot.answer_callback_query(call.id)

        if not tickets:
            bot.edit_message_text(
                L["no_tickets"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
            return

        bot.edit_message_text(
            f"🎫 التذاكر المفتوحة ({len(tickets)}):",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

        for ticket in tickets:
            text = L["ticket_item"].format(
                ticket_id=ticket["ticket_id"],
                user_name=ticket["full_name"],
                user_id=ticket["user_id"],
                date=ticket["created_at"],
                message=ticket["message"]
            )
            kb = ticket_reply_keyboard(ticket["ticket_id"], OWNER_ID)
            try:
                if ticket["photo_id"]:
                    bot.send_photo(
                        call.message.chat.id,
                        ticket["photo_id"],
                        caption=text,
                        reply_markup=kb
                    )
                else:
                    bot.send_message(
                        call.message.chat.id,
                        text,
                        reply_markup=kb
                    )
            except Exception:
                pass

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_reply_"))
    @owner_only
    def cb_reply_ticket(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            ticket_id = int(call.data.split("_")[2])
        except (IndexError, ValueError):
            return
        _set_state("reply_ticket", ticket_id=ticket_id)
        bot.answer_callback_query(call.id)
        bot.send_message(
            call.message.chat.id,
            L["enter_reply"].format(ticket_id=ticket_id),
            reply_markup=back_keyboard(OWNER_ID, "adm_tickets")
        )

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_close_"))
    @owner_only
    def cb_close_ticket(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            ticket_id = int(call.data.split("_")[2])
        except (IndexError, ValueError):
            return
        close_ticket(ticket_id)
        bot.answer_callback_query(call.id, L["ticket_closed"])
        try:
            bot.edit_message_reply_markup(
                call.message.chat.id,
                call.message.message_id,
                reply_markup=None
            )
        except Exception:
            pass

    # ══════════════════════════════════════════
    #           PAYMENT METHODS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_payments")
    @owner_only
    def cb_admin_payments(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["payment_methods_list"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_payment_methods_keyboard(OWNER_ID)
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_payment_")
        and not c.data.startswith("adm_payments")
        and not c.data.startswith("adm_payment_method")
    )
    @owner_only
    def cb_payment_detail(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            method_id = int(call.data.split("_")[2])
        except (IndexError, ValueError):
            return

        method = get_payment_method(method_id)
        if not method:
            bot.answer_callback_query(call.id, L["error"])
            return

        status = "✅ مفعّل" if method["is_active"] else "❌ معطّل"
        text = (
            f"💳 {method['name_ar']}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🔄 الحالة: {status}\n"
            f"📝 التعليمات:\n{method['instructions_ar'] or 'لا توجد'}"
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_payment_actions_keyboard(method_id, OWNER_ID)
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_toggle_payment_")
    )
    @owner_only
    def cb_toggle_payment(call: CallbackQuery):
        try:
            method_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        toggle_payment_method(method_id)
        bot.answer_callback_query(call.id, "✅ تم التحديث")
        cb_payment_detail(call)

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_del_payment_")
    )
    @owner_only
    def cb_delete_payment_confirm(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            method_id = int(call.data.split("_")[3])
        except (IndexError, ValueError):
            return
        method = get_payment_method(method_id)
        if not method:
            bot.answer_callback_query(call.id, L["error"])
            return
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["confirm_delete_payment"].format(name=method["name_ar"]),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=confirm_delete_payment_keyboard(method_id, OWNER_ID)
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("adm_confirm_del_payment_")
    )
    @owner_only
    def cb_confirm_delete_payment(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        try:
            method_id = int(call.data.split("_")[4])
        except (IndexError, ValueError):
            return
        delete_payment_method(method_id)
        bot.answer_callback_query(call.id, L["payment_method_deleted"])
        bot.edit_message_text(
            L["payment_method_deleted"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_payment_methods_keyboard(OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_add_payment")
    @owner_only
    def cb_add_payment_start(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("add_payment_name_ar")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_method_name_ar"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_payments")
        )

    # ══════════════════════════════════════════
    #           GIFT LINKS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_gift")
    @owner_only
    def cb_gift(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("gift_amount")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["gift_link_setup"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           BROADCAST
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_broadcast")
    @owner_only
    def cb_broadcast(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("broadcast_message")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["broadcast_prompt"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_broadcast_send")
    @owner_only
    def cb_broadcast_send(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        state        = _get_state()
        message_text = state.get("data", {}).get("message")
        photo_id     = state.get("data", {}).get("photo_id")

        if not message_text and not photo_id:
            bot.answer_callback_query(call.id, L["error"])
            return

        _clear_state()

        # Get ALL users including old ones
        user_ids = get_all_user_ids()

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["broadcast_started"],
            call.message.chat.id,
            call.message.message_id
        )

        # Run in background thread so bot stays responsive
        t = threading.Thread(
            target=_do_broadcast,
            args=(bot, user_ids, message_text, photo_id,
                  call.message.chat.id),
            daemon=True
        )
        t.start()

    # ══════════════════════════════════════════
    #           LEADERBOARD
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_leaderboard")
    @owner_only
    def cb_leaderboard(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        top_users = get_top_users_by_balance(limit=15, min_balance=0.50)

        if not top_users:
            bot.answer_callback_query(call.id)
            bot.edit_message_text(
                L["leaderboard_empty"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
            return

        medals = ["🥇", "🥈", "🥉"]
        text   = L["leaderboard_title"] + "\n\n"

        for idx, user in enumerate(top_users, 1):
            rank_emoji = medals[idx - 1] if idx <= 3 else f"{idx}️⃣"
            name       = user["full_name"]
            if len(name) > 20:
                name = name[:17] + "..."
            username = f"@{user['username']}" if user["username"] else "—"

            text += L["leaderboard_item"].format(
                rank=rank_emoji,
                name=name,
                user_id=user["user_id"],
                username=username,
                balance=f"{user['balance']:.2f}",
                spent=f"{user['total_spent']:.2f}"
            ) + "\n\n"

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           CREATE COUPONS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_create_coupon")
    @owner_only
    def cb_create_coupon(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["coupon_type_select"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=coupon_type_keyboard(OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_coupon_balance")
    @owner_only
    def cb_coupon_balance(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("coupon_balance")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_coupon_balance"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_create_coupon")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_coupon_discount")
    @owner_only
    def cb_coupon_discount(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("coupon_discount")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_coupon_discount"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_create_coupon")
        )

    # ══════════════════════════════════════════
    #           STATISTICS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_stats")
    @owner_only
    def cb_stats(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        users          = get_all_users_count()
        sales, revenue = get_total_sales()
        keys           = get_total_available_keys()
        tickets        = get_open_tickets_count()

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["stats_title"].format(
                users=users,
                sales=sales,
                revenue=f"{revenue:.2f}",
                keys=keys,
                tickets=tickets
            ),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           ADD / DEDUCT BALANCE
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_add_balance")
    @owner_only
    def cb_adm_add_balance(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("add_balance_uid")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_user_id_balance"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_deduct_balance")
    @owner_only
    def cb_adm_deduct_balance(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("deduct_balance_uid")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_user_id_balance"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           DM USER (NEW)
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_dm_user")
    @owner_only
    def cb_dm_user(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("dm_user_id")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["dm_user_prompt"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "admin")
        )

    # ══════════════════════════════════════════
    #           SETTINGS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_settings")
    @owner_only
    def cb_settings(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["settings_menu"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=settings_keyboard(OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_maintenance")
    @owner_only
    def cb_maintenance(call: CallbackQuery):
        L         = get_locale(OWNER_ID)
        is_active = is_maintenance_mode()
        status    = L["status_active"] if is_active else L["status_inactive"]
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["maintenance_status"].format(status=status),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=maintenance_keyboard(OWNER_ID, is_active)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_maintenance_toggle")
    @owner_only
    def cb_maintenance_toggle(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        current    = is_maintenance_mode()
        new_status = not current
        set_maintenance_mode(new_status)

        msg = L["maintenance_enabled"] if new_status else L["maintenance_disabled"]
        bot.answer_callback_query(call.id, msg)

        # Send notification to all users when maintenance ends
        if not new_status:
            t = threading.Thread(
                target=_notify_maintenance_complete,
                args=(bot,),
                daemon=True
            )
            t.start()

        cb_maintenance(call)

    def _notify_maintenance_complete(bot):
        """Notify all users maintenance is done - runs in background."""
        from locales.ar import AR
        from locales.en import EN
        user_ids = get_all_user_ids()
        for uid in user_ids:
            if uid == OWNER_ID:
                continue
            try:
                lang = get_user_language(uid)
                L    = AR if lang == "ar" else EN
                bot.send_message(uid, L["maintenance_complete_message"])
            except Exception:
                pass
            time.sleep(0.03)

    # ══════════════════════════════════════════
    #        FORCED SUBSCRIPTION (NEW)
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_force_sub")
    @owner_only
    def cb_force_sub(call: CallbackQuery):
        L         = get_locale(OWNER_ID)
        is_active = is_force_sub_enabled()
        status    = L["status_active"] if is_active else L["status_inactive"]
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["force_sub_status"].format(status=status),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=force_sub_keyboard(OWNER_ID, is_active)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_force_sub_toggle")
    @owner_only
    def cb_force_sub_toggle(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        new_status = not is_force_sub_enabled()
        set_force_sub_enabled(new_status)
        msg = L["force_sub_enabled_msg"] if new_status else L["force_sub_disabled_msg"]
        bot.answer_callback_query(call.id, msg)
        cb_force_sub(call)

    @bot.callback_query_handler(func=lambda c: c.data == "adm_recharge_commission")
    @owner_only
    def cb_recharge_commission(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        rate       = get_recharge_commission_rate()
        is_enabled = is_commission_enabled()
        status     = L["status_active"] if is_enabled else L["status_inactive"]
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["recharge_commission_status"].format(
                status=status,
                rate=f"{rate:.1f}"
            ),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=recharge_commission_keyboard(OWNER_ID, is_enabled)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_edit_commission")
    @owner_only
    def cb_edit_commission(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("edit_commission_rate")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_commission_rate"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_recharge_commission")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_toggle_commission")
    @owner_only
    def cb_toggle_commission(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        new_status = not is_commission_enabled()
        set_commission_enabled(new_status)
        msg = L["commission_enabled"] if new_status else L["commission_disabled"]
        bot.answer_callback_query(call.id, msg)
        cb_recharge_commission(call)

    @bot.callback_query_handler(func=lambda c: c.data == "adm_referral_system")
    @owner_only
    def cb_referral_system(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        reward     = get_referral_reward()
        is_enabled = is_referral_enabled()
        status     = L["status_active"] if is_enabled else L["status_inactive"]
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["referral_system_status"].format(
                status=status,
                reward=f"{reward:.2f}"
            ),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=referral_system_keyboard(OWNER_ID, is_enabled)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_edit_referral")
    @owner_only
    def cb_edit_referral(call: CallbackQuery):
        L      = get_locale(OWNER_ID)
        reward = get_referral_reward()
        _set_state("edit_referral_reward")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["current_ref_reward"].format(reward=f"{reward:.2f}"),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_referral_system")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_toggle_referral")
    @owner_only
    def cb_toggle_referral(call: CallbackQuery):
        L          = get_locale(OWNER_ID)
        new_status = not is_referral_enabled()
        set_referral_enabled(new_status)
        msg = L["referral_enabled"] if new_status else L["referral_disabled"]
        bot.answer_callback_query(call.id, msg)
        cb_referral_system(call)

    @bot.callback_query_handler(func=lambda c: c.data == "adm_spin_wheel")
    @owner_only
    def cb_spin_wheel_settings(call: CallbackQuery):
        L        = get_locale(OWNER_ID)
        settings = get_spin_settings()
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["spin_wheel_settings"].format(
                no_prize=f"{settings['no_prize']:.0f}",
                balance=f"{settings['balance']:.0f}",
                discount5=f"{settings['discount5']:.0f}",
                discount7=f"{settings['discount7']:.0f}",
                balance_value=f"{settings['balance_value']:.2f}"
            ),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=spin_wheel_settings_keyboard(OWNER_ID)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_edit_spin_chances")
    @owner_only
    def cb_edit_spin_chances(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("edit_spin_chances")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_spin_chances"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_spin_wheel")
        )

    @bot.callback_query_handler(func=lambda c: c.data == "adm_edit_spin_balance")
    @owner_only
    def cb_edit_spin_balance(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _set_state("edit_spin_balance_value")
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["enter_spin_balance_value"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_spin_wheel")
        )

    # ══════════════════════════════════════════
    #      BALANCE MESSAGE (NEW)
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "adm_balance_msg")
    @owner_only
    def cb_balance_msg(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["balance_msg_prompt"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(OWNER_ID, "adm_settings")
        )
        _set_state("confirm_balance_msg")

    @bot.callback_query_handler(func=lambda c: c.data == "adm_balance_msg_send")
    @owner_only
    def cb_balance_msg_send(call: CallbackQuery):
        L = get_locale(OWNER_ID)
        _clear_state()

        users = get_all_users_with_balance()

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["balance_msg_started"],
            call.message.chat.id,
            call.message.message_id
        )

        t = threading.Thread(
            target=_send_balance_messages,
            args=(bot, users, call.message.chat.id),
            daemon=True
        )
        t.start()

    def _send_balance_messages(bot, users: list, chat_id: int):
        """Send balance info to all users with balance > 0."""
        from locales.ar import AR
        from locales.en import EN
        success = 0
        failed  = 0

        for user in users:
            try:
                lang = user["language"] if user["language"] else "ar"
                L    = AR if lang == "ar" else EN
                text = L["balance_msg_template"].format(
                    user_id=user["user_id"],
                    balance=f"{user['balance']:.2f}",
                    ref_count=user["ref_count"]
                )
                bot.send_message(
                    user["user_id"],
                    text,
                    parse_mode="HTML"
                )
                success += 1
            except Exception:
                failed += 1
            time.sleep(0.03)

        try:
            L = get_locale(OWNER_ID)
            bot.send_message(
                chat_id,
                L["balance_msg_done"].format(
                    success=success,
                    failed=failed
                ),
                reply_markup=back_keyboard(OWNER_ID, "adm_settings")
            )
        except Exception:
            pass

    # ══════════════════════════════════════════
    #     MAIN MESSAGE HANDLER (Admin States)
    # ══════════════════════════════════════════

    @bot.message_handler(
        func=lambda m: m.from_user.id == OWNER_ID and OWNER_ID in _admin_states,
        content_types=["text", "photo", "document"]
    )
    def handle_admin_input(msg: Message):
        L          = get_locale(OWNER_ID)
        state_data = _get_state()
        state      = state_data.get("state")
        data       = state_data.get("data", {})

        # ── Extract content ───────────────────
        if msg.content_type == "photo":
            text     = msg.caption or ""
            photo_id = msg.photo[-1].file_id
            doc_id   = None
            doc_name = None
        elif msg.content_type == "document":
            text     = msg.caption or ""
            photo_id = None
            doc_id   = msg.document.file_id
            doc_name = msg.document.file_name or "file"
        else:
            text     = msg.text.strip() if msg.text else ""
            photo_id = None
            doc_id   = None
            doc_name = None

        # ── Cancel ────────────────────────────
        if text.lower() in ("/cancel", "cancel", "إلغاء"):
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["operation_cancelled"],
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )
            return

        # ══════════════════════════════════════
        #   MOD MANAGEMENT
        # ══════════════════════════════════════

        if state == "add_mod":
            success = add_mod(text)
            _clear_state()
            if success:
                bot.send_message(
                    msg.chat.id,
                    L["mod_added"].format(name=text),
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )
            else:
                bot.send_message(
                    msg.chat.id,
                    L["mod_exists"],
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )

        elif state == "edit_mod":
            mod_id  = data.get("mod_id")
            success = update_mod_name(mod_id, text)
            _clear_state()
            if success:
                bot.send_message(
                    msg.chat.id,
                    L["mod_updated"],
                    reply_markup=back_keyboard(OWNER_ID, "adm_manage_mods")
                )
            else:
                bot.send_message(
                    msg.chat.id,
                    L["mod_exists"],
                    reply_markup=back_keyboard(OWNER_ID, f"adm_mod_{mod_id}")
                )

        # ══════════════════════════════════════
        #   KEY PRODUCT FLOW
        # ══════════════════════════════════════

        elif state == "key_enter_price":
            try:
                price = float(text)
                if price <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_price"])
                return

            mod_id   = data.get("mod_id")
            mod_name = data.get("mod_name")
            duration = data.get("duration")

            _set_state("key_enter_values",
                       mod_id=mod_id,
                       mod_name=mod_name,
                       duration=duration,
                       price=price)

            bot.send_message(
                msg.chat.id,
                L["enter_keys"].format(
                    mod_name=mod_name,
                    days=duration,
                    price=f"{price:.2f}"
                ),
                reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
            )

        elif state == "key_enter_values":
            mod_id   = data.get("mod_id")
            duration = data.get("duration")
            price    = data.get("price")
            key_list = [k.strip() for k in text.split("\n") if k.strip()]
            added, _ = add_keys(mod_id, duration, price, key_list)
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["keys_added"].format(count=added),
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   FILE PRODUCT FLOW
        # ══════════════════════════════════════

        elif state == "file_enter_price":
            try:
                price = float(text)
                if price <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_price"])
                return

            mod_id   = data.get("mod_id")
            mod_name = data.get("mod_name")
            duration = data.get("duration")

            _set_state("file_enter_quantity",
                       mod_id=mod_id,
                       mod_name=mod_name,
                       duration=duration,
                       price=price)

            bot.send_message(
                msg.chat.id,
                L["enter_file_quantity"],
                reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
            )

        elif state == "file_enter_quantity":
            try:
                quantity = int(text)
                if quantity <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_quantity"])
                return

            mod_id   = data.get("mod_id")
            mod_name = data.get("mod_name")
            duration = data.get("duration")
            price    = data.get("price")

            _set_state("file_enter_description",
                       mod_id=mod_id,
                       mod_name=mod_name,
                       duration=duration,
                       price=price,
                       quantity=quantity)

            bot.send_message(
                msg.chat.id,
                L["enter_file_description"],
                reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
            )

        elif state == "file_enter_description":
            mod_id      = data.get("mod_id")
            mod_name    = data.get("mod_name")
            duration    = data.get("duration")
            price       = data.get("price")
            quantity    = data.get("quantity")
            description = None if text.lower() == "skip" else text

            _set_state("file_send_file",
                       mod_id=mod_id,
                       mod_name=mod_name,
                       duration=duration,
                       price=price,
                       quantity=quantity,
                       description=description)

            bot.send_message(
                msg.chat.id,
                L["send_file_now"].format(
                    mod_name=mod_name,
                    days=duration,
                    price=f"{price:.2f}",
                    quantity=quantity
                ),
                reply_markup=back_keyboard(OWNER_ID, "adm_add_key")
            )

        elif state == "file_send_file":
            # Must receive a document or photo
            if not doc_id and not photo_id:
                bot.send_message(msg.chat.id, L["file_not_sent"])
                return

            mod_id      = data.get("mod_id")
            mod_name    = data.get("mod_name")
            duration    = data.get("duration")
            price       = data.get("price")
            quantity    = data.get("quantity")
            description = data.get("description")

            # Use doc_id if document, photo_id if photo
            file_id   = doc_id if doc_id else photo_id
            file_name = doc_name if doc_name else "photo"

            success = add_file_product(
                mod_id, duration, price,
                file_id, file_name,
                quantity, description
            )
            _clear_state()

            if success:
                bot.send_message(
                    msg.chat.id,
                    L["file_product_added"].format(
                        file_name=file_name,
                        price=f"{price:.2f}",
                        quantity=quantity,
                        description=description or "—"
                    ),
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )
            else:
                bot.send_message(
                    msg.chat.id,
                    L["error"],
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )

        # ══════════════════════════════════════
        #   EDIT KEY PRICE
        # ══════════════════════════════════════

        elif state == "edit_key_price":
            try:
                new_price = float(text)
                if new_price <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_price"])
                return

            mod_id    = data.get("mod_id")
            duration  = data.get("duration")
            old_price = data.get("old_price")
            count     = update_keys_price(mod_id, duration, old_price, new_price)
            _clear_state()

            if count > 0:
                bot.send_message(
                    msg.chat.id,
                    L["price_updated"].format(
                        count=count,
                        new_price=f"{new_price:.2f}"
                    ),
                    reply_markup=back_keyboard(OWNER_ID, f"adm_mod_{mod_id}")
                )
            else:
                bot.send_message(
                    msg.chat.id,
                    L["no_keys_to_update"],
                    reply_markup=back_keyboard(OWNER_ID, f"adm_mod_{mod_id}")
                )

        # ══════════════════════════════════════
        #   REFERRAL REWARD
        # ══════════════════════════════════════

        elif state in ("set_referral", "edit_referral_reward"):
            try:
                reward = float(text)
                if reward < 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_reward"])
                return

            set_setting("referral_reward", str(reward))
            _clear_state()
            target = "adm_referral_system" if state == "edit_referral_reward" else "admin"
            bot.send_message(
                msg.chat.id,
                L["reward_updated"].format(reward=f"{reward:.2f}"),
                reply_markup=back_keyboard(OWNER_ID, target)
            )

        # ══════════════════════════════════════
        #   REPLY TICKET
        # ══════════════════════════════════════

        elif state == "reply_ticket":
            ticket_id = data.get("ticket_id")
            ticket    = get_ticket(ticket_id)
            _clear_state()

            if not ticket:
                bot.send_message(msg.chat.id, L["error"])
                return

            target_uid = ticket["user_id"]

            try:
                from locales.ar import AR
                from locales.en import EN
                lang       = get_user_language(target_uid)
                user_L     = AR if lang == "ar" else EN
                reply_text = user_L["support_reply"].format(message=text)
                bot.send_message(target_uid, reply_text)
            except Exception as e:
                bot.send_message(
                    msg.chat.id,
                    f"❌ فشل إرسال الرد: {e}"
                )
                return

            close_ticket(ticket_id)
            bot.send_message(
                msg.chat.id,
                L["reply_sent"],
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   GIFT LINK
        # ══════════════════════════════════════

        elif state == "gift_amount":
            try:
                amount = float(text)
                if amount <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_amount"])
                return
            _set_state("gift_uses", amount=amount)
            bot.send_message(msg.chat.id, L["gift_enter_uses"])

        elif state == "gift_uses":
            try:
                max_uses = int(text)
                if max_uses < 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["error"])
                return
            amount = data.get("amount")
            _set_state("gift_expiry", amount=amount, max_uses=max_uses)
            bot.send_message(msg.chat.id, L["gift_enter_expiry"])

        elif state == "gift_expiry":
            try:
                hours = int(text)
                if hours < 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["error"])
                return

            amount   = data.get("amount")
            max_uses = data.get("max_uses")
            link_id  = str(uuid.uuid4())[:8].upper()

            expires_at = None
            if hours > 0:
                expires_at = (
                    datetime.now() + timedelta(hours=hours)
                ).isoformat()

            create_gift_link(link_id, amount, max_uses, expires_at)
            _clear_state()

            bot_info   = bot.get_me()
            link       = f"https://t.me/{bot_info.username}?start=gift_{link_id}"
            uses_text  = str(max_uses) if max_uses > 0 else "∞"
            expiry_text = f"{hours} ساعة" if hours > 0 else "∞"

            bot.send_message(
                msg.chat.id,
                L["gift_created"].format(
                    link=link,
                    amount=f"{amount:.2f}",
                    uses=uses_text,
                    expiry=expiry_text
                ),
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   ADD BALANCE (WITH COMMISSION)
        # ══════════════════════════════════════

        elif state == "add_balance_uid":
            try:
                target_id = int(text)
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            user = get_user(target_id)
            if not user:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            _set_state("add_balance_amount",
                       target_id=target_id,
                       target_name=user["full_name"])
            bot.send_message(
                msg.chat.id,
                L["enter_amount_balance"] +
                f"\n👤 {user['full_name']} (ID: {target_id})"
            )

        elif state == "add_balance_amount":
            try:
                amount = float(text)
                if amount <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_amount"])
                return

            target_id   = data.get("target_id")
            target_name = data.get("target_name")

            # Add balance to user
            update_balance(target_id, amount)

            # Notify user of balance addition (in their language)
            try:
                from locales.ar import AR
                from locales.en import EN
                lang   = get_user_language(target_id)
                user_L = AR if lang == "ar" else EN
                user   = get_user(target_id)
                bot.send_message(
                    target_id,
                    user_L["balance_added_notification"].format(
                        amount=f"{amount:.2f}",
                        balance=f"{user['balance']:.2f}"
                    )
                )
            except Exception:
                pass

            # Commission for referrer
            referrer_id       = get_user_referrer(target_id)
            commission_given  = False
            commission_amount = 0

            if referrer_id and is_commission_enabled():
                commission_rate   = get_recharge_commission_rate()
                commission_amount = add_recharge_commission(
                    referrer_id, amount, commission_rate
                )
                commission_given  = True

                # Notify referrer in their language
                try:
                    from locales.ar import AR
                    from locales.en import EN
                    ref_lang = get_user_language(referrer_id)
                    ref_L    = AR if ref_lang == "ar" else EN
                    bot.send_message(
                        referrer_id,
                        ref_L["commission_earned"].format(
                            name=target_name,
                            recharge=f"{amount:.2f}",
                            rate=f"{commission_rate:.1f}",
                            amount=f"{commission_amount:.2f}"
                        )
                    )
                except Exception:
                    pass

            _clear_state()

            response = L["balance_added"].format(
                amount=f"{amount:.2f}",
                name=target_name
            )
            if commission_given:
                response += (
                    f"\n\n💼 تم إعطاء عمولة "
                    f"${commission_amount:.2f} للمُحيل"
                )

            bot.send_message(
                msg.chat.id,
                response,
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   DEDUCT BALANCE
        # ══════════════════════════════════════

        elif state == "deduct_balance_uid":
            try:
                target_id = int(text)
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            user = get_user(target_id)
            if not user:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            _set_state("deduct_balance_amount",
                       target_id=target_id,
                       target_name=user["full_name"],
                       current_balance=user["balance"])
            bot.send_message(
                msg.chat.id,
                L["enter_amount_deduct"] +
                f"\n👤 {user['full_name']} (ID: {target_id})\n"
                f"💰 الرصيد الحالي: ${user['balance']:.2f}"
            )

        elif state == "deduct_balance_amount":
            try:
                amount = float(text)
                if amount <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_amount"])
                return

            target_id       = data.get("target_id")
            target_name     = data.get("target_name")
            current_balance = data.get("current_balance")

            if current_balance < amount:
                bot.send_message(
                    msg.chat.id,
                    L["insufficient_balance_deduct"].format(
                        balance=f"{current_balance:.2f}",
                        amount=f"{amount:.2f}"
                    ),
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )
                _clear_state()
                return

            update_balance(target_id, -amount)
            new_balance = current_balance - amount
            _clear_state()

            bot.send_message(
                msg.chat.id,
                L["balance_deducted"].format(
                    amount=f"{amount:.2f}",
                    name=target_name,
                    balance=f"{new_balance:.2f}"
                ),
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   BROADCAST MESSAGE
        # ══════════════════════════════════════

        elif state == "broadcast_message":
            message_text = text if text else None
            user_count   = get_all_users_count()

            _set_state("broadcast_confirm",
                       message=message_text,
                       photo_id=photo_id)

            preview = (
                message_text[:100] + "..."
                if message_text and len(message_text) > 100
                else message_text or "[صورة]"
            )

            bot.send_message(
                msg.chat.id,
                L["broadcast_confirm"].format(
                    count=user_count,
                    message=preview
                ),
                reply_markup=broadcast_confirm_keyboard(OWNER_ID)
            )

        # ══════════════════════════════════════
        #   PAYMENT METHODS
        # ══════════════════════════════════════

        elif state == "add_payment_name_ar":
            _set_state("add_payment_name_en", name_ar=text)
            bot.send_message(msg.chat.id, L["enter_method_name_en"])

        elif state == "add_payment_name_en":
            name_ar = data.get("name_ar")
            _set_state("add_payment_inst_ar",
                       name_ar=name_ar, name_en=text)
            bot.send_message(
                msg.chat.id, L["enter_method_instructions_ar"]
            )

        elif state == "add_payment_inst_ar":
            name_ar = data.get("name_ar")
            name_en = data.get("name_en")
            inst_ar = None if text.lower() == "skip" else text
            _set_state("add_payment_inst_en",
                       name_ar=name_ar, name_en=name_en,
                       inst_ar=inst_ar)
            bot.send_message(
                msg.chat.id, L["enter_method_instructions_en"]
            )

        elif state == "add_payment_inst_en":
            name_ar = data.get("name_ar")
            name_en = data.get("name_en")
            inst_ar = data.get("inst_ar")
            inst_en = None if text.lower() == "skip" else text

            add_payment_method(name_ar, name_en, inst_ar, inst_en)
            _clear_state()

            bot.send_message(
                msg.chat.id,
                L["payment_method_added"],
                reply_markup=admin_payment_methods_keyboard(OWNER_ID)
            )

        # ══════════════════════════════════════
        #   COMMISSION RATE
        # ══════════════════════════════════════

        elif state == "edit_commission_rate":
            try:
                rate = float(text)
                if rate < 0 or rate > 100:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_commission"])
                return
            set_recharge_commission_rate(rate)
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["commission_updated"].format(rate=f"{rate:.1f}"),
                reply_markup=back_keyboard(OWNER_ID, "adm_recharge_commission")
            )

        # ══════════════════════════════════════
        #   COUPONS
        # ══════════════════════════════════════

        elif state == "coupon_balance":
            try:
                value = float(text)
                if value <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_amount"])
                return
            code = create_coupon("balance", value)
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["coupon_created"].format(
                    code=code,
                    info=L["coupon_info_balance"].format(
                        value=f"{value:.2f}"
                    ),
                    type=L["coupon_type_balance"]
                ),
                parse_mode="HTML",
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        elif state == "coupon_discount":
            try:
                value = int(text)
                if value <= 0 or value > 100:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_commission"])
                return
            code = create_coupon("discount", float(value))
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["coupon_created"].format(
                    code=code,
                    info=L["coupon_info_discount"].format(value=value),
                    type=L["coupon_type_discount"]
                ),
                parse_mode="HTML",
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        # ══════════════════════════════════════
        #   SPIN WHEEL
        # ══════════════════════════════════════

        elif state == "edit_spin_chances":
            try:
                parts     = text.split(",")
                if len(parts) != 4:
                    raise ValueError
                no_prize  = float(parts[0].strip())
                balance   = float(parts[1].strip())
                discount5 = float(parts[2].strip())
                discount7 = float(parts[3].strip())
                total     = no_prize + balance + discount5 + discount7
                if abs(total - 100) > 0.01:
                    bot.send_message(
                        msg.chat.id,
                        f"❌ المجموع يجب أن يكون 100%\n"
                        f"المجموع الحالي: {total}%"
                    )
                    return
                update_spin_setting('spin_no_prize_chance', no_prize)
                update_spin_setting('spin_balance_chance',  balance)
                update_spin_setting('spin_discount5_chance', discount5)
                update_spin_setting('spin_discount7_chance', discount7)
                _clear_state()
                bot.send_message(
                    msg.chat.id,
                    L["spin_chances_updated"],
                    reply_markup=back_keyboard(OWNER_ID, "adm_spin_wheel")
                )
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_spin_format"])

        elif state == "edit_spin_balance_value":
            try:
                value = float(text)
                if value <= 0:
                    raise ValueError
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_amount"])
                return
            update_spin_setting('spin_balance_value', value)
            _clear_state()
            bot.send_message(
                msg.chat.id,
                L["spin_balance_updated"].format(value=f"{value:.2f}"),
                reply_markup=back_keyboard(OWNER_ID, "adm_spin_wheel")
            )

        # ══════════════════════════════════════
        #   DM USER (NEW)
        # ══════════════════════════════════════

        elif state == "dm_user_id":
            try:
                target_id = int(text)
            except ValueError:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            user = get_user(target_id)
            if not user:
                bot.send_message(msg.chat.id, L["invalid_user"])
                return
            _set_state("dm_user_message",
                       target_id=target_id,
                       target_name=user["full_name"])
            bot.send_message(
                msg.chat.id,
                L["dm_user_message"] +
                f"\n👤 {user['full_name']} (ID: {target_id})",
                reply_markup=back_keyboard(OWNER_ID, "admin")
            )

        elif state == "dm_user_message":
            target_id = data.get("target_id")
            _clear_state()
            try:
                if doc_id:
                    bot.send_document(
                        target_id, doc_id,
                        caption=text if text else None
                    )
                elif photo_id:
                    bot.send_photo(
                        target_id, photo_id,
                        caption=text if text else None
                    )
                else:
                    bot.send_message(target_id, text)

                bot.send_message(
                    msg.chat.id,
                    L["dm_user_success"].format(user_id=target_id),
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )
            except Exception:
                bot.send_message(
                    msg.chat.id,
                    L["dm_user_failed"].format(user_id=target_id),
                    reply_markup=back_keyboard(OWNER_ID, "admin")
                )

        # ══════════════════════════════════════
        #   BALANCE MESSAGE CONFIRM
        # ══════════════════════════════════════

        elif state == "confirm_balance_msg":
            # Any message triggers the send
            _clear_state()
            users = get_all_users_with_balance()
            L_    = get_locale(OWNER_ID)
            bot.send_message(
                msg.chat.id,
                L_["balance_msg_started"]
            )
            t = threading.Thread(
                target=_send_balance_messages,
                args=(bot, users, msg.chat.id),
                daemon=True
            )
            t.start()