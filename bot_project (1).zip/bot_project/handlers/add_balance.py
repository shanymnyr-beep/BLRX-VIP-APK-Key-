import telebot
from telebot.types import CallbackQuery
from config import OWNER_USERNAME
from database import (
    get_user, get_payment_methods,
    get_payment_method, get_user_language
)
from keyboards import (
    add_balance_amounts_keyboard,
    payment_methods_keyboard,
    contact_dev_keyboard,
    back_keyboard
)
from utils.helpers import get_locale, esc
from utils.decorators import maintenance_check


def register_add_balance_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "add_balance")
    @maintenance_check(bot)
    def cb_add_balance(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["add_balance_title"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=add_balance_amounts_keyboard(uid)
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("balance_")
    )
    @maintenance_check(bot)
    def cb_select_amount(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        try:
            amount = int(call.data.split("_")[1])
        except (IndexError, ValueError):
            return

        methods = get_payment_methods()

        if not methods:
            bot.answer_callback_query(call.id)
            bot.edit_message_text(
                L["no_payment_methods"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "add_balance")
            )
            return

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["select_payment_method"].format(amount=amount),
            call.message.chat.id,
            call.message.message_id,
            reply_markup=payment_methods_keyboard(amount, uid)
        )

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("pay_")
    )
    @maintenance_check(bot)
    def cb_payment_method(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        try:
            parts     = call.data.split("_")
            method_id = int(parts[1])
            amount    = int(parts[2])
        except (IndexError, ValueError):
            return

        user = get_user(uid)
        if not user:
            return

        method = get_payment_method(method_id)
        if not method:
            bot.answer_callback_query(call.id, L["error"])
            return

        lang        = get_user_language(uid)
        method_name = (
            method["name_ar"] if lang == "ar"
            else method["name_en"]
        )
        username = (
            f"@{user['username']}"
            if user["username"]
            else "لا يوجد / N/A"
        )

        text = L["payment_request_message"].format(
            user_id=uid,
            name=esc(user["full_name"]),
            payment_method=method_name,
            username=esc(username),
            amount=amount,
            dev_username=OWNER_USERNAME
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=contact_dev_keyboard(uid, OWNER_USERNAME)
        )