import telebot
import random
import time
from telebot.types import CallbackQuery
from datetime import datetime, timedelta
from database import (
    get_user, get_last_spin_time, update_spin_time,
    get_spin_settings, update_balance, set_user_discount
)
from keyboards import daily_gift_keyboard, back_keyboard
from utils.helpers import get_locale
from utils.decorators import maintenance_check


def register_daily_gift_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "daily_gift")
    @maintenance_check(bot)
    def cb_daily_gift(call: CallbackQuery):
        uid      = call.from_user.id
        L        = get_locale(uid)
        settings = get_spin_settings()

        text = L["daily_gift_info"].format(
            balance=f"${settings['balance_value']:.2f}",
            discount5="5",
            discount7="7"
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=daily_gift_keyboard(uid)
        )

    @bot.callback_query_handler(func=lambda c: c.data == "spin_wheel")
    @maintenance_check(bot)
    def cb_spin_wheel(call: CallbackQuery):
        uid       = call.from_user.id
        L         = get_locale(uid)
        last_spin = get_last_spin_time(uid)

        # Check 24h cooldown
        if last_spin:
            last_time = datetime.fromisoformat(last_spin)
            next_time = last_time + timedelta(hours=24)
            now       = datetime.now()

            if now < next_time:
                remaining = next_time - now
                hours     = int(remaining.total_seconds() // 3600)
                minutes   = int((remaining.total_seconds() % 3600) // 60)
                bot.answer_callback_query(
                    call.id,
                    L["spin_wait"].format(
                        hours=hours, minutes=minutes
                    ),
                    show_alert=True
                )
                return

        bot.answer_callback_query(call.id)

        # Animation
        _perform_spin(
            bot,
            call.message.chat.id,
            call.message.message_id,
            uid, L
        )

        # Update spin time
        update_spin_time(uid)

    def _perform_spin(bot, chat_id, message_id, user_id, L):
        """Animate spin and award prize."""
        frames = [
            "🎰 | 🎉 🔥 ❌ 🎁 💰 |",
            "🎰 | 💰 🎉 🔥 ❌ 🎁 |",
            "🎰 | 🎁 ❌ 💰 🎉 🔥 |",
        ]

        for frame in frames:
            try:
                bot.edit_message_text(
                    f"{L['spinning']}\n\n{frame}",
                    chat_id, message_id
                )
                time.sleep(0.8)
            except Exception:
                pass

        # Get prize
        settings = get_spin_settings()
        prize    = _get_random_prize(settings)
        user     = get_user(user_id)

        if prize == "no_prize":
            text = L["spin_no_prize"]

        elif prize == "balance":
            amount = settings["balance_value"]
            update_balance(user_id, amount)
            new_balance = user["balance"] + amount
            text = L["spin_win_balance"].format(
                amount=f"{amount:.2f}",
                balance=f"{new_balance:.2f}"
            )

        elif prize == "discount5":
            set_user_discount(user_id, 5)
            text = L["spin_win_discount"].format(discount=5)

        elif prize == "discount7":
            set_user_discount(user_id, 7)
            text = L["spin_win_discount"].format(discount=7)

        else:
            text = L["spin_no_prize"]

        try:
            bot.edit_message_text(
                text,
                chat_id, message_id,
                reply_markup=back_keyboard(user_id, "main_menu")
            )
        except Exception:
            bot.send_message(
                chat_id, text,
                reply_markup=back_keyboard(user_id, "main_menu")
            )

    def _get_random_prize(settings: dict) -> str:
        """Select prize based on probabilities."""
        prizes = [
            ("no_prize",  settings["no_prize"]),
            ("balance",   settings["balance"]),
            ("discount5", settings["discount5"]),
            ("discount7", settings["discount7"]),
        ]

        total      = sum(p[1] for p in prizes)
        rand       = random.uniform(0, total)
        cumulative = 0

        for prize, chance in prizes:
            cumulative += chance
            if rand <= cumulative:
                return prize

        return "no_prize"