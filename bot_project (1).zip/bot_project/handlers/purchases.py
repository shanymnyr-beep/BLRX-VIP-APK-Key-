import telebot
from telebot.types import CallbackQuery
from database import get_user_purchases
from keyboards import back_keyboard
from utils.helpers import get_locale, esc
from utils.decorators import maintenance_check


def register_purchases_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "purchases")
    @maintenance_check(bot)
    def cb_purchases(call: CallbackQuery):
        uid       = call.from_user.id
        L         = get_locale(uid)
        purchases = get_user_purchases(uid)

        bot.answer_callback_query(call.id)

        if not purchases:
            bot.edit_message_text(
                L["no_purchases"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "main_menu")
            )
            return

        # Build purchases text
        text = L["purchases_title"] + "\n\n"

        for p in purchases:
            ptype = p["product_type"] if p["product_type"] else "key"

            if ptype == "file":
                text += L["purchase_item_file"].format(
                    mod_name=esc(p["mod_name"]),
                    days=p["duration"],
                    price=f"{p['price']:.2f}",
                    date=p["purchased_at"][:10]
                ) + "\n\n"
            else:
                key_val = p["key_value"] or "—"
                text += L["purchase_item"].format(
                    mod_name=esc(p["mod_name"]),
                    days=p["duration"],
                    key=esc(key_val),
                    price=f"{p['price']:.2f}",
                    date=p["purchased_at"][:10]
                ) + "\n\n"

        MAX_LEN = 4000
        if len(text) <= MAX_LEN:
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "main_menu"),
                parse_mode="HTML"
            )
        else:
            bot.edit_message_text(
                L["purchases_title"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "main_menu")
            )
            chunks = [
                text[i:i + MAX_LEN]
                for i in range(0, len(text), MAX_LEN)
            ]
            for chunk in chunks:
                bot.send_message(
                    call.message.chat.id,
                    chunk,
                    parse_mode="HTML"
                )