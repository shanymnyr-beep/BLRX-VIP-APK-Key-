import telebot
from telebot.types import CallbackQuery
from database import get_user, get_user_discount
from keyboards import back_keyboard
from utils.helpers import get_locale, esc
from utils.decorators import maintenance_check


def register_account_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "account")
    @maintenance_check(bot)
    def cb_account(call: CallbackQuery):
        uid  = call.from_user.id
        L    = get_locale(uid)
        user = get_user(uid)

        if not user:
            return

        name     = user["full_name"] or call.from_user.full_name
        discount = get_user_discount(uid)

        discount_info = ""
        if discount > 0:
            discount_info = L["account_discount_info"].format(
                discount=discount
            )

        text = L["account_title"].format(
            user_id=uid,
            name=esc(name),
            balance=f"{user['balance']:.2f}",
            spent=f"{user['total_spent']:.2f}",
            ref_earnings=f"{user['ref_earnings']:.2f}",
            ref_count=user["ref_count"],
            discount_info=discount_info
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(uid, "main_menu"),
            parse_mode="HTML"
        )