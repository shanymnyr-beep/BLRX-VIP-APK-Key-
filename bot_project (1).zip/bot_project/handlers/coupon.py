import telebot
from telebot.types import CallbackQuery, Message
from database import (
    get_user, get_coupon, use_coupon,
    update_balance, set_user_discount
)
from keyboards import back_keyboard
from utils.helpers import get_locale
from config import MAX_DISCOUNT
from utils.decorators import maintenance_check

# State tracking
_coupon_states = {}


def register_coupon_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "coupon")
    @maintenance_check(bot)
    def cb_coupon(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)
        _coupon_states[uid] = "awaiting_coupon"
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["coupon_prompt"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(uid, "main_menu")
        )

    @bot.message_handler(
        func=lambda m: _coupon_states.get(m.from_user.id) == "awaiting_coupon",
        content_types=["text"]
    )
    @maintenance_check(bot)
    def handle_coupon_code(msg: Message):
        uid  = msg.from_user.id
        L    = get_locale(uid)
        code = msg.text.strip()

        _coupon_states.pop(uid, None)

        coupon = get_coupon(code)

        if not coupon:
            bot.send_message(
                msg.chat.id,
                L["coupon_invalid"],
                reply_markup=back_keyboard(uid, "main_menu")
            )
            return

        if coupon["is_used"]:
            bot.send_message(
                msg.chat.id,
                L["coupon_used"],
                reply_markup=back_keyboard(uid, "main_menu")
            )
            return

        if not use_coupon(code, uid):
            bot.send_message(
                msg.chat.id,
                L["coupon_invalid"],
                reply_markup=back_keyboard(uid, "main_menu")
            )
            return

        # Apply reward
        if coupon["type"] == "balance":
            update_balance(uid, coupon["value"])
            user = get_user(uid)
            bot.send_message(
                msg.chat.id,
                L["coupon_balance_success"].format(
                    amount=f"{coupon['value']:.2f}",
                    balance=f"{user['balance']:.2f}"
                ),
                reply_markup=back_keyboard(uid, "main_menu")
            )

        elif coupon["type"] == "discount":
            # Cap discount at 10%
            discount = min(int(coupon["value"]), MAX_DISCOUNT)
            set_user_discount(uid, discount)
            bot.send_message(
                msg.chat.id,
                L["coupon_discount_success"].format(discount=discount),
                reply_markup=back_keyboard(uid, "main_menu")
            )