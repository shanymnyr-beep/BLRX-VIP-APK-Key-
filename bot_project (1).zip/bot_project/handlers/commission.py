import telebot
from telebot.types import CallbackQuery
from database import (
    get_user, get_recharge_commission_rate,
    is_commission_enabled
)
from keyboards import back_keyboard
from utils.helpers import get_locale
from utils.decorators import maintenance_check


def register_commission_handlers(bot: telebot.TeleBot):

    @bot.callback_query_handler(func=lambda c: c.data == "commission")
    @maintenance_check(bot)
    def cb_commission(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        if not is_commission_enabled():
            bot.answer_callback_query(
                call.id,
                "⚠️ النظام معطل حالياً",
                show_alert=True
            )
            return

        user = get_user(uid)
        if not user:
            return

        bot_info        = bot.get_me()
        ref_link        = f"https://t.me/{bot_info.username}?start=ref_{uid}"
        commission_rate = get_recharge_commission_rate()

        text = L["commission_title"].format(
            link=ref_link,
            rate=f"{commission_rate:.0f}",
            earnings=f"{user['ref_earnings']:.2f}",
            count=user["ref_count"]
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(uid, "main_menu"),
            parse_mode="HTML"
        )