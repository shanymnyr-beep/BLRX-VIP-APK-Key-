import telebot
import logging
from telebot.types import CallbackQuery, Message
from database import create_ticket, get_user
from keyboards import back_keyboard, support_keyboard
from utils.helpers import get_locale
from utils.decorators import maintenance_check
from config import OWNER_ID

# State tracking
_support_states = {}


def register_support_handlers(bot: telebot.TeleBot):

    # ══════════════════════════════════════════
    #           HELP MENU
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "help")
    @maintenance_check(bot)
    def cb_help(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["help_menu"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=support_keyboard(uid)
        )

    # ══════════════════════════════════════════
    #           INSTRUCTIONS
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "instructions")
    @maintenance_check(bot)
    def cb_instructions(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["instructions_text"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(uid, "help")
        )

    # ══════════════════════════════════════════
    #           SEND SUPPORT MESSAGE
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "send_support")
    @maintenance_check(bot)
    def cb_send_support(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)
        _support_states[uid] = "awaiting_support"
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            L["support_prompt"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=back_keyboard(uid, "help")
        )

    # ══════════════════════════════════════════
    #           HANDLE SUPPORT MESSAGE
    # ══════════════════════════════════════════

    @bot.message_handler(
        func=lambda m: _support_states.get(m.from_user.id) == "awaiting_support",
        content_types=["text", "photo"]
    )
    @maintenance_check(bot)
    def handle_support_message(msg: Message):
        uid = msg.from_user.id
        L   = get_locale(uid)

        # Extract content
        if msg.content_type == "photo":
            text_content = msg.caption or ""
            photo_id     = msg.photo[-1].file_id
        else:
            text_content = msg.text or ""
            photo_id     = None

        if not text_content and not photo_id:
            bot.send_message(msg.chat.id, L["error"])
            return

        # Clear state
        _support_states.pop(uid, None)

        # Save ticket
        ticket_id = create_ticket(uid, text_content, photo_id)

        # Confirm to user
        bot.send_message(
            msg.chat.id,
            L["support_received"],
            reply_markup=back_keyboard(uid, "main_menu")
        )

        # Notify owner
        user      = get_user(uid)
        user_name = user["full_name"] if user else str(uid)
        username  = (
            f"@{user['username']}"
            if user and user["username"]
            else "N/A"
        )

        owner_text = (
            f"🎫 تذكرة جديدة #{ticket_id}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 {user_name} ({username})\n"
            f"🆔 ID: {uid}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💬 {text_content}"
        )

        from keyboards import ticket_reply_keyboard
        kb = ticket_reply_keyboard(ticket_id, OWNER_ID)

        try:
            if photo_id:
                bot.send_photo(
                    OWNER_ID, photo_id,
                    caption=owner_text,
                    reply_markup=kb
                )
            else:
                bot.send_message(
                    OWNER_ID, owner_text,
                    reply_markup=kb
                )
        except Exception as e:
            logging.getLogger(__name__).warning(
                "Failed to notify owner of ticket: %s", e
            )