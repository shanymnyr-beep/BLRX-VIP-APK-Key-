import telebot
from telebot.types import Message, CallbackQuery
from datetime import datetime
from config import OWNER_ID
from database import (
    get_user, create_user, update_user_language,
    get_user_language, get_referral_reward,
    add_referral_earnings, get_gift_link,
    check_gift_usage, claim_gift,
    is_referral_enabled, save_bot_message,
    get_user_bot_messages, clear_user_messages,
    set_pending_referrer,
)
from keyboards import (
    language_keyboard, main_menu_keyboard, back_keyboard,
    join_channel_keyboard, instagram_keyboard,
)
from utils.helpers import get_locale
from utils.decorators import maintenance_check
from utils.subscription import (
    is_subscribed, is_real_telegram_user, verify_rate_limited,
    grant_pending_referral, needs_instagram_step, complete_instagram_step,
)


def register_start_handlers(bot: telebot.TeleBot):

    # ══════════════════════════════════════════
    #           /start COMMAND
    # ══════════════════════════════════════════

    @bot.message_handler(commands=['start'])
    @maintenance_check(bot)
    def cmd_start(msg: Message):
        # Clear any pending conversational state so /start always resets cleanly.
        try:
            from handlers.support import _support_states
            _support_states.pop(msg.from_user.id, None)
        except Exception:
            pass
        try:
            from handlers.coupon import _coupon_states
            _coupon_states.pop(msg.from_user.id, None)
        except Exception:
            pass

        user = msg.from_user

        # ── Hidden anti-spam: ignore non-real / bot accounts silently. ──
        if not is_real_telegram_user(user):
            return

        args = msg.text.split()
        referral_code = args[1] if len(args) > 1 else None

        # ── Wipe ALL previously-opened interfaces above this /start ──
        # Deletes every bot message the user can see (main menu, store, account,
        # any inner page opened via a button, sent files/photos, notifications),
        # then a fresh interface is shown below. Two strategies are combined for
        # full coverage:
        #   (a) delete every message id we tracked via save_bot_message (exact)
        #   (b) sweep a range of message ids just below this /start command id,
        #       which catches messages that were never tracked (sent_document,
        #       sent_photo, long-purchase chunks, edited inner pages, etc.)
        _purge_previous_interfaces(bot, msg.chat.id, user.id, msg.message_id)

        # Handle gift link (gift links also require the subscription gate).
        if referral_code and referral_code.startswith("gift_"):
            # Ensure the user row exists, then gate, then claim.
            if not get_user(user.id):
                create_user(user.id, user.username, user.full_name)
            link_id = referral_code[5:]
            if not _gate(bot, msg, user):
                # store the gift intent so it is handled after onboarding? Keep
                # it simple: ask them to subscribe; they can reopen the link.
                return
            _handle_gift(bot, msg, link_id)
            return

        existing = get_user(user.id)

        if not existing:
            # ── New user ───────────────────────
            # Resolve a referral link into a PENDING (unpaid) referral. The
            # reward is granted ONLY after this user passes the channel check
            # (see utils.subscription.grant_pending_referral). This is the core
            # anti-fake-referral rule.
            referred_by = None
            pending_ref = None
            if referral_code and referral_code.startswith("ref_"):
                try:
                    ref_id = int(referral_code[4:])
                    if ref_id != user.id and get_user(ref_id):
                        referred_by = ref_id
                        pending_ref = ref_id
                except ValueError:
                    pass

            create_user(
                user.id,
                user.username,
                user.full_name,
                referred_by=referred_by,
                pending_ref=pending_ref,
            )

        # ── Forced-subscription gate (channel + one-time Instagram) ──
        if not _gate(bot, msg, user):
            return

        # Fully onboarded -> show the menu (existing or just-finished user).
        existing = get_user(user.id)
        if existing and existing["language"]:
            # Returning user with a language already set: show menu directly.
            # New users still need language selection.
            pass

        # If the user has never picked a language, offer it now; otherwise menu.
        # We detect "first real entry" by whether a language row exists AND the
        # user has interacted before. To keep it simple and match the requested
        # flow ("after pressing start again -> choose language"), we always show
        # language selection for users who have not completed it.
        _post_gate_entry(bot, msg.chat.id, user.id, user.full_name)

    # ══════════════════════════════════════════
    #     SUBSCRIPTION GATE HELPERS
    # ══════════════════════════════════════════

    def _gate(bot, msg: Message, user) -> bool:
        """
        Returns True if the user has fully passed the gate (channel + IG).
        Otherwise shows the appropriate screen and returns False.
        """
        L = get_locale(user.id)

        # 1) Real channel membership check.
        if not is_subscribed(bot, user.id):
            sent = bot.send_message(
                msg.chat.id,
                L["force_sub_message"],
                reply_markup=join_channel_keyboard(user.id),
                parse_mode="HTML"
            )
            save_bot_message(user.id, sent.message_id)
            return False

        # Passed channel check -> pay any pending referral exactly once.
        try:
            grant_pending_referral(bot, user.id)
        except Exception:
            pass

        # 2) One-time Instagram step.
        if needs_instagram_step(user.id):
            sent = bot.send_message(
                msg.chat.id,
                L["instagram_message"],
                reply_markup=instagram_keyboard(user.id),
                parse_mode="HTML"
            )
            save_bot_message(user.id, sent.message_id)
            return False

        return True

    def _post_gate_entry(bot, chat_id, user_id, full_name):
        """
        After the gate is fully passed: if the user has no language yet, show
        language selection; otherwise show the main menu.
        """
        user = get_user(user_id)
        has_lang = bool(user and user["language"])
        # The schema defaults language to 'ar', so "no language" is rare; we
        # instead show language selection only when the user has not completed
        # onboarding before. Practically: show language picker once right after
        # passing the gate for the first time, then the menu afterwards.
        # We reuse instagram_shown as the "completed onboarding" marker.
        from database import instagram_shown
        completed = instagram_shown(user_id) or (user_id == OWNER_ID)

        if not has_lang or not completed:
            sent = bot.send_message(
                chat_id,
                "🌐 اختر لغتك / Choose your language:",
                reply_markup=language_keyboard()
            )
            save_bot_message(user_id, sent.message_id)
        else:
            _show_main_menu(bot, chat_id, user_id, full_name)

    # ══════════════════════════════════════════
    #     VERIFY SUBSCRIPTION (button)
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "verify_join")
    def cb_verify_join(call: CallbackQuery):
        user = call.from_user
        uid  = user.id
        L    = get_locale(uid)

        # Hidden anti-spam: ignore bot accounts + flood taps.
        if not is_real_telegram_user(user):
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            return
        if verify_rate_limited(uid):
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            return

        # Re-check real membership.
        if not is_subscribed(bot, uid):
            bot.answer_callback_query(
                call.id, L["force_sub_not_joined"], show_alert=True
            )
            return

        # Subscribed now -> grant any pending referral exactly once.
        try:
            grant_pending_referral(bot, uid)
        except Exception:
            pass

        bot.answer_callback_query(call.id, L["force_sub_ok"])

        # Next: one-time Instagram step, else go straight to language/menu.
        if needs_instagram_step(uid):
            try:
                bot.edit_message_text(
                    L["instagram_message"],
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=instagram_keyboard(uid),
                    parse_mode="HTML"
                )
            except Exception:
                bot.send_message(
                    call.message.chat.id,
                    L["instagram_message"],
                    reply_markup=instagram_keyboard(uid),
                    parse_mode="HTML"
                )
            return

        _enter_after_gate(bot, call.message.chat.id, uid,
                          user.full_name, call.message.message_id)

    # ══════════════════════════════════════════
    #     INSTAGRAM STEP DONE (button, no verify)
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "instagram_done")
    def cb_instagram_done(call: CallbackQuery):
        user = call.from_user
        uid  = user.id
        L    = get_locale(uid)

        if not is_real_telegram_user(user):
            try:
                bot.answer_callback_query(call.id)
            except Exception:
                pass
            return

        # Safety: the IG step lives behind the channel gate. Re-verify channel.
        if not is_subscribed(bot, uid):
            bot.answer_callback_query(
                call.id, L["force_sub_not_joined"], show_alert=True
            )
            try:
                bot.edit_message_text(
                    L["force_sub_message"],
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=join_channel_keyboard(uid),
                    parse_mode="HTML"
                )
            except Exception:
                pass
            return

        # Mark the one-time Instagram step as completed (never shown again).
        complete_instagram_step(uid)
        bot.answer_callback_query(call.id)

        _enter_after_gate(bot, call.message.chat.id, uid,
                          user.full_name, call.message.message_id)

    def _enter_after_gate(bot, chat_id, user_id, full_name, message_id=None):
        """
        Gate fully passed via buttons. Show language selection if the user has
        not completed it yet, else show the main menu.
        """
        user = get_user(user_id)
        has_lang = bool(user and user["language"])
        # First completion: present language selection. Subsequent entries go
        # straight to the menu (handled in _post_gate_entry / main_menu).
        text = "🌐 اختر لغتك / Choose your language:"
        if message_id:
            try:
                bot.edit_message_text(
                    text, chat_id, message_id,
                    reply_markup=language_keyboard()
                )
                return
            except Exception:
                pass
        sent = bot.send_message(chat_id, text, reply_markup=language_keyboard())
        save_bot_message(user_id, sent.message_id)

    # ══════════════════════════════════════════
    #           LANGUAGE SELECTION
    # ══════════════════════════════════════════

    @bot.callback_query_handler(
        func=lambda c: c.data in ("lang_ar", "lang_en")
    )
    def cb_set_language(call: CallbackQuery):
        # Language selection sits AFTER the gate, but guard it anyway so it can
        # never be used to bypass the subscription requirement.
        uid = call.from_user.id
        if uid != OWNER_ID and not is_subscribed(bot, uid):
            L = get_locale(uid)
            bot.answer_callback_query(
                call.id, L["force_sub_not_joined"], show_alert=True
            )
            try:
                bot.edit_message_text(
                    L["force_sub_message"],
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=join_channel_keyboard(uid),
                    parse_mode="HTML"
                )
            except Exception:
                pass
            return

        lang = "ar" if call.data == "lang_ar" else "en"
        update_user_language(call.from_user.id, lang)

        from locales.ar import AR
        from locales.en import EN
        L = AR if lang == "ar" else EN

        bot.answer_callback_query(call.id, L["language_set"])
        _show_main_menu(
            bot,
            call.message.chat.id,
            call.from_user.id,
            call.from_user.full_name,
            message_id=call.message.message_id
        )

    @bot.callback_query_handler(func=lambda c: c.data == "change_language")
    @maintenance_check(bot)
    def cb_change_language(call: CallbackQuery):
        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            "🌐 اختر لغتك / Choose your language:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=language_keyboard()
        )

    # ══════════════════════════════════════════
    #           MAIN MENU
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "main_menu")
    @maintenance_check(bot)
    def cb_main_menu(call: CallbackQuery):
        # Gate guard on the main menu too.
        uid = call.from_user.id
        if uid != OWNER_ID and not is_subscribed(bot, uid):
            L = get_locale(uid)
            bot.answer_callback_query(
                call.id, L["force_sub_not_joined"], show_alert=True
            )
            try:
                bot.edit_message_text(
                    L["force_sub_message"],
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=join_channel_keyboard(uid),
                    parse_mode="HTML"
                )
            except Exception:
                pass
            return

        _show_main_menu(
            bot,
            call.message.chat.id,
            call.from_user.id,
            call.from_user.full_name,
            message_id=call.message.message_id
        )

    # ══════════════════════════════════════════
    #           HELPERS
    # ══════════════════════════════════════════

    def _purge_previous_interfaces(bot, chat_id, user_id, current_message_id):
        """
        Remove every previously-opened bot interface above the current /start.

        (a) Exact deletes: every message id tracked via save_bot_message.
        (b) Range sweep: message ids immediately below this /start command.
            Telegram message ids are monotonically increasing per chat, so any
            interface the bot showed before /start has a SMALLER id. We try to
            delete a window of ids just below the /start message. Deletes that
            target the user's own messages or messages older than Telegram's
            48h delete window simply fail and are ignored silently.
        """
        # (a) Exact, tracked deletes.
        try:
            tracked = get_user_bot_messages(user_id, limit=50)
        except Exception:
            tracked = []

        deleted = set()
        for mid in tracked:
            try:
                bot.delete_message(chat_id, mid)
            except Exception:
                pass
            deleted.add(mid)

        # (b) Range sweep below the /start message id (catches untracked ones).
        SWEEP = 40
        for mid in range(current_message_id - 1,
                         max(current_message_id - SWEEP, 0), -1):
            if mid in deleted:
                continue
            try:
                bot.delete_message(chat_id, mid)
            except Exception:
                # Not ours / too old / already gone -> ignore.
                pass

        # Also delete the /start command message itself so the chat stays clean.
        try:
            bot.delete_message(chat_id, current_message_id)
        except Exception:
            pass

        # Reset our tracking table; fresh interface ids will be saved anew.
        try:
            clear_user_messages(user_id)
        except Exception:
            pass

    def _show_main_menu(bot, chat_id, user_id, name,
                        message_id=None):
        L    = get_locale(user_id)
        text = L["main_menu"].format(name=name)
        kb   = main_menu_keyboard(user_id)

        if message_id:
            try:
                bot.edit_message_text(
                    text, chat_id, message_id,
                    reply_markup=kb
                )
                return
            except Exception:
                pass

        sent = bot.send_message(chat_id, text, reply_markup=kb)
        save_bot_message(user_id, sent.message_id)

    def _handle_gift(bot, msg: Message, link_id: str):
        user     = msg.from_user
        existing = get_user(user.id)

        if not existing:
            create_user(user.id, user.username, user.full_name)

        L    = get_locale(user.id)
        gift = get_gift_link(link_id)

        if not gift:
            bot.send_message(msg.chat.id, L["gift_invalid"])
            _show_main_menu(
                bot, msg.chat.id,
                user.id, user.full_name
            )
            return

        # Check expiry
        if gift["expires_at"]:
            try:
                exp = datetime.fromisoformat(gift["expires_at"])
                if datetime.now() > exp:
                    bot.send_message(msg.chat.id, L["gift_expired"])
                    _show_main_menu(
                        bot, msg.chat.id,
                        user.id, user.full_name
                    )
                    return
            except Exception:
                pass

        # Check max uses
        if gift["max_uses"] > 0 and gift["used_count"] >= gift["max_uses"]:
            bot.send_message(msg.chat.id, L["gift_max_uses"])
            _show_main_menu(
                bot, msg.chat.id,
                user.id, user.full_name
            )
            return

        # Check already claimed
        if check_gift_usage(link_id, user.id):
            bot.send_message(msg.chat.id, L["gift_already_claimed"])
            _show_main_menu(
                bot, msg.chat.id,
                user.id, user.full_name
            )
            return

        # Claim gift
        claim_gift(link_id, user.id, gift["amount"])
        bot.send_message(
            msg.chat.id,
            L["gift_claimed"].format(amount=f"{gift['amount']:.2f}")
        )
        _show_main_menu(
            bot, msg.chat.id,
            user.id, user.full_name
        )
