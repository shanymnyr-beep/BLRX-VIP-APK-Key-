import telebot
from telebot.types import CallbackQuery
from database import (
    get_all_mods, get_mod_by_id, get_keys_summary,
    get_user, get_user_discount, purchase_atomic
)
from keyboards import (
    mods_keyboard, mod_buy_keyboard,
    confirm_purchase_keyboard, back_keyboard
)
from utils.helpers import get_locale, get_stock_text, esc
from utils.decorators import maintenance_check
from config import LOW_STOCK_THRESHOLD, MAX_DISCOUNT


def register_store_handlers(bot: telebot.TeleBot):

    # ══════════════════════════════════════════
    #           STORE MAIN
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data == "store")
    @maintenance_check(bot)
    def cb_store(call: CallbackQuery):
        uid  = call.from_user.id
        L    = get_locale(uid)
        mods = get_all_mods()

        bot.answer_callback_query(call.id)

        if not mods:
            bot.edit_message_text(
                L["no_mods"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "main_menu")
            )
            return

        bot.edit_message_text(
            L["store_title"],
            call.message.chat.id,
            call.message.message_id,
            reply_markup=mods_keyboard(mods, uid)
        )

    # ══════════════════════════════════════════
    #           MOD DETAIL
    # ══════════════════════════════════════════

    @bot.callback_query_handler(
        func=lambda c: c.data.startswith("mod_")
        and not c.data.startswith("mod_buy")
    )
    @maintenance_check(bot)
    def cb_mod_detail(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        try:
            mod_id = int(call.data.split("_")[1])
        except (IndexError, ValueError):
            return

        mod = get_mod_by_id(mod_id)
        if not mod:
            bot.answer_callback_query(call.id, L["error"])
            return

        summary = get_keys_summary(mod_id)
        if not summary:
            bot.answer_callback_query(call.id)
            bot.edit_message_text(
                f"🎮 {mod['name']}\n\n" + L["out_of_stock"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, "store")
            )
            return

        # Build duration lines
        duration_lines = ""
        for row in summary:
            stock_text      = get_stock_text(row["cnt"], L, LOW_STOCK_THRESHOLD)
            duration_lines += L["duration_line"].format(
                days=row["duration"],
                price=f"{row['price']:.2f}",
                stock=stock_text
            ) + "\n"

        text = L["mod_details"].format(
            mod_name=esc(mod["name"]),
            durations=duration_lines.strip()
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=mod_buy_keyboard(mod_id, summary, uid),
            parse_mode="HTML"
        )

    # ══════════════════════════════════════════
    #           BUY - SELECT DURATION
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data.startswith("buy_"))
    @maintenance_check(bot)
    def cb_buy(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        try:
            parts    = call.data.split("_")
            mod_id   = int(parts[1])
            duration = int(parts[2])
            price    = float(parts[3])
        except (IndexError, ValueError):
            return

        mod = get_mod_by_id(mod_id)
        if not mod:
            bot.answer_callback_query(call.id, L["error"])
            return

        user    = get_user(uid)
        balance = user["balance"] if user else 0.0

        # Check discount
        discount      = get_user_discount(uid)
        discount_info = ""
        final_price   = price

        if discount > 0:
            # Max discount cap = 10%
            discount    = min(discount, MAX_DISCOUNT)
            final_price = round(price * (1 - discount / 100.0), 2)
            discount_info = L["discount_info_text"].format(
                discount=discount,
                final=f"{final_price:.2f}"
            )

        display_price = f"{final_price:.2f}" if discount > 0 else f"{price:.2f}"

        text = L["confirm_purchase"].format(
            mod_name=esc(mod["name"]),
            days=duration,
            price=display_price,
            balance=f"{balance:.2f}",
            discount_info=discount_info
        )

        bot.answer_callback_query(call.id)
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=confirm_purchase_keyboard(mod_id, duration, price, uid)
        )

    # ══════════════════════════════════════════
    #           CONFIRM PURCHASE
    # ══════════════════════════════════════════

    @bot.callback_query_handler(func=lambda c: c.data.startswith("confirm_"))
    @maintenance_check(bot)
    def cb_confirm_purchase(call: CallbackQuery):
        uid = call.from_user.id
        L   = get_locale(uid)

        try:
            parts          = call.data.split("_")
            mod_id         = int(parts[1])
            duration       = int(parts[2])
            original_price = float(parts[3])
        except (IndexError, ValueError):
            return

        user = get_user(uid)
        if not user:
            bot.answer_callback_query(call.id, L["error"])
            return

        balance = user["balance"]

        # Apply discount (capped)
        discount    = get_user_discount(uid)
        final_price = original_price
        apply_discount = False

        if discount > 0:
            discount    = min(discount, MAX_DISCOUNT)
            final_price = round(original_price * (1 - discount / 100.0), 2)
            apply_discount = True

        # ── Atomic purchase (race-safe) ────────
        result = purchase_atomic(
            user_id=uid,
            mod_id=mod_id,
            duration=duration,
            price=original_price,
            final_price=final_price,
            mod_name="",            # filled below from mod row
            apply_discount=apply_discount
        )

        if result["status"] == "insufficient":
            bal  = result["balance"]
            diff = final_price - bal
            bot.answer_callback_query(call.id, "❌", show_alert=True)
            bot.edit_message_text(
                L["insufficient_balance"].format(
                    balance=f"{bal:.2f}",
                    price=f"{final_price:.2f}",
                    diff=f"{diff:.2f}"
                ),
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, f"mod_{mod_id}")
            )
            return

        if result["status"] in ("out_of_stock", "error"):
            bot.answer_callback_query(
                call.id, L["out_of_stock_err"], show_alert=True
            )
            bot.edit_message_text(
                L["out_of_stock_err"],
                call.message.chat.id,
                call.message.message_id,
                reply_markup=back_keyboard(uid, f"mod_{mod_id}")
            )
            return

        # Success
        mod         = get_mod_by_id(mod_id)
        mod_name    = mod["name"] if mod else "-"
        key_row     = result["key_row"]
        ptype       = key_row["product_type"]
        new_balance = result["new_balance"]

        bot.answer_callback_query(call.id, "✅")

        # ── Send result based on product type ──
        if ptype == "file":
            text = L["purchase_success_file"].format(
                mod_name=esc(mod_name),
                days=duration,
                price=f"{final_price:.2f}",
                balance=f"{new_balance:.2f}"
            )
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode="HTML",
                reply_markup=back_keyboard(uid, "store")
            )
            try:
                file_id = key_row["file_id"]
                try:
                    bot.send_document(call.message.chat.id, file_id)
                except Exception:
                    bot.send_photo(call.message.chat.id, file_id)
            except Exception:
                bot.send_message(
                    call.message.chat.id,
                    "⚠️ تعذر إرسال الملف. تواصل مع الدعم."
                )
        else:
            if apply_discount:
                text = L["purchase_success_discount"].format(
                    mod_name=esc(mod_name),
                    days=duration,
                    key=esc(key_row["key_value"]),
                    original=f"{original_price:.2f}",
                    discount=discount,
                    final=f"{final_price:.2f}",
                    balance=f"{new_balance:.2f}"
                )
            else:
                text = L["purchase_success"].format(
                    mod_name=esc(mod_name),
                    days=duration,
                    key=esc(key_row["key_value"]),
                    price=f"{final_price:.2f}",
                    balance=f"{new_balance:.2f}"
                )
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode="HTML",
                reply_markup=back_keyboard(uid, "store")
            )