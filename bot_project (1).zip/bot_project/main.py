#!/usr/bin/env python3
"""
╔══════════════════════════════════════════╗
║     Mod Menu Keys Bot - Main Entry       ║
║     Author: Professional Bot System     ║
╚══════════════════════════════════════════╝
"""

import telebot
import logging
import threading
import time
from config import BOT_TOKEN, OWNER_ID
from database import init_db, restore_backup_if_present

# ── Logging setup ────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("bot.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ── Initialize bot ────────────────────────────────────────────
bot = telebot.TeleBot(
    BOT_TOKEN,
    parse_mode=None,
    threaded=True,
    num_threads=8
)

# ── Restore data from a provided backup (if any) BEFORE init ──
if restore_backup_if_present():
    logger.info("📥 Imported existing data backup (bot_data_backup.db).")

# ── Initialize database ───────────────────────────────────────
init_db()
logger.info("✅ Database initialized.")

# ── Register all handlers ─────────────────────────────────────
from handlers.start import register_start_handlers
from handlers.store import register_store_handlers
from handlers.referral import register_referral_handlers
from handlers.account import register_account_handlers
from handlers.purchases import register_purchases_handlers
from handlers.support import register_support_handlers
from handlers.admin import register_admin_handlers
from handlers.add_balance import register_add_balance_handlers
from handlers.coupon import register_coupon_handlers
from handlers.daily_gift import register_daily_gift_handlers
from handlers.commission import register_commission_handlers

register_start_handlers(bot)
register_store_handlers(bot)
register_referral_handlers(bot)
register_account_handlers(bot)
register_purchases_handlers(bot)
register_support_handlers(bot)
register_admin_handlers(bot)
register_add_balance_handlers(bot)
register_coupon_handlers(bot)
register_daily_gift_handlers(bot)
register_commission_handlers(bot)

logger.info("✅ All handlers registered.")


# ── Error handler ─────────────────────────────────────────────
# Registered LAST so all stateful text handlers (support/coupon/admin) match first.
@bot.message_handler(func=lambda m: True, content_types=["text", "photo", "document"])
def fallback_handler(msg):
    """Catch-all for unhandled messages; intentionally ignored."""
    pass


# ── Startup notification ──────────────────────────────────────
def notify_owner_startup():
    try:
        bot.send_message(
            OWNER_ID,
            "✅ البوت يعمل الآن!\n"
            "🤖 Mod Menu Keys Bot is online!\n"
            f"🕐 {time.strftime('%Y-%m-%d %H:%M:%S')}"
        )
    except Exception as e:
        logger.warning(f"Could not notify owner: {e}")


# ── Polling with auto-restart ─────────────────────────────────
def start_polling():
    logger.info("🚀 Bot started polling...")
    notify_owner_startup()
    while True:
        try:
            bot.infinity_polling(
                timeout=30,
                long_polling_timeout=30,
                logger_level=logging.WARNING,
                allowed_updates=["message", "callback_query"]
            )
        except Exception as e:
            logger.error(f"Polling error: {e}")
            time.sleep(5)
            logger.info("🔄 Restarting polling...")


if __name__ == "__main__":
    start_polling()