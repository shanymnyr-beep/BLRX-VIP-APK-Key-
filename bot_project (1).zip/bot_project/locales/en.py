EN = {
    # ── General ──────────────────────────────
    "choose_language":     "🌐 Choose your language:",
    "language_set":        "✅ Language set to English.",
    "main_menu":           "🏠 𝗤𝘂𝗲𝗿𝘆 𝗠𝗲𝗻𝘂\nWelcome {name}! Choose an option:",
    "back":                "🔙 Back",
    "cancel":              "❌ Cancel",
    "confirm":             "✅ Confirm",
    "error":               "❌ An error occurred. Please try again.",
    "not_authorized":      "⛔ Unauthorized.",
    "operation_cancelled": "❌ Operation cancelled.",

    # ── Maintenance ───────────────────────────
    "maintenance_mode_active": "🔧 Bot Under Maintenance",
    "maintenance_mode_message": (
        "🔧 𝗕𝗼𝘁 𝗨𝗻𝗱𝗲𝗿 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Our team is working on improvements! 🚀\n\n"
        "⏰ You'll be notified when done.\n\n"
        "Thank you for your patience. 💙"
    ),
    "maintenance_complete_message": (
        "🎉 𝗕𝗼𝘁 𝗶𝘀 𝗕𝗮𝗰𝗸 𝗢𝗻𝗹𝗶𝗻𝗲!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Welcome back! 💙\n\n"
        "✅ Bot is working normally 🚀\n\n"
        "Thank you for your patience! ❤️"
    ),

    # ── Buttons ───────────────────────────────
    "btn_store":        "🛒 Store",
    "btn_referral":     "🎁 Referral",
    "btn_commission":   "💼 Commission",
    "btn_account":      "👤 My Account",
    "btn_purchases":    "🧾 My Purchases",
    "btn_add_balance":  "💳 Add Balance",
    "btn_daily_gift":   "🎁 Daily Gift",
    "btn_coupon":       "🎫 Coupon",
    "btn_help":         "🆘 Help",
    "btn_admin":        "⚙️ Admin Panel",
    "btn_language":     "🌐 Language",
    "btn_spin":         "🎰 Spin",
    "btn_send_support": "📩 Send Support Message",
    "btn_instructions": "📘 Instructions",
    "btn_product_key":  "Key",
    "btn_product_file": "File",

    # ── Support / Help ────────────────────────
    "help_menu": (
        "🆘 𝗠𝗲𝗻𝘂 𝗦𝘂𝗽𝗽𝗼𝗿𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "How can we help you?\n"
        "Choose an option below:"
    ),
    "instructions_text": (
        "📘 𝗜𝗻𝘀𝘁𝗿𝘂𝗰𝘁𝗶𝗼𝗻𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "1️⃣ Press 🛒 Store to browse products\n\n"
        "2️⃣ Choose your product and duration\n\n"
        "3️⃣ Make sure you have enough balance\n"
        "   • Press 💳 Add Balance to top up\n\n"
        "4️⃣ After purchase you receive key or file instantly\n\n"
        "5️⃣ Share referral link to earn free balance 🎁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💡 For extra help contact support"
    ),
    "support_prompt": (
        "📩 𝗦𝗲𝗻𝗱 𝗠𝗲𝘀𝘀𝗮𝗴𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Write your message and we'll reply soon.\n"
        "You can attach an image (optional)."
    ),
    "support_received": "✅ Thank you! We'll reply shortly.",
    "support_reply": (
        "📩 𝗥𝗲𝗽𝗹𝘆 𝗙𝗿𝗼𝗺 𝗦𝘂𝗽𝗽𝗼𝗿𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{message}"
    ),

    # ── Store ─────────────────────────────────
    "store_title": "🛒 𝗦𝘁𝗼𝗿𝗲\nSelect a Mod Menu:",
    "no_mods":     "📭 No mods available yet.",
    "mod_details": (
        "🎮 𝗠𝗼𝗱: {mod_name}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{durations}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👇 Select duration below:"
    ),
    "duration_line":    "⏱ {days} Day(s)\n   💰 ${price}\n   📦 {stock}\n",
    "in_stock":         "✅ In Stock",
    "low_stock":        "⚠️ Only {count} left",
    "out_of_stock":     "❌ Out of Stock",
    "buy_btn":          "⏱ {days} Day(s) - ${price}",
    "confirm_purchase": (
        "🛒 𝗖𝗼𝗻𝗳𝗶𝗿𝗺 𝗣𝘂𝗿𝗰𝗵𝗮𝘀𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 Mod: {mod_name}\n"
        "⏱ Duration: {days} Day(s)\n"
        "💰 Price: ${price}\n"
        "💳 Balance: ${balance}\n"
        "{discount_info}"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Proceed?"
    ),
    "discount_info_text":   "🎁 You have {discount}% discount!\n💵 Price after discount: ${final}\n",
    "insufficient_balance": (
        "❌ 𝗜𝗻𝘀𝘂𝗳𝗳𝗶𝗰𝗶𝗲𝗻𝘁 𝗕𝗮𝗹𝗮𝗻𝗰𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 Your balance: ${balance}\n"
        "💸 Required: ${price}\n"
        "📉 Difference: ${diff}"
    ),
    "purchase_success": (
        "✅ 𝗣𝘂𝗿𝗰𝗵𝗮𝘀𝗲 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 Mod: {mod_name}\n"
        "⏱ Duration: {days} Day(s)\n"
        "🔑 Key: <code>{key}</code>\n"
        "💰 Paid: ${price}\n"
        "💳 Remaining: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Thank you! 🎉"
    ),
    "purchase_success_file": (
        "✅ 𝗣𝘂𝗿𝗰𝗵𝗮𝘀𝗲 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 Mod: {mod_name}\n"
        "⏱ Duration: {days} Day(s)\n"
        "📁 File below 👇\n"
        "💰 Paid: ${price}\n"
        "💳 Remaining: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Thank you! 🎉"
    ),
    "purchase_success_discount": (
        "✅ 𝗣𝘂𝗿𝗰𝗵𝗮𝘀𝗲 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 Mod: {mod_name}\n"
        "⏱ Duration: {days} Day(s)\n"
        "🔑 Key: <code>{key}</code>\n"
        "💰 Original: ${original}\n"
        "🎁 Discount: -{discount}%\n"
        "💵 Paid: ${final}\n"
        "💳 Remaining: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Thank you! 🎉"
    ),
    "out_of_stock_err":  "❌ Out of stock for this duration!",
    "no_keys_available": "❌ No products available.",

    # ── Referral ──────────────────────────────
    "referral_title": (
        "🎁 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹 𝗦𝘆𝘀𝘁𝗲𝗺\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 Your referral link:\n"
        "{link}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 Referrals: {count}\n"
        "💰 Earnings: ${earnings}\n"
        "💵 Reward per referral: ${reward}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Share and earn! 🚀"
    ),
    "referral_earned": (
        "🎁 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹 𝗘𝗮𝗿𝗻𝗲𝗱!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👤 Joined: {name}\n"
        "💰 Added: ${amount}\n"
        "💵 New Balance: ${balance}"
    ),

    # ── Commission ────────────────────────────
    "commission_title": (
        "💼 𝗖𝗼𝗺𝗺𝗶𝘀𝘀𝗶𝗼𝗻 𝗦𝘆𝘀𝘁𝗲𝗺\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 Your link:\n"
        "{link}\n\n"
        "📌 How to earn?\n"
        "1. Share your link\n"
        "2. When they recharge\n"
        "3. You get {rate}% commission!\n\n"
        "💰 Total Earnings: ${earnings}\n"
        "👥 Referrals: {count}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Share now! 🚀"
    ),
    "commission_earned": (
        "💰 𝗖𝗼𝗺𝗺𝗶𝘀𝘀𝗶𝗼𝗻 𝗘𝗮𝗿𝗻𝗲𝗱!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{name} recharged their balance\n"
        "💵 Recharge: ${recharge}\n"
        "📊 Commission: {rate}%\n"
        "💰 Your earn: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💳 Added to your balance! 🚀"
    ),
    "recharge_commission_earned": (
        "💰 𝗖𝗼𝗺𝗺𝗶𝘀𝘀𝗶𝗼𝗻 𝗘𝗮𝗿𝗻𝗲𝗱!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{user_name} recharged their balance\n"
        "💵 Recharge: ${recharge}\n"
        "📊 Commission: {rate}%\n"
        "💰 Your earn: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💳 Added to your balance! 🚀"
    ),

    # ── Balance Notification ──────────────────
    "balance_added_notification": (
        "💰 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 𝗔𝗱𝗱𝗲𝗱!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "✅ ${amount} has been added to your balance!\n"
        "💳 New Balance: ${balance}"
    ),

    # ── Daily Gift ────────────────────────────
    "daily_gift_info": (
        "🎁 𝗗𝗮𝗶𝗹𝘆 𝗚𝗶𝗳𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎰 Today's Prizes:\n\n"
        "💰 {balance} Free Balance\n"
        "🎫 {discount5}% Discount\n"
        "🎫 {discount7}% Discount\n"
        "❌ Better Luck Next Time\n\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Press '🎰 Spin'!\n"
        "⏰ Once every 24 hours"
    ),
    "spinning":      "🎰 Spinning...",
    "spin_wait": (
        "⏰ Come back later!\n"
        "⏳ Remaining: {hours}h {minutes}m\n\n"
        "New chance tomorrow! 🎁"
    ),
    "spin_no_prize": (
        "😔 𝗡𝗼 𝗣𝗿𝗶𝘇𝗲 𝗧𝗵𝗶𝘀 𝗧𝗶𝗺𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Don't worry! Luck is coming 🍀\n"
        "Try again tomorrow! 🎁"
    ),
    "spin_win_balance": (
        "🎉 𝗖𝗼𝗻𝗴𝗿𝗮𝘁𝘂𝗹𝗮𝘁𝗶𝗼𝗻𝘀!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 Prize: ${amount}\n"
        "💳 New Balance: ${balance}\n\n"
        "Come back tomorrow! 🎁"
    ),
    "spin_win_discount": (
        "🎉 𝗖𝗼𝗻𝗴𝗿𝗮𝘁𝘂𝗹𝗮𝘁𝗶𝗼𝗻𝘀!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎫 Prize: {discount}% Discount\n"
        "📌 Valid for next purchase!\n\n"
        "Come back tomorrow! 🎁"
    ),

    # ── Account ───────────────────────────────
    "account_title": (
        "👤 𝗠𝘆 𝗔𝗰𝗰𝗼𝘂𝗻𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "📛 Name: {name}\n"
        "💰 𝗕𝗮𝗹𝗮𝗻𝗰𝗲: ${balance}\n"
        "💸 Total Spent: ${spent}\n"
        "🎁 Referral Earnings: ${ref_earnings}\n"
        "👥 Referrals: {ref_count}\n"
        "{discount_info}"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "account_discount_info": "🎫 You have {discount}% discount!\n",

    # ── Purchases ─────────────────────────────
    "purchases_title":    "🧾 𝗠𝘆 𝗣𝘂𝗿𝗰𝗵𝗮𝘀𝗲𝘀:",
    "no_purchases":       "📭 No purchases yet.",
    "purchase_item": (
        "🎮 {mod_name}\n"
        "⏳ {days} Day(s)\n"
        "🔑 Key: <code>{key}</code>\n"
        "💰 ${price} │ 📅 {date}\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "purchase_item_file": (
        "🎮 {mod_name}\n"
        "⏳ {days} Day(s)\n"
        "📁 File Product\n"
        "💰 ${price} │ 📅 {date}\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),

    # ── Add Balance ───────────────────────────
    "add_balance_title": (
        "💳 𝗔𝗱𝗱 𝗕𝗮𝗹𝗮𝗻𝗰𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Select amount:"
    ),
    "add_balance_amount_1":  "💵 $1",
    "add_balance_amount_3":  "💵 $3",
    "add_balance_amount_5":  "💵 $5",
    "add_balance_amount_10": "💵 $10",
    "select_payment_method": (
        "💳 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗠𝗲𝘁𝗵𝗼𝗱\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 Amount: ${amount}\n"
        "━━━━━━━���━━━━━━━━━━━━━━\n"
        "Choose method:"
    ),
    "no_payment_methods": "❌ No payment methods available.",
    "payment_request_message": (
        "📋 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 𝗥𝗲𝗾𝘂𝗲𝘀𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "📛 Name: {name}\n"
        "💳 Method: {payment_method}\n"
        "🔗 Username: {username}\n"
        "💰 Amount: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👨‍💻 Contact: {dev_username}\n"
        "📩 Send this info to complete payment"
    ),
    "btn_contact_dev": "📤 Contact Developer",

    # ── Coupons ───────────────────────────────
    "coupon_prompt": (
        "🎫 𝗨𝘀𝗲 𝗖𝗼𝘂𝗽𝗼𝗻\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎁 Enter your code!\n\n"
        "✨ Rewards:\n"
        "   💰 Free Balance\n"
        "   🎉 Discount\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Enter code below ⬇️"
    ),
    "coupon_invalid": "❌ Invalid or expired code.",
    "coupon_used":    "⚠️ This coupon was already used!",
    "coupon_balance_success": (
        "🎉 𝗖𝗼𝗻𝗴𝗿𝗮𝘁𝘂𝗹𝗮𝘁𝗶𝗼𝗻𝘀!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 You received: ${amount}\n"
        "💳 New balance: ${balance}\n\n"
        "Thank you! 🚀"
    ),
    "coupon_discount_success": (
        "🎉 𝗖𝗼𝗻𝗴𝗿𝗮𝘁𝘂𝗹𝗮𝘁𝗶𝗼𝗻𝘀!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎁 You got: {discount}% discount\n"
        "📌 Valid for next purchase!\n\n"
        "Enjoy! 🛒"
    ),

    # ── Admin Panel ───────────────────────────
    "admin_panel":           "⚙️ 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹\nChoose action:",
    "admin_add_mod":         "➕ Add Mod",
    "admin_manage_mods":     "📋 Manage Mods",
    "admin_add_key":         "🔑 Add Product",
    "admin_referral_set":    "💰 Referral Settings",
    "admin_tickets":         "🎫 Tickets",
    "admin_payment_methods": "💳 Payment Methods",
    "admin_gift_link":       "🎁 Gift Link",
    "admin_broadcast":       "📢 Broadcast",
    "admin_leaderboard":     "🏆 Leaderboard",
    "admin_create_coupon":   "🎫 Create Coupon",
    "admin_stats":           "📊 Statistics",
    "admin_settings":        "⚙️ Settings",
    "admin_spin_wheel":      "🎰 Spin Wheel",
    "admin_balance_msg":     "💰 Balance Message",
    "admin_dm_user":         "📨 DM User",
    "admin_backup":          "💾 Export Data",
    "backup_caption": (
        "💾 <b>Bot Data Backup</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 Users: {users}\n"
        "💰 Total balance: ${balance}\n"
        "🧾 Purchases: {purchases}\n"
        "🔑 Keys: {keys}\n"
        "🎮 Mods: {mods}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📌 Keep this file. Place it as bot_data_backup.db next to the bot "
        "files when updating; all data is restored automatically on startup."
    ),
    "backup_failed":         "❌ Backup failed: {error}",
    "add_balance":           "💰 Add Balance",
    "deduct_balance":        "💸 Deduct Balance",

    # ── Admin Mod Management ──────────────────
    "enter_mod_name":       "📝 Enter new mod name:",
    "mod_added":            "✅ Mod added: {name}",
    "mod_exists":           "⚠️ Mod already exists.",
    "select_mod_to_manage": "📋 Select mod to manage:",
    "mod_actions":          "⚙️ Manage: {name}\nChoose action:",
    "btn_edit_mod":         "✏️ Edit Name",
    "btn_delete_mod":       "🗑 Delete Mod",
    "btn_view_keys":        "🔑 View Products",
    "btn_edit_price":       "💰 Edit Price",
    "btn_view_keys_detail": "🔍 View Details",
    "enter_new_mod_name":   "✏️ Enter new mod name:",
    "mod_updated":          "✅ Mod name updated.",
    "mod_deleted":          "✅ Mod and all products deleted.",
    "confirm_delete_mod":   "⚠️ Delete '{name}' and all its products?",

    # ── Admin Add Product ─────────────────────
    "select_mod_for_key":  "🎮 Select mod to add product to:",
    "no_mods_for_key":     "❌ No mods. Add one first.",
    "select_duration":     "⏱ Select duration:",
    "select_product_type": (
        "📦 Select product type:\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔑 Key - Add text keys\n"
        "📁 File - Upload a file for sale"
    ),
    "select_duration_edit": "⏱ Select duration to edit price:",
    "enter_price":          "💰 Enter price (USD):\nExample: 3.89",
    "enter_new_price":      "💰 Enter new price:\nCurrent: ${old_price}",
    "invalid_price":        "❌ Invalid price.",
    "price_updated":        "✅ Updated {count} product(s) to ${new_price}",
    "no_keys_to_update":    "❌ No products for this duration",
    "enter_keys": (
        "🔑 Enter keys (one per line):\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Mod: {mod_name}\n"
        "Duration: {days} Day(s)\n"
        "Price: ${price}"
    ),
    "keys_added":     "✅ {count} key(s) added.",
    "keys_duplicate": "⚠️ {count} duplicate(s) skipped.",

    # ── File Product Flow ─────────────────────
    "enter_file_price": (
        "💰 Enter file price (USD):\n"
        "Example: 5.00"
    ),
    "enter_file_quantity": (
        "📦 Enter available quantity:\n"
        "Example: 10\n\n"
        "💡 This many copies will be available"
    ),
    "enter_file_description": (
        "📝 Enter file description (optional):\n\n"
        "💡 Shown to user on purchase\n"
        "Type 'skip' to skip"
    ),
    "send_file_now": (
        "📁 Send the file now:\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Mod: {mod_name}\n"
        "Duration: {days} Day(s)\n"
        "Price: ${price}\n"
        "Quantity: {quantity}"
    ),
    "file_product_added": (
        "✅ File added successfully!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📁 File: {file_name}\n"
        "💰 Price: ${price}\n"
        "📦 Quantity: {quantity} copies\n"
        "📝 Description: {description}"
    ),
    "invalid_quantity": "❌ Invalid quantity. Enter a number > 0.",
    "file_not_sent":    "❌ Please send a valid file.",

    # ── Keys List ─────────────────────────────
    "keys_list_title": (
        "🔑 Products: {mod_name}\n"
        "⏱ {days} day(s) | 💰 ${price}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{keys_preview}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📊 Total: {total}"
    ),
    "key_item_available":  "✅ <code>{key}</code>",
    "key_item_sold":       "❌ <code>{key}</code> (sold {date})",
    "file_item_available": "✅ 📁 File available",
    "file_item_sold":      "❌ 📁 File (sold {date})",

    # ── Admin Referral ────────────────────────
    "current_ref_reward": "💰 Current reward: ${reward}\nEnter new value:",
    "invalid_reward":     "❌ Invalid value.",
    "reward_updated":     "✅ Reward updated to ${reward}",

    # ── Tickets ───────────────────────────────
    "no_tickets":       "📭 No open tickets.",
    "ticket_item": (
        "🎫 Ticket #{ticket_id}\n"
        "👤 {user_name} (ID: {user_id})\n"
        "📅 {date}\n"
        "💬 {message}"
    ),
    "btn_reply_ticket": "💬 Reply",
    "enter_reply":      "✏️ Write reply for ticket #{ticket_id}:",
    "reply_sent":       "✅ Reply sent.",
    "ticket_closed":    "✅ Ticket closed.",

    # ── DM User ───────────────────────────────
    "dm_user_prompt":  "🆔 Enter user ID to send message to:",
    "dm_user_message": (
        "📝 Send message or photo now:\n"
        "Delivered directly to that user only"
    ),
    "dm_user_success": "✅ Message sent to user {user_id}",
    "dm_user_failed":  "❌ Failed to send to {user_id}\nUser may have blocked the bot.",

    # ── Balance Message ───────────────────────
    "balance_msg_prompt": (
        "💰 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 𝗠𝗲𝘀𝘀𝗮𝗴𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Send balance info to all users with balance > 0\n"
        "Includes:\n"
        "• Current balance\n"
        "• Referral count\n"
        "• User ID\n\n"
        "Send now?"
    ),
    "balance_msg_template": (
        "💰 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 𝗜𝗻𝗳𝗼\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "💳 Your Balance: ${balance}\n"
        "👥 Referrals: {ref_count}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔄 Bot will be updated soon\n"
        "You can recover your balance by contacting support"
    ),
    "balance_msg_started": "🚀 Sending balance messages...",
    "balance_msg_done":    "✅ Done!\n✅ Success: {success}\n❌ Failed: {failed}",

    # ── Payment Methods ───────────────────────
    "payment_methods_list":         "💳 Payment Methods:",
    "add_payment_method":           "➕ Add Method",
    "enter_method_name_ar":         "📝 Method name in Arabic:",
    "enter_method_name_en":         "📝 Method name in English:",
    "enter_method_instructions_ar": "📝 Instructions in Arabic (or 'skip'):",
    "enter_method_instructions_en": "📝 Instructions in English (or 'skip'):",
    "payment_method_added":         "✅ Payment method added!",
    "payment_method_deleted":       "✅ Payment method deleted.",
    "btn_toggle_method":            "🔄 Enable/Disable",
    "btn_delete_method":            "🗑 Delete",
    "confirm_delete_payment":       "⚠️ Delete '{name}'?",

    # ── Broadcast ─────────────────────────────
    "broadcast_prompt": (
        "📢 𝗕𝗿𝗼𝗮𝗱𝗰𝗮𝘀𝘁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Write message for all users\n"
        "💡 You can attach a photo"
    ),
    "broadcast_confirm": (
        "📢 Confirm Broadcast\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 Users: {count}\n"
        "📝 Message:\n{message}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Send?"
    ),
    "broadcast_started":   "🚀 Broadcasting to all users...",
    "broadcast_completed": (
        "✅ Broadcast Complete!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "✅ Success: {success}\n"
        "❌ Failed: {failed}\n"
        "👥 Total: {total}"
    ),

    # ── Leaderboard ───────────────────────────
    "leaderboard_title": (
        "🏆 𝗟𝗲𝗮𝗱𝗲𝗿𝗯𝗼𝗮𝗿𝗱\n"
        "💰 Top Balances\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "leaderboard_item": (
        "{rank} {name}\n"
        "   🆔 {user_id} | 👤 {username}\n"
        "   💰 ${balance} | 💸 ${spent}"
    ),
    "leaderboard_empty": "📭 No users with $0.50+ balance",

    # ── Coupons Management ────────────────────
    "coupon_type_select":   "🎫 Select coupon type:",
    "btn_coupon_balance":   "💰 Free Balance",
    "btn_coupon_discount":  "🎉 Discount",
    "enter_coupon_balance": "💰 Enter value (USD):\nExample: 5",
    "enter_coupon_discount":"🎁 Enter discount (%):\nExample: 10",
    "coupon_created": (
        "✅ 𝗖𝗼𝘂𝗽𝗼𝗻 𝗖𝗿𝗲𝗮𝘁𝗲𝗱!\n\n"
        "🔑 Code: <code>{code}</code>\n"
        "{info}\n"
        "📊 Type: {type}"
    ),
    "coupon_info_balance":  "💰 Value: ${value}",
    "coupon_info_discount": "🎉 Discount: {value}%",
    "coupon_type_balance":  "Free Balance",
    "coupon_type_discount": "Discount",

    # ── Settings ──────────────────────────────
    "settings_menu":      "⚙️ 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀\nChoose:",
    "maintenance_mode":   "🔧 Maintenance Mode",
    "maintenance_status": (
        "🔧 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 𝗠𝗼𝗱𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Status: {status}"
    ),
    "maintenance_enabled":     "✅ Maintenance enabled",
    "maintenance_disabled":    "✅ Maintenance disabled",
    "btn_enable_maintenance":  "🔴 Enable Maintenance",
    "btn_disable_maintenance": "🟢 Disable Maintenance",
    "status_active":           "🔴 Active",
    "status_inactive":         "🟢 Inactive",

    # ── Commission Settings ───────────────────
    "recharge_commission": "💰 Recharge Commission",
    "recharge_commission_status": (
        "💰 𝗖𝗼𝗺𝗺𝗶𝘀𝘀𝗶𝗼𝗻 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Status: {status}\n"
        "Rate: {rate}%"
    ),
    "enter_commission_rate": "💰 Enter commission rate (%):",
    "commission_updated":    "✅ Rate updated to {rate}%",
    "invalid_commission":    "❌ Invalid (0-100)",
    "btn_edit_commission":   "✏️ Edit Rate",
    "btn_toggle_commission": "🔄 Enable/Disable",
    "commission_enabled":    "✅ Commission enabled",
    "commission_disabled":   "⚠️ Commission disabled",

    # ── Referral Settings ─────────────────────
    "referral_system": "🎁 Referral System",
    "referral_system_status": (
        "🎁 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Status: {status}\n"
        "Reward: ${reward}"
    ),
    "btn_toggle_referral": "🔄 Enable/Disable",
    "btn_edit_referral":   "✏️ Edit Reward",
    "referral_enabled":    "✅ Referral enabled",
    "referral_disabled":   "⚠️ Referral disabled",

    # ── Spin Wheel ────────────────────────────
    "spin_wheel_settings": (
        "🎰 𝗦𝗽𝗶𝗻 𝗪𝗵𝗲𝗲𝗹 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "❌ Nothing: {no_prize}%\n"
        "💰 Balance: {balance}%\n"
        "🎫 Discount 5%: {discount5}%\n"
        "🎫 Discount 7%: {discount7}%\n"
        "💵 Balance Value: ${balance_value}"
    ),
    "btn_edit_spin_chances":    "✏️ Edit Chances",
    "btn_edit_spin_balance":    "💰 Edit Balance Value",
    "enter_spin_chances": (
        "📊 Enter chances (sum = 100%)\n"
        "Format: NoPrize,Balance,Disc5,Disc7\n"
        "Example: 60, 25, 10, 5"
    ),
    "enter_spin_balance_value": "💰 Enter balance value:\nExample: 0.10",
    "spin_chances_updated":     "✅ Chances updated!",
    "spin_balance_updated":     "✅ Balance value updated to ${value}",
    "invalid_spin_format":      "❌ Invalid format.",

    # ── Gift Links ────────────────────────────
    "gift_link_setup":    "🎁 Enter gift amount:\nExample: 1.00",
    "gift_enter_uses":    "👥 Max uses (0 = unlimited):",
    "gift_enter_expiry":  "📅 Expiry in hours (0 = no expiry):",
    "gift_created": (
        "✅ 𝗚𝗶𝗳𝘁 𝗟𝗶𝗻𝗸 𝗖𝗿𝗲𝗮𝘁𝗲𝗱!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 {link}\n"
        "💰 Amount: ${amount}\n"
        "👥 Uses: {uses}\n"
        "📅 Expiry: {expiry}"
    ),
    "gift_claimed":         "🎁 Gift claimed! ${amount} added.",
    "gift_already_claimed": "⚠️ Already claimed.",
    "gift_expired":         "❌ Link expired.",
    "gift_max_uses":        "❌ Usage limit reached.",
    "gift_invalid":         "❌ Invalid link.",

    # ── Stats ─────────────────────────────────
    "stats_title": (
        "📊 𝗦𝘁𝗮𝘁𝘀\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 Users: {users}\n"
        "🛒 Sales: {sales}\n"
        "💰 Revenue: ${revenue}\n"
        "🔑 Products left: {keys}\n"
        "🎫 Open tickets: {tickets}"
    ),

    "duration_days": {
        1: "1 Day", 3: "3 Days", 7: "7 Days",
        15: "15 Days", 30: "30 Days"
    },

    # ── Balance Management ────────────────────
    "enter_user_id_balance": "🆔 Enter user ID:",
    "enter_amount_balance":  "💰 Enter amount to add:",
    "enter_amount_deduct":   "💸 Enter amount to deduct:",
    "balance_added":         "✅ Added ${amount} to {name}",
    "balance_deducted":      "✅ Deducted ${amount} from {name}\n💰 New balance: ${balance}",
    "invalid_user":          "❌ User not found.",
    "invalid_amount":        "❌ Invalid amount.",
    "insufficient_balance_deduct": (
        "❌ Insufficient balance!\n"
        "💰 Balance: ${balance}\n"
        "💸 Required: ${amount}"
    ),
    # ── Forced Subscription (NEW) ─────────────
    "force_sub_message": (
        "🔒 <b>Join our channel to continue</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📢 Subscribe to the channel first, then press the verify button below.\n\n"
        "👇 Join using the button:"
    ),
    "force_sub_not_joined": "❌ You haven't joined yet! Join the channel then press verify.",
    "force_sub_ok": "✅ Subscription verified successfully!",
    "btn_join_channel": "📢 Join Channel",
    "btn_verify_join": "✅ Verify Subscription",

    # ── Instagram step (one-time, no verify) ──
    "instagram_message": (
        "📸 <b>One last step</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🙏 Please follow us on Instagram to support us.\n"
        "Tap the button to open the profile, then press \"Done\" to continue."
    ),
    "btn_open_instagram": "📸 Open Instagram",
    "btn_instagram_done": "✅ Done / Continue",

    # ── Admin: Forced Subscription ────────────
    "force_sub_system": "🔒 Forced Subscription",
    "force_sub_status": (
        "🔒 <b>Forced Subscription</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Status: {status}\n\n"
        "When enabled, no user can use the bot before joining the channel."
    ),
    "force_sub_enabled_msg": "✅ Forced subscription enabled",
    "force_sub_disabled_msg": "❌ Forced subscription disabled",
    "btn_enable_force_sub": "✅ Enable Forced Subscription",
    "btn_disable_force_sub": "❌ Disable Forced Subscription",
}