AR = {
    # ── General ──────────────────────────────
    "choose_language":      "🌐 اختر لغتك المفضلة:",
    "language_set":         "✅ تم تعيين اللغة إلى العربية.",
    "main_menu":            "🏠 <b>القائمة الرئيسية</b>\nأهلاً بك {name}! اختر ما تريد:",
    "back":                 "🔙 رجوع",
    "cancel":               "❌ إلغاء",
    "confirm":              "✅ تأكيد",
    "error":                "❌ حدث خطأ، يرجى المحاولة مجدداً.",
    "not_authorized":       "⛔ غير مصرح لك.",
    "operation_cancelled":  "❌ تم إلغاء العملية.",

    # ── Maintenance ───────────────────────────
    "maintenance_mode_active": "🔧 البوت قيد الصيانة",
    "maintenance_mode_message": (
        "🔧 <b>البوت قيد الصيانة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "يعمل فريقنا على تطوير البوت وإضافة مميزات جديدة! 🚀\n\n"
        "⏰ سيتم إعلامك فور انتهاء الصيانة.\n\n"
        "نعتذر عن الإزعاج ونشكرك على صبرك. 💙"
    ),
    "maintenance_complete_message": (
        "🎉 <b>عاد البوت للعمل</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "مرحباً بك من جديد! 💙\n\n"
        "✅ البوت عاد للعمل بشكل طبيعي 🚀\n\n"
        "شكراً لصبرك! ❤️"
    ),

    # ── Buttons ───────────────────────────────
    "btn_store":        "🛒 متجر",
    "btn_referral":     "🎁 إحالة",
    "btn_commission":   "💼 عمولة",
    "btn_account":      "👤 حسابي",
    "btn_purchases":    "🧾 مشترياتي",
    "btn_add_balance":  "💳 شراء رصيد",
    "btn_daily_gift":   "🎁 هدية يومية",
    "btn_coupon":       "🎫 كوبون",
    "btn_help":         "🆘 مساعدة",
    "btn_admin":        "⚙️ لوحة تحكم",
    "btn_language":     "🌐 Language",
    "btn_spin":         "🎰 Spin",
    "btn_send_support": "📩 إرسال رسالة للدعم",
    "btn_instructions": "📘 تعليمات الاستخدام",
    "btn_product_key":  "مفتاح",
    "btn_product_file": "ملف",

    # ── Support / Help ────────────────────────
    "help_menu": (
        "🆘 <b>الدعم والمساعدة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "كيف يمكننا مساعدتك؟\n"
        "اختر أحد الخيارات أدناه:"
    ),
    "instructions_text": (
        "📘 <b>تعليمات الاستخدام</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "1️⃣ اضغط على 🛒 متجر لعرض المنتجات المتاحة\n\n"
        "2️⃣ اختر المنتج والمدة المناسبة لك\n\n"
        "3️⃣ تأكد من وجود رصيد كافٍ قبل الشراء\n"
        "   • اضغط 💳 شراء رصيد لإضافة رصيد\n\n"
        "4️⃣ بعد الشراء يصلك المفتاح أو الملف فوراً\n\n"
        "5️⃣ شارك رابط الإحالة لكسب رصيد مجاني 🎁\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💡 للمساعدة الإضافية تواصل مع الدعم"
    ),
    "support_prompt": (
        "📩 <b>إرسال رسالة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "اكتب رسالتك وسنرد عليك في أقرب وقت.\n"
        "يمكنك إرفاق صورة مع رسالتك (اختياري)."
    ),
    "support_received": "✅ شكراً لتواصلك، سيتم الرد عليك قريباً.",
    "support_reply": (
        "📩 <b>رد من الدعم</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{message}"
    ),

    # ── Store ─────────────────────────────────
    "store_title": "🛒 <b>المتجر</b>\nاختر الـ Mod Menu الذي تريده:",
    "no_mods":     "📭 لا توجد مودات متاحة حالياً.",
    "mod_details": (
        "🎮 <b>المود</b>: {mod_name}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{durations}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👇 اختر المدة أدناه:"
    ),
    "duration_line":    "⏱ {days} يوم\n   💰 ${price}\n   📦 {stock}\n",
    "in_stock":         "✅ متوفر",
    "low_stock":        "⚠️ متبقي {count} فقط",
    "out_of_stock":     "❌ نفد المخزون",
    "buy_btn":          "⏱ {days} يوم - ${price}",
    "confirm_purchase": (
        "🛒 <b>تأكيد الشراء</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 المود: {mod_name}\n"
        "⏱ المدة: {days} يوم\n"
        "💰 السعر: ${price}\n"
        "💳 رصيدك: ${balance}\n"
        "{discount_info}"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "هل تريد المتابعة؟"
    ),
    "discount_info_text":   "🎁 لديك خصم {discount}%!\n💵 السعر بعد الخصم: ${final}\n",
    "insufficient_balance": (
        "❌ <b>الرصيد غير كافٍ</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 رصيدك: ${balance}\n"
        "💸 المطلوب: ${price}\n"
        "📉 النقص: ${diff}"
    ),
    "purchase_success": (
        "✅ <b>تمت عملية الشراء</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 المود: {mod_name}\n"
        "⏱ المدة: {days} يوم\n"
        "🔑 المفتاح: <code>{key}</code>\n"
        "💰 المدفوع: ${price}\n"
        "💳 الرصيد المتبقي: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "شكراً لشرائك! 🎉"
    ),
    "purchase_success_file": (
        "✅ <b>تمت عملية الشراء</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 المود: {mod_name}\n"
        "⏱ المدة: {days} يوم\n"
        "📁 الملف أدناه 👇\n"
        "💰 المدفوع: ${price}\n"
        "💳 الرصيد المتبقي: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "شكراً لشرائك! 🎉"
    ),
    "purchase_success_discount": (
        "✅ <b>تمت عملية الشراء</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎮 المود: {mod_name}\n"
        "⏱ المدة: {days} يوم\n"
        "🔑 المفتاح: <code>{key}</code>\n"
        "💰 السعر الأصلي: ${original}\n"
        "🎁 الخصم: -{discount}%\n"
        "💵 المدفوع: ${final}\n"
        "💳 الرصيد المتبقي: ${balance}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "شكراً لشرائك! 🎉"
    ),
    "out_of_stock_err":  "❌ نفدت المنتجات لهذه المدة! جرب مدة أخرى.",
    "no_keys_available": "❌ لا توجد منتجات متاحة لهذا الخيار.",

    # ── Referral ──────────────────────────────
    "referral_title": (
        "🎁 <b>نظام الإحالة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 رابط الإحالة الخاص بك:\n"
        "{link}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 عدد الإحالات: {count}\n"
        "💰 أرباح الإحالة: ${earnings}\n"
        "💵 مكافأة لكل إحالة: ${reward}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "شارك الرابط واكسب رصيداً مجاناً! 🚀"
    ),
    "referral_earned": (
        "🎁 <b>تم ربح إحالة</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👤 انضم: {name}\n"
        "💰 تم إضافة: ${amount}\n"
        "💵 رصيدك الجديد: ${balance}"
    ),

    # ── Commission ────────────────────────────
    "commission_title": (
        "💼 <b>نظام العمولة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 رابطك الخاص:\n"
        "{link}\n\n"
        "📌 كيف تربح عمولة؟\n"
        "1. شارك رابطك مع أصدقائك\n"
        "2. عندما يشحنون رصيدهم\n"
        "3. تحصل على {rate}% عمولة!\n\n"
        "💰 أرباحك الكلية: ${earnings}\n"
        "👥 عدد إحالاتك: {count}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "شارك الرابط الآن! 🚀"
    ),
    "commission_earned": (
        "💰 <b>تم ربح عمولة</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "قام {name} بشحن رصيده\n"
        "💵 المبلغ المشحون: ${recharge}\n"
        "📊 نسبة العمولة: {rate}%\n"
        "💰 عمولتك: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💳 تمت الإضافة لرصيدك! 🚀"
    ),
    "recharge_commission_earned": (
        "💰 <b>تم ربح عمولة</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "قام {user_name} بشحن رصيده\n"
        "💵 المبلغ المشحون: ${recharge}\n"
        "📊 نسبة العمولة: {rate}%\n"
        "💰 عمولتك: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💳 تمت الإضافة لرصيدك! 🚀"
    ),

    # ── Balance Notification ──────────────────
    "balance_added_notification": (
        "💰 <b>تمت إضافة رصيد</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "✅ تمت إضافة ${amount} إلى رصيدك!\n"
        "💳 رصيدك الجديد: ${balance}"
    ),

    # ── Daily Gift ────────────────────────────
    "daily_gift_info": (
        "🎁 <b>الهدية اليومية</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎰 جوائز اليوم:\n\n"
        "💰 {balance} رصيد مجاني\n"
        "🎫 خصم {discount5}% على الشراء\n"
        "🎫 خصم {discount7}% على الشراء\n"
        "❌ حظ أوفر المرة القادمة\n\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "اضغط على زر \"🎰 Spin\" للدوران!\n"
        "⏰ مرة واحدة كل 24 ساعة"
    ),
    "spinning":          "🎰 جاري الدوران...",
    "spin_wait": (
        "⏰ عد لاحقاً!\n"
        "⏳ الوقت المتبقي: {hours} ساعة و {minutes} دقيقة\n\n"
        "عد غداً لفرصة جديدة! 🎁"
    ),
    "spin_no_prize": (
        "😔 <b>لا جائزة هذه المرة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "لا تقلق! الحظ قادم 🍀\n"
        "عد غداً لفرصة جديدة! 🎁"
    ),
    "spin_win_balance": (
        "🎉 <b>مبروك</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 الجائزة: ${amount}\n"
        "💳 رصيدك الجديد: ${balance}\n\n"
        "عد غداً لفرصة جديدة! 🎁"
    ),
    "spin_win_discount": (
        "🎉 <b>مبروك</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎫 الجائزة: خصم {discount}%\n"
        "📌 يمكنك استخدامه في عملية الشراء التالية!\n\n"
        "عد غداً لفرصة جديدة! 🎁"
    ),

    # ── Account ───────────────────────────────
    "account_title": (
        "👤 <b>حسابي</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "📛 الاسم: {name}\n"
        "💰 <b>الرصيد</b>: ${balance}\n"
        "💸 إجمالي المصروف: ${spent}\n"
        "🎁 أرباح الإحالة: ${ref_earnings}\n"
        "👥 عدد الإحالات: {ref_count}\n"
        "{discount_info}"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "account_discount_info": "🎫 لديك خصم {discount}% للاستخدام!\n",

    # ── Purchases ─────────────────────────────
    "purchases_title":    "🧾 <b>مشترياتي</b>:",
    "no_purchases":       "📭 لا توجد مشتريات بعد.",
    "purchase_item": (
        "🎮 {mod_name}\n"
        "⏳ {days} يوم\n"
        "🔑 المفتاح: <code>{key}</code>\n"
        "💰 ${price} │ 📅 {date}\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "purchase_item_file": (
        "🎮 {mod_name}\n"
        "⏳ {days} يوم\n"
        "📁 منتج ملف\n"
        "💰 ${price} │ 📅 {date}\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),

    # ── Add Balance ───────────────────────────
    "add_balance_title": (
        "💳 <b>شراء رصيد</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "اختر المبلغ الذي تريد شحنه:"
    ),
    "add_balance_amount_1":  "💵 1$",
    "add_balance_amount_3":  "💵 3$",
    "add_balance_amount_5":  "💵 5$",
    "add_balance_amount_10": "💵 10$",
    "select_payment_method": (
        "💳 <b>طريقة الدفع</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 المبلغ: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "اختر الطريقة المناسبة:"
    ),
    "no_payment_methods": "❌ لا توجد طرق دفع متاحة.\nتواصل مع المطور.",
    "payment_request_message": (
        "📋 <b>طلب شحن رصيد</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "📛 الاسم: {name}\n"
        "💳 طريقة الدفع: {payment_method}\n"
        "🔗 اليوزر: {username}\n"
        "💰 المبلغ: ${amount}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👨‍💻 تواصل مع المطور: {dev_username}\n"
        "📩 أرسل هذه المعلومات لإتمام الدفع"
    ),
    "btn_contact_dev": "📤 إرسال إلى المطور",

    # ── Coupons ───────────────────────────────
    "coupon_prompt": (
        "🎫 <b>استخدام كوبون</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎁 أدخل الكود للحصول على مكافأتك!\n\n"
        "✨ المكافآت المتاحة:\n"
        "   💰 رصيد مجاني\n"
        "   🎉 خصم على المشتريات\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "أدخل الكود أدناه ⬇️"
    ),
    "coupon_invalid": "❌ كود غير صحيح أو منتهي الصلاحية.",
    "coupon_used":    "⚠️ تم استخدام هذا الكوبون مسبقاً!",
    "coupon_balance_success": (
        "🎉 <b>مبروك</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "💰 حصلت على: ${amount}\n"
        "💳 رصيدك الجديد: ${balance}\n\n"
        "شكراً! 🚀"
    ),
    "coupon_discount_success": (
        "🎉 <b>مبروك</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🎁 حصلت على: خصم {discount}%\n"
        "📌 ساري على عملية الشراء التالية!\n\n"
        "استمتع بالتسوق! 🛒"
    ),

    # ── Admin Panel ───────────────────────────
    "admin_panel":           "⚙️ <b>لوحة التحكم</b>\nاختر الإجراء:",
    "admin_add_mod":         "➕ إضافة مود",
    "admin_manage_mods":     "📋 إدارة المودات",
    "admin_add_key":         "🔑 إضافة منتج",
    "admin_referral_set":    "💰 تعديل الإحالة",
    "admin_tickets":         "🎫 التذاكر",
    "admin_payment_methods": "💳 طرق الدفع",
    "admin_gift_link":       "🎁 رابط هدية",
    "admin_broadcast":       "📢 رسالة جماعية",
    "admin_leaderboard":     "🏆 المتصدرين",
    "admin_create_coupon":   "🎫 إنشاء كوبون",
    "admin_stats":           "📊 الإحصائيات",
    "admin_settings":        "⚙️ الإعدادات",
    "admin_spin_wheel":      "🎰 عجلة الحظ",
    "admin_balance_msg":     "💰 رسالة الرصيد",
    "admin_dm_user":         "📨 رسالة لمستخدم",
    "admin_backup":          "💾 سحب بيانات",
    "backup_caption": (
        "💾 <b>نسخة بيانات البوت</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 المستخدمون: {users}\n"
        "💰 إجمالي الأرصدة: ${balance}\n"
        "🧾 المشتريات: {purchases}\n"
        "🔑 المفاتيح: {keys}\n"
        "🎮 المودات: {mods}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📌 احتفظ بهذا الملف. ضعه باسم bot_data_backup.db مع ملفات البوت "
        "عند التحديث، وسيستعيد كل البيانات تلقائياً عند التشغيل."
    ),
    "backup_failed":         "❌ فشل سحب البيانات: {error}",
    "add_balance":           "💰 إضافة رصيد",
    "deduct_balance":        "💸 خصم رصيد",

    # ── Admin Mod Management ──────────────────
    "enter_mod_name":       "📝 أدخل اسم المود الجديد:",
    "mod_added":            "✅ تمت إضافة المود: {name}",
    "mod_exists":           "⚠️ هذا المود موجود بالفعل.",
    "select_mod_to_manage": "📋 اختر المود للإدارة:",
    "mod_actions":          "⚙️ إدارة المود: {name}\nاختر الإجراء:",
    "btn_edit_mod":         "✏️ تعديل الاسم",
    "btn_delete_mod":       "🗑 حذف المود",
    "btn_view_keys":        "🔑 عرض المنتجات",
    "btn_edit_price":       "💰 تعديل السعر",
    "btn_view_keys_detail": "🔍 تفاصيل المنتجات",
    "enter_new_mod_name":   "✏️ أدخل الاسم الجديد للمود:",
    "mod_updated":          "✅ تم تحديث اسم المود.",
    "mod_deleted":          "✅ تم حذف المود وجميع منتجاته.",
    "confirm_delete_mod":   "⚠️ هل أنت متأكد من حذف المود '{name}' وجميع منتجاته؟",

    # ── Admin Add Product ─────────────────────
    "select_mod_for_key":  "🎮 اختر المود لإضافة المنتج إليه:",
    "no_mods_for_key":     "❌ لا توجد مودات. أضف موداً أولاً.",
    "select_duration":     "⏱ اختر مدة المنتج:",
    "select_product_type": (
        "📦 اختر نوع المنتج:\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔑 مفتاح - إضافة مفاتيح نصية\n"
        "📁 ملف - رفع ملف للبيع"
    ),
    "select_duration_edit": "⏱ اختر المدة لتعديل سعرها:",
    "enter_price":          "💰 أدخل السعر (بالدولار):\nمثال: 3.89",
    "enter_new_price":      "💰 أدخل السعر الجديد:\nالسعر الحالي: ${old_price}",
    "invalid_price":        "❌ سعر غير صالح. أدخل رقماً صحيحاً.",
    "price_updated":        "✅ تم تحديث سعر {count} منتج إلى ${new_price}",
    "no_keys_to_update":    "❌ لا توجد منتجات متاحة لهذه المدة",
    "enter_keys": (
        "🔑 أدخل المفاتيح (مفتاح واحد في كل سطر):\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "المود: {mod_name}\n"
        "المدة: {days} يوم\n"
        "السعر: ${price}"
    ),
    "keys_added":      "✅ تمت إضافة {count} مفتاح.",
    "keys_duplicate":  "⚠️ تم تخطي {count} مكرر.",

    # ── File Product Flow ─────────────────────
    "enter_file_price": (
        "💰 أدخل سعر الملف (بالدولار):\n"
        "مثال: 5.00"
    ),
    "enter_file_quantity": (
        "📦 أدخل الكمية المتاحة للبيع:\n"
        "مثال: 10\n\n"
        "💡 هذا العدد من النسخ سيكون متاحاً للشراء"
    ),
    "enter_file_description": (
        "📝 أدخل وصف الملف (اختياري):\n\n"
        "💡 يظهر للمستخدم عند الشراء\n"
        "اكتب 'skip' للتخطي"
    ),
    "send_file_now": (
        "📁 أرسل الملف الآن:\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "المود: {mod_name}\n"
        "المدة: {days} يوم\n"
        "السعر: ${price}\n"
        "الكمية: {quantity}"
    ),
    "file_product_added": (
        "✅ تمت إضافة الملف بنجاح!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📁 الملف: {file_name}\n"
        "💰 السعر: ${price}\n"
        "📦 الكمية: {quantity} نسخة\n"
        "📝 الوصف: {description}"
    ),
    "invalid_quantity": "❌ كمية غير صالحة. أدخل رقماً أكبر من 0.",
    "file_not_sent":    "❌ يرجى إرسال ملف صالح.",

    # ── Keys List ─────────────────────────────
    "keys_list_title": (
        "🔑 منتجات {mod_name}\n"
        "⏱ المدة: {days} يوم | 💰 ${price}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "{keys_preview}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📊 الإجمالي: {total}"
    ),
    "key_item_available":  "✅ <code>{key}</code>",
    "key_item_sold":       "❌ <code>{key}</code> (مباع {date})",
    "file_item_available": "✅ 📁 ملف متاح",
    "file_item_sold":      "❌ 📁 ملف (مباع {date})",

    # ── Admin Referral ────────────────────────
    "current_ref_reward": "💰 قيمة الإحالة الحالية: ${reward}\nأدخل القيمة الجديدة:",
    "invalid_reward":     "❌ قيمة غير صالحة.",
    "reward_updated":     "✅ تم تحديث قيمة الإحالة إلى ${reward}",

    # ── Tickets ───────────────────────────────
    "no_tickets":       "📭 لا توجد تذاكر مفتوحة.",
    "ticket_item": (
        "🎫 تذكرة #{ticket_id}\n"
        "👤 {user_name} (ID: {user_id})\n"
        "📅 {date}\n"
        "💬 {message}"
    ),
    "btn_reply_ticket": "💬 رد",
    "enter_reply":      "✏️ اكتب ردك على التذكرة #{ticket_id}:",
    "reply_sent":       "✅ تم إرسال الرد.",
    "ticket_closed":    "✅ تم إغلاق التذكرة.",

    # ── DM User ───────────────────────────────
    "dm_user_prompt":  "🆔 أدخل ID المستخدم لإرسال الرسالة إليه:",
    "dm_user_message": (
        "📝 أرسل الرسالة أو الصورة الآن:\n"
        "ستصل للمستخدم مباشرة فقط"
    ),
    "dm_user_success": "✅ تم إرسال الرسالة للمستخدم {user_id}",
    "dm_user_failed":  "❌ فشل الإرسال للمستخدم {user_id}\nربما حظر البوت.",

    # ── Balance Message ───────────────────────
    "balance_msg_prompt": (
        "💰 <b>رسالة الرصيد</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "سيتم إرسال رسالة لجميع المستخدمين الذين لديهم رصيد\n"
        "تحتوي على:\n"
        "• رصيدهم الحالي\n"
        "• عدد إحالاتهم\n"
        "• ID الخاص بهم\n\n"
        "هل تريد الإرسال الآن؟"
    ),
    "balance_msg_template": (
        "💰 <b>معلومات الرصيد</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🆔 ID: <code>{user_id}</code>\n"
        "💳 رصيدك الحالي: ${balance}\n"
        "👥 إحالاتك: {ref_count}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔄 سيتم تحديث البوت قريباً\n"
        "يمكنك استرجاع رصيدك عبر التواصل مع الدعم"
    ),
    "balance_msg_started": "🚀 جاري إرسال رسائل الرصيد...",
    "balance_msg_done":    "✅ اكتمل!\n✅ نجح: {success}\n❌ فشل: {failed}",

    # ── Payment Methods ───────────────────────
    "payment_methods_list":           "💳 طرق الدفع:",
    "add_payment_method":             "➕ إضافة طريقة",
    "enter_method_name_ar":           "📝 اسم الطريقة بالعربية:",
    "enter_method_name_en":           "📝 اسم الطريقة بالإنجليزية:",
    "enter_method_instructions_ar":   "📝 التعليمات بالعربية (أو 'skip'):",
    "enter_method_instructions_en":   "📝 التعليمات بالإنجليزية (أو 'skip'):",
    "payment_method_added":           "✅ تمت إضافة طريقة الدفع!",
    "payment_method_deleted":         "✅ تم حذف طريقة الدفع.",
    "btn_toggle_method":              "🔄 تفعيل/تعطيل",
    "btn_delete_method":              "🗑 حذف",
    "confirm_delete_payment":         "⚠️ حذف طريقة الدفع '{name}'؟",

    # ── Broadcast ─────────────────────────────
    "broadcast_prompt": (
        "📢 <b>رسالة جماعية</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "اكتب الرسالة لإرسالها لجميع المستخدمين\n"
        "💡 يمكنك إرفاق صورة"
    ),
    "broadcast_confirm": (
        "📢 تأكيد الإرسال\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 المستخدمون: {count}\n"
        "📝 الرسالة:\n{message}\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "هل تريد الإرسال؟"
    ),
    "broadcast_started":   "🚀 جاري الإرسال لجميع المستخدمين...",
    "broadcast_completed": (
        "✅ اكتمل الإرسال!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "✅ نجح: {success}\n"
        "❌ فشل: {failed}\n"
        "👥 الإجمالي: {total}"
    ),

    # ── Leaderboard ───────────────────────────
    "leaderboard_title": (
        "🏆 <b>قائمة المتصدرين</b>\n"
        "💰 أعلى الأرصدة\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ),
    "leaderboard_item": (
        "{rank} {name}\n"
        "   🆔 {user_id} | 👤 {username}\n"
        "   💰 ${balance} | 💸 ${spent}"
    ),
    "leaderboard_empty": "📭 لا يوجد مستخدمون برصيد $0.50+",

    # ── Coupons Management ────────────────────
    "coupon_type_select":   "🎫 اختر نوع الكوبون:",
    "btn_coupon_balance":   "💰 رصيد مجاني",
    "btn_coupon_discount":  "🎉 خصم",
    "enter_coupon_balance": "💰 أدخل قيمة الرصيد:\nمثال: 5",
    "enter_coupon_discount":"🎁 أدخل نسبة الخصم (%):\nمثال: 10",
    "coupon_created": (
        "✅ <b>تم إنشاء الكوبون</b>!\n\n"
        "🔑 الكود: <code>{code}</code>\n"
        "{info}\n"
        "📊 النوع: {type}"
    ),
    "coupon_info_balance":  "💰 القيمة: ${value}",
    "coupon_info_discount": "🎉 الخصم: {value}%",
    "coupon_type_balance":  "رصيد مجاني",
    "coupon_type_discount": "خصم",

    # ── Settings ──────────────────────────────
    "settings_menu":      "⚙️ <b>الإعدادات</b>\nاختر الإعداد:",
    "maintenance_mode":   "🔧 وضع الصيانة",
    "maintenance_status": (
        "🔧 𝗠𝗮𝗶𝗻𝘁𝗲𝗻𝗮𝗻𝗰𝗲 <b>المود</b>𝗲\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "الحالة: {status}"
    ),
    "maintenance_enabled":    "✅ تم تفعيل وضع الصيانة",
    "maintenance_disabled":   "✅ تم إلغاء وضع الصيانة",
    "btn_enable_maintenance":  "🔴 تفعيل الصيانة",
    "btn_disable_maintenance": "🟢 إلغاء الصيانة",
    "status_active":           "🔴 مفعّل",
    "status_inactive":         "🟢 غير مفعّل",

    # ── Commission Settings ───────────────────
    "recharge_commission": "💰 عمولة الشحن",
    "recharge_commission_status": (
        "💰 𝗖𝗼𝗺𝗺𝗶𝘀𝘀𝗶𝗼𝗻 <b>الإعدادات</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "الحالة: {status}\n"
        "النسبة: {rate}%"
    ),
    "enter_commission_rate": "💰 أدخل نسبة العمولة (%):",
    "commission_updated":    "✅ تم تحديث نسبة العمولة إلى {rate}%",
    "invalid_commission":    "❌ نسبة غير صالحة (0-100)",
    "btn_edit_commission":   "✏️ تعديل النسبة",
    "btn_toggle_commission": "🔄 تفعيل/تعطيل",
    "commission_enabled":    "✅ تم تفعيل نظام العمولة",
    "commission_disabled":   "⚠️ تم تعطيل نظام العمولة",

    # ── Referral Settings ─────────────────────
    "referral_system": "🎁 نظام الإحالة",
    "referral_system_status": (
        "🎁 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹 <b>الإعدادات</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "الحالة: {status}\n"
        "المكافأة: ${reward}"
    ),
    "btn_toggle_referral": "🔄 تفعيل/تعطيل",
    "btn_edit_referral":   "✏️ تعديل المكافأة",
    "referral_enabled":    "✅ تم تفعيل نظام الإحالة",
    "referral_disabled":   "⚠️ تم تعطيل نظام الإحالة",

    # ── Spin Wheel ────────────────────────────
    "spin_wheel_settings": (
        "🎰 𝗦𝗽𝗶𝗻 𝗪𝗵𝗲𝗲𝗹 <b>الإعدادات</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "❌ لا شيء: {no_prize}%\n"
        "💰 رصيد: {balance}%\n"
        "🎫 خصم 5%: {discount5}%\n"
        "🎫 خصم 7%: {discount7}%\n"
        "💵 قيمة الرصيد: ${balance_value}"
    ),
    "btn_edit_spin_chances":  "✏️ تعديل النسب",
    "btn_edit_spin_balance":  "💰 تعديل قيمة الرصيد",
    "enter_spin_chances": (
        "📊 أدخل النسب (المجموع = 100%)\n"
        "الصيغة: لا_شيء, رصيد, خصم5, خصم7\n"
        "مثال: 60, 25, 10, 5"
    ),
    "enter_spin_balance_value": "💰 أدخل قيمة الرصيد:\nمثال: 0.10",
    "spin_chances_updated":     "✅ تم تحديث النسب!",
    "spin_balance_updated":     "✅ تم تحديث قيمة الرصيد إلى ${value}",
    "invalid_spin_format":      "❌ صيغة غير صحيحة.",

    # ── Gift Links ────────────────────────────
    "gift_link_setup":    "🎁 أدخل مبلغ الهدية:\nمثال: 1.00",
    "gift_enter_uses":    "👥 عدد مرات الاستخدام (0 = غير محدود):",
    "gift_enter_expiry":  "📅 مدة الصلاحية بالساعات (0 = بدون انتهاء):",
    "gift_created": (
        "✅ <b>تم إنشاء رابط الهدية</b>!\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔗 {link}\n"
        "💰 المبلغ: ${amount}\n"
        "👥 الاستخدامات: {uses}\n"
        "📅 الانتهاء: {expiry}"
    ),
    "gift_claimed":         "🎁 تم استلام هديتك! تمت إضافة ${amount} إلى رصيدك.",
    "gift_already_claimed": "⚠️ لقد استلمت هذه الهدية مسبقاً.",
    "gift_expired":         "❌ هذا الرابط منتهي الصلاحية.",
    "gift_max_uses":        "❌ تم استنفاد استخدامات هذا الرابط.",
    "gift_invalid":         "❌ رابط غير صالح.",

    # ── Stats ─────────────────────────────────
    "stats_title": (
        "📊 <b>الإحصائيات</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "👥 المستخدمون: {users}\n"
        "🛒 المبيعات: {sales}\n"
        "💰 الإيرادات: ${revenue}\n"
        "🔑 المنتجات المتبقية: {keys}\n"
        "🎫 التذاكر المفتوحة: {tickets}"
    ),

    "duration_days": {
        1: "1 يوم", 3: "3 أيام", 7: "7 أيام",
        15: "15 يوم", 30: "30 يوم"
    },

    # ── Balance Management ────────────────────
    "enter_user_id_balance": "🆔 أدخل ID المستخدم:",
    "enter_amount_balance":  "💰 أدخل المبلغ المراد إضافته:",
    "enter_amount_deduct":   "💸 أدخل المبلغ المراد خصمه:",
    "balance_added":         "✅ تمت إضافة ${amount} لـ {name}",
    "balance_deducted":      "✅ تم خصم ${amount} من {name}\n💰 الرصيد الجديد: ${balance}",
    "invalid_user":          "❌ المستخدم غير موجود.",
    "invalid_amount":        "❌ مبلغ غير صالح.",
    "insufficient_balance_deduct": (
        "❌ الرصيد غير كافي!\n"
        "💰 رصيد المستخدم: ${balance}\n"
        "💸 المطلوب: ${amount}"
    ),
    # ── Forced Subscription (NEW) ─────────────
    "force_sub_message": (
        "🔒 <b>للمتابعة، اشترك في قناتنا</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "📢 اشترك في القناة أولاً ثم اضغط زر التحقق بالأسفل.\n\n"
        "👇 اشترك من الزر التالي:"
    ),
    "force_sub_not_joined": "❌ لم تشترك بعد! اشترك في القناة ثم اضغط تحقق.",
    "force_sub_ok": "✅ تم التحقق من اشتراكك بنجاح!",
    "btn_join_channel": "📢 اشترك في القناة",
    "btn_verify_join": "✅ تحقق من الاشتراك",

    # ── Instagram step (one-time, no verify) ──
    "instagram_message": (
        "📸 <b>خطوة أخيرة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "🙏 رجاءً تابع حسابنا على إنستقرام لدعمنا.\n"
        "اضغط الزر لفتح الحساب، ثم اضغط \"تابعت\" للمتابعة."
    ),
    "btn_open_instagram": "📸 فتح إنستقرام",
    "btn_instagram_done": "✅ تابعت / متابعة",

    # ── Admin: Forced Subscription ────────────
    "force_sub_system": "🔒 الاشتراك الإجباري",
    "force_sub_status": (
        "🔒 <b>الاشتراك الإجباري</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "الحالة: {status}\n\n"
        "عند التفعيل، لا يمكن لأي مستخدم استخدام البوت قبل الاشتراك في القناة."
    ),
    "force_sub_enabled_msg": "✅ تم تفعيل الاشتراك الإجباري",
    "force_sub_disabled_msg": "❌ تم تعطيل الاشتراك الإجباري",
    "btn_enable_force_sub": "✅ تفعيل الاشتراك الإجباري",
    "btn_disable_force_sub": "❌ تعطيل الاشتراك الإجباري",
}