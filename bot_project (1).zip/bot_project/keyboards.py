from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import OWNER_ID
from locales.ar import AR
from locales.en import EN


def get_locale_kb(user_id: int) -> dict:
    from database import get_user_language
    lang = get_user_language(user_id)
    return AR if lang == "ar" else EN


# ── Language ──────────────────────────────────────────────────
def language_keyboard() -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("🇸🇦 العربية", callback_data="lang_ar"),
        InlineKeyboardButton("🇺🇸 English",  callback_data="lang_en")
    )
    return kb


# ── Forced Subscription ───────────────────────────────────────
def join_channel_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Shown when the user is NOT subscribed: join button + verify button."""
    L = get_locale_kb(user_id)
    from utils.subscription import channel_link
    kb = InlineKeyboardMarkup(row_width=1)
    link = channel_link()
    if link:
        kb.add(InlineKeyboardButton(L["btn_join_channel"], url=link))
    kb.add(InlineKeyboardButton(L["btn_verify_join"], callback_data="verify_join"))
    return kb


def instagram_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """One-time Instagram follow step: open profile + continue (no verify)."""
    L = get_locale_kb(user_id)
    from config import INSTAGRAM_URL
    kb = InlineKeyboardMarkup(row_width=1)
    if INSTAGRAM_URL:
        kb.add(InlineKeyboardButton(L["btn_open_instagram"], url=INSTAGRAM_URL))
    kb.add(InlineKeyboardButton(L["btn_instagram_done"], callback_data="instagram_done"))
    return kb


# ── Main Menu ─────────────────────────────────────────────────
def main_menu_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    from database import is_referral_enabled, is_commission_enabled

    kb = InlineKeyboardMarkup(row_width=2)
    buttons = [
        InlineKeyboardButton(L["btn_store"],       callback_data="store"),
        InlineKeyboardButton(L["btn_add_balance"], callback_data="add_balance"),
    ]

    if is_referral_enabled():
        buttons.append(
            InlineKeyboardButton(L["btn_referral"], callback_data="referral")
        )

    if is_commission_enabled():
        buttons.append(
            InlineKeyboardButton(L["btn_commission"], callback_data="commission")
        )

    buttons.extend([
        InlineKeyboardButton(L["btn_account"],    callback_data="account"),
        InlineKeyboardButton(L["btn_purchases"],  callback_data="purchases"),
        InlineKeyboardButton(L["btn_daily_gift"], callback_data="daily_gift"),
        InlineKeyboardButton(L["btn_coupon"],     callback_data="coupon"),
        InlineKeyboardButton(L["btn_help"],       callback_data="help"),
    ])

    kb.add(*buttons)

    # Admin button - owner only
    if user_id == OWNER_ID:
        kb.add(InlineKeyboardButton(L["btn_admin"], callback_data="admin"))

    kb.add(InlineKeyboardButton(L["btn_language"], callback_data="change_language"))
    return kb


# ── Store ─────────────────────────────────────────────────────
def mods_keyboard(mods: list, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    for mod in mods:
        kb.add(InlineKeyboardButton(
            f"🎮 {mod['name']}",
            callback_data=f"mod_{mod['mod_id']}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


def mod_buy_keyboard(mod_id: int, keys_summary: list,
                     user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    for row in keys_summary:
        duration = row["duration"]
        price    = row["price"]
        count    = row["cnt"]
        ptype    = row["product_type"]
        if count == 0:
            continue
        icon  = "🔑" if ptype == "key" else "📁"
        label = f"{icon} {duration} يوم - ${price:.2f}"
        kb.add(InlineKeyboardButton(
            label,
            callback_data=f"buy_{mod_id}_{duration}_{price}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="store"))
    return kb


def confirm_purchase_keyboard(mod_id: int, duration: int,
                               price: float,
                               user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(
            L["confirm"],
            callback_data=f"confirm_{mod_id}_{duration}_{price}"
        ),
        InlineKeyboardButton(
            L["cancel"],
            callback_data=f"mod_{mod_id}"
        )
    )
    return kb


# ── Add Balance ───────────────────────────────────────────────
def add_balance_amounts_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["add_balance_amount_1"],  callback_data="balance_1"),
        InlineKeyboardButton(L["add_balance_amount_3"],  callback_data="balance_3"),
        InlineKeyboardButton(L["add_balance_amount_5"],  callback_data="balance_5"),
        InlineKeyboardButton(L["add_balance_amount_10"], callback_data="balance_10"),
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


def payment_methods_keyboard(amount: int, user_id: int) -> InlineKeyboardMarkup:
    L    = get_locale_kb(user_id)
    from database import get_payment_methods, get_user_language
    methods = get_payment_methods()
    lang    = get_user_language(user_id)

    kb = InlineKeyboardMarkup(row_width=1)
    for method in methods:
        name = method["name_ar"] if lang == "ar" else method["name_en"]
        kb.add(InlineKeyboardButton(
            name,
            callback_data=f"pay_{method['method_id']}_{amount}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="add_balance"))
    return kb


def contact_dev_keyboard(user_id: int, dev_username: str) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(
        L["btn_contact_dev"],
        url=f"https://t.me/{dev_username.replace('@', '')}"
    ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


# ── Support ───────────────────────────────────────────────────
def support_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Help menu: Send message OR Instructions."""
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton(L["btn_send_support"], callback_data="send_support"),
        InlineKeyboardButton(L["btn_instructions"], callback_data="instructions"),
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


# ── Daily Gift ────────────────────────────────────────────────
def daily_gift_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(L["btn_spin"], callback_data="spin_wheel"))
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


# ── Admin Panel ───────────────────────────────────────────────
def admin_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["admin_add_mod"],         callback_data="adm_add_mod"),
        InlineKeyboardButton(L["admin_manage_mods"],     callback_data="adm_manage_mods"),
        InlineKeyboardButton(L["admin_add_key"],         callback_data="adm_add_key"),
        InlineKeyboardButton(L["admin_referral_set"],    callback_data="adm_ref_set"),
        InlineKeyboardButton(L["admin_tickets"],         callback_data="adm_tickets"),
        InlineKeyboardButton(L["admin_payment_methods"], callback_data="adm_payments"),
        InlineKeyboardButton(L["admin_gift_link"],       callback_data="adm_gift"),
        InlineKeyboardButton(L["admin_broadcast"],       callback_data="adm_broadcast"),
        InlineKeyboardButton(L["admin_leaderboard"],     callback_data="adm_leaderboard"),
        InlineKeyboardButton(L["admin_create_coupon"],   callback_data="adm_create_coupon"),
        InlineKeyboardButton(L["admin_stats"],           callback_data="adm_stats"),
        InlineKeyboardButton(L["admin_settings"],        callback_data="adm_settings"),
        InlineKeyboardButton(L["add_balance"],           callback_data="adm_add_balance"),
        InlineKeyboardButton(L["deduct_balance"],        callback_data="adm_deduct_balance"),
        InlineKeyboardButton(L["admin_dm_user"],         callback_data="adm_dm_user"),
        InlineKeyboardButton(L["admin_backup"],          callback_data="adm_backup"),
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="main_menu"))
    return kb


def admin_mods_keyboard(mods: list, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    for mod in mods:
        kb.add(InlineKeyboardButton(
            f"🎮 {mod['name']}",
            callback_data=f"adm_mod_{mod['mod_id']}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="admin"))
    return kb


def admin_mod_actions_keyboard(mod_id: int, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_edit_mod"],
                             callback_data=f"adm_edit_mod_{mod_id}"),
        InlineKeyboardButton(L["btn_delete_mod"],
                             callback_data=f"adm_del_mod_{mod_id}"),
        InlineKeyboardButton(L["btn_view_keys"],
                             callback_data=f"adm_view_keys_{mod_id}"),
        InlineKeyboardButton(L["btn_edit_price"],
                             callback_data=f"adm_edit_price_{mod_id}"),
        InlineKeyboardButton(L["btn_view_keys_detail"],
                             callback_data=f"adm_view_keys_detail_{mod_id}"),
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_manage_mods"))
    return kb


def confirm_delete_keyboard(mod_id: int, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["confirm"],
                             callback_data=f"adm_confirm_del_{mod_id}"),
        InlineKeyboardButton(L["cancel"],
                             callback_data=f"adm_mod_{mod_id}")
    )
    return kb


def admin_select_mod_for_key(mods: list, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    for mod in mods:
        kb.add(InlineKeyboardButton(
            f"🎮 {mod['name']}",
            callback_data=f"adm_key_mod_{mod['mod_id']}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="admin"))
    return kb


def duration_keyboard(mod_id: int, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=3)
    for d in [1, 3, 7, 15, 30]:
        label = L["duration_days"].get(d, f"{d} Days")
        kb.add(InlineKeyboardButton(
            label, callback_data=f"adm_dur_{mod_id}_{d}"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_add_key"))
    return kb


# ── Product Type Keyboard (Admin only - after duration) ───────
def product_type_keyboard(mod_id: int, duration: int,
                           user_id: int) -> InlineKeyboardMarkup:
    """
    Shown ONLY in admin flow after selecting duration.
    Choose: Key or File.
    """
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(
            "🔑 " + L["btn_product_key"],
            callback_data=f"adm_ptype_key_{mod_id}_{duration}"
        ),
        InlineKeyboardButton(
            "📁 " + L["btn_product_file"],
            callback_data=f"adm_ptype_file_{mod_id}_{duration}"
        )
    )
    kb.add(InlineKeyboardButton(
        L["back"], callback_data=f"adm_key_mod_{mod_id}"
    ))
    return kb


def duration_price_select_keyboard(mod_id: int, keys_info: list,
                                    user_id: int,
                                    action: str = "price") -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)

    for row in keys_info:
        duration  = row["duration"]
        price     = row["price"]
        available = row["available"]
        ptype     = row["product_type"]

        if available == 0:
            continue

        icon  = "🔑" if ptype == "key" else "📁"
        label = f"{icon} {duration} يوم | ${price:.2f} | {available} متاح"

        if action == "price":
            cb = f"adm_price_select_{mod_id}_{duration}_{price}"
        else:
            cb = f"adm_keys_view_{mod_id}_{duration}_{price}"

        kb.add(InlineKeyboardButton(label, callback_data=cb))

    kb.add(InlineKeyboardButton(L["back"], callback_data=f"adm_mod_{mod_id}"))
    return kb


def ticket_reply_keyboard(ticket_id: int, user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_reply_ticket"],
                             callback_data=f"adm_reply_{ticket_id}"),
        InlineKeyboardButton(L["ticket_closed"],
                             callback_data=f"adm_close_{ticket_id}")
    )
    return kb


# ── Admin Payment Methods ─────────────────────────────────────
def admin_payment_methods_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    from database import get_all_payment_methods
    methods = get_all_payment_methods()

    kb = InlineKeyboardMarkup(row_width=1)
    for m in methods:
        status = "✅" if m["is_active"] else "❌"
        kb.add(InlineKeyboardButton(
            f"{status} {m['name_ar']}",
            callback_data=f"adm_payment_{m['method_id']}"
        ))
    kb.add(InlineKeyboardButton(
        L["add_payment_method"], callback_data="adm_add_payment"
    ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="admin"))
    return kb


def admin_payment_actions_keyboard(method_id: int,
                                    user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_toggle_method"],
                             callback_data=f"adm_toggle_payment_{method_id}"),
        InlineKeyboardButton(L["btn_delete_method"],
                             callback_data=f"adm_del_payment_{method_id}")
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_payments"))
    return kb


def confirm_delete_payment_keyboard(method_id: int,
                                     user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["confirm"],
                             callback_data=f"adm_confirm_del_payment_{method_id}"),
        InlineKeyboardButton(L["cancel"],
                             callback_data=f"adm_payment_{method_id}")
    )
    return kb


# ── Admin Broadcast ───────────────────────────────────────────
def broadcast_confirm_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["confirm"], callback_data="adm_broadcast_send"),
        InlineKeyboardButton(L["cancel"],  callback_data="admin")
    )
    return kb


# ── Admin Coupons ─────────────────────────────────────────────
def coupon_type_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_coupon_balance"],
                             callback_data="adm_coupon_balance"),
        InlineKeyboardButton(L["btn_coupon_discount"],
                             callback_data="adm_coupon_discount")
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="admin"))
    return kb


# ── Admin Settings ────────────────────────────────────────────
def settings_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton(L["maintenance_mode"],    callback_data="adm_maintenance"),
        InlineKeyboardButton(L["force_sub_system"],    callback_data="adm_force_sub"),
        InlineKeyboardButton(L["recharge_commission"], callback_data="adm_recharge_commission"),
        InlineKeyboardButton(L["referral_system"],     callback_data="adm_referral_system"),
        InlineKeyboardButton(L["admin_spin_wheel"],    callback_data="adm_spin_wheel"),
        InlineKeyboardButton(L["admin_balance_msg"],   callback_data="adm_balance_msg"),
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="admin"))
    return kb


def force_sub_keyboard(user_id: int, is_active: bool) -> InlineKeyboardMarkup:
    """Admin: enable/disable the forced-subscription gate."""
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    if is_active:
        kb.add(InlineKeyboardButton(
            L["btn_disable_force_sub"], callback_data="adm_force_sub_toggle"
        ))
    else:
        kb.add(InlineKeyboardButton(
            L["btn_enable_force_sub"], callback_data="adm_force_sub_toggle"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_settings"))
    return kb


def maintenance_keyboard(user_id: int, is_active: bool) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    if is_active:
        kb.add(InlineKeyboardButton(
            L["btn_disable_maintenance"],
            callback_data="adm_maintenance_toggle"
        ))
    else:
        kb.add(InlineKeyboardButton(
            L["btn_enable_maintenance"],
            callback_data="adm_maintenance_toggle"
        ))
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_settings"))
    return kb


def recharge_commission_keyboard(user_id: int,
                                  is_enabled: bool) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_edit_commission"],
                             callback_data="adm_edit_commission"),
        InlineKeyboardButton(L["btn_toggle_commission"],
                             callback_data="adm_toggle_commission")
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_settings"))
    return kb


def referral_system_keyboard(user_id: int,
                              is_enabled: bool) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton(L["btn_edit_referral"],
                             callback_data="adm_edit_referral"),
        InlineKeyboardButton(L["btn_toggle_referral"],
                             callback_data="adm_toggle_referral")
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_settings"))
    return kb


def spin_wheel_settings_keyboard(user_id: int) -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton(L["btn_edit_spin_chances"],
                             callback_data="adm_edit_spin_chances"),
        InlineKeyboardButton(L["btn_edit_spin_balance"],
                             callback_data="adm_edit_spin_balance")
    )
    kb.add(InlineKeyboardButton(L["back"], callback_data="adm_settings"))
    return kb


# ── Generic Back ──────────────────────────────────────────────
def back_keyboard(user_id: int,
                  target: str = "main_menu") -> InlineKeyboardMarkup:
    L = get_locale_kb(user_id)
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(L["back"], callback_data=target))
    return kb