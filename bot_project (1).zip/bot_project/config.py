# ══════════════════════════════════════════
#              BOT CONFIGURATION
# ══════════════════════════════════════════
# Just fill in your values below. Nothing else needed.

BOT_TOKEN      = "8778860006:AAGf5AaXQ_QtMnkqjw5-VuaPWYgmKiVH0Gk"
OWNER_ID       = 7022254502
OWNER_USERNAME = "@BLRX_Xx"

# Default referral reward in USD
DEFAULT_REFERRAL_REWARD = 0.03

# Database file
DB_PATH = "bot_database.db"

# Low stock warning threshold
LOW_STOCK_THRESHOLD = 3

# Maximum discount percentage that can ever be applied
MAX_DISCOUNT = 10

# ══════════════════════════════════════════
#         FORCED SUBSCRIPTION (NEW)
# ══════════════════════════════════════════
# Telegram channel the user MUST join before using the bot.
#
#   FORCE_SUB_CHANNEL_ID       -> numeric chat id (bot MUST be admin there)
#   FORCE_SUB_CHANNEL_USERNAME -> public @username WITHOUT the @  (used for the join button link)
#   FORCE_SUB_CHANNEL_LINK     -> optional explicit invite link (used if the channel is private
#                                 or has no public username). Leave "" to auto-build from username.
#
# The bot verifies membership with get_chat_member, so it MUST be an admin
# (or at least a member with the right to see participants) in this channel.
FORCE_SUB_ENABLED          = True
FORCE_SUB_CHANNEL_ID       = -1002784979002
FORCE_SUB_CHANNEL_USERNAME = "SARKEXx48"          # https://t.me/SARKEXx48
FORCE_SUB_CHANNEL_LINK     = ""                    # leave empty -> https://t.me/SARKEXx48

# Instagram follow step (NO verification — shown ONCE only, informational).
INSTAGRAM_ENABLED = True
INSTAGRAM_URL     = "https://www.instagram.com/ta_48.g?igsh=MXc4NG9qaXRyaWNobQ=="

# ── Anti-spam / anti-fake-referral (hidden system) ────────────
# Minimum seconds between two "verify subscription" presses by the same user.
# Protects against button flooding. Users never see this; it just silently
# rate-limits abusive taps.
VERIFY_COOLDOWN_SECONDS = 3
